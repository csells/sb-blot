using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TableLayoutToolStripSample {
  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();

      ToolStrip ts = this.toolStrip1;
      
      // Configure table structure
      ts.LayoutStyle = ToolStripLayoutStyle.Table;
      TableLayoutSettings tableLayout = ts.LayoutSettings as TableLayoutSettings;
      tableLayout.ColumnCount = 3;
      tableLayout.RowCount = 1;
      tableLayout.ColumnStyles.Add(new ColumnStyle());
      // Spring contents of this column, which will be the drop down list
      tableLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
      tableLayout.ColumnStyles.Add(new ColumnStyle());
      // Make sure rowheight is 25 pixels, the default, since without
      // setting the height the table is only as high as the contained
      // controls
      tableLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));

      // Fill up the entire cell
      foreach( ToolStripItem toolStripItem in ts.Items ) {
        toolStripItem.Dock = DockStyle.Fill;
      }
    }
  }
}
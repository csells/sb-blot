﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace LayoutSample {
  partial class MarginsAndPaddingForm : Form {
    public MarginsAndPaddingForm() {
      InitializeComponent();
    }

    protected override void OnPaint(PaintEventArgs e) {
      base.OnPaint(e);

      Graphics g = e.Graphics;

      PaintPadding(g, this);
      foreach( Control control in this.Controls ) {
        PaintControlMargin(g, control);
        PaintPadding(Graphics.FromHwnd(control.Handle), control);
      }
    }

    private void PaintPadding(Graphics g, Control control) {

      int dx = control.ClientRectangle.Width;
      int dy = control.ClientRectangle.Height;

      // Get padding dimensions
      int pLeft = control.Padding.Left;
      int pTop = control.Padding.Top;
      int pRight = control.Padding.Right;
      int pBottom = control.Padding.Bottom;

      // Paint form padding

      using( Brush brush = new SolidBrush(Color.FromArgb(125, Color.LightSteelBlue)) ) {
        g.FillRectangle(brush, 0, 0, dx, pTop);
        g.FillRectangle(brush, 0, pTop, pLeft, dy);
        g.FillRectangle(brush, dx - pRight, pTop, dx, dy);
        g.FillRectangle(brush, pLeft, dy - pBottom, dx - pRight - pLeft, dy);
      }
    }

    private void PaintControlMargin(Graphics g, Control control) {

      // Get control dimensions
      int x = control.Left;
      int y = control.Top;
      int dx = control.Width;
      int dy = control.Height;

      // Get margin dimensions
      int mLeft = control.Margin.Left;
      int mTop = control.Margin.Top;
      int mRight = control.Margin.Right;
      int mBottom = control.Margin.Bottom;

      // Draw margin
      using( Brush brush = new SolidBrush(Color.FromArgb(125, Color.Salmon)) ) {
        g.FillRectangle(brush, x, y - mTop, dx, mTop);
        g.FillRectangle(brush, x + dx, y, mRight, dy);
        g.FillRectangle(brush, x, y + dy, dx, mBottom);
        g.FillRectangle(brush, x - mLeft, y, mLeft, dy);
      }
    }
  }
}
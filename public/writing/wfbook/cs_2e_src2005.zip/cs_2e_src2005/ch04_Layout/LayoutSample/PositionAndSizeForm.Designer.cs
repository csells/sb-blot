﻿namespace LayoutSample {
  partial class PositionAndSizeForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.nameTextBox = new System.Windows.Forms.TextBox();
      this.nameLabel = new System.Windows.Forms.Label();
      this.occupationLabel = new System.Windows.Forms.Label();
      this.occupationTextBox = new System.Windows.Forms.TextBox();
      this.SuspendLayout();
      // 
      // nameTextBox
      // 
      this.nameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.nameTextBox.Location = new System.Drawing.Point(79, 12);
      this.nameTextBox.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.nameTextBox.Name = "nameTextBox";
      this.nameTextBox.Size = new System.Drawing.Size(121, 20);
      this.nameTextBox.TabIndex = 2;
      // 
      // nameLabel
      // 
      this.nameLabel.AutoSize = true;
      this.nameLabel.Location = new System.Drawing.Point(12, 15);
      this.nameLabel.Name = "nameLabel";
      this.nameLabel.Size = new System.Drawing.Size(34, 13);
      this.nameLabel.TabIndex = 0;
      this.nameLabel.Text = "Name:";
      // 
      // occupationLabel
      // 
      this.occupationLabel.AutoSize = true;
      this.occupationLabel.Location = new System.Drawing.Point(12, 38);
      this.occupationLabel.Name = "occupationLabel";
      this.occupationLabel.Size = new System.Drawing.Size(61, 13);
      this.occupationLabel.TabIndex = 1;
      this.occupationLabel.Text = "Occupation:";
      // 
      // occupationTextBox
      // 
      this.occupationTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.occupationTextBox.Location = new System.Drawing.Point(79, 35);
      this.occupationTextBox.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.occupationTextBox.Name = "occupationTextBox";
      this.occupationTextBox.Size = new System.Drawing.Size(121, 20);
      this.occupationTextBox.TabIndex = 3;
      // 
      // ContainmentForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(211, 69);
      this.Controls.Add(this.nameLabel);
      this.Controls.Add(this.nameTextBox);
      this.Controls.Add(this.occupationLabel);
      this.Controls.Add(this.occupationTextBox);
      this.Name = "ContainmentForm";
      this.Text = "Position and Size";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox nameTextBox;
    private System.Windows.Forms.Label nameLabel;
    private System.Windows.Forms.Label occupationLabel;
    private System.Windows.Forms.TextBox occupationTextBox;
  }
}
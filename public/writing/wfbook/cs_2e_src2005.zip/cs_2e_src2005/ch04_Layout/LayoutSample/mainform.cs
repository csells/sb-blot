﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace LayoutSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void positionAndSizeButton_Click(object sender, EventArgs e) {
      (new PositionAndSizeForm()).ShowDialog();
    }

    private void marginsAndPaddingButton_Click(object sender, EventArgs e) {
      (new MarginsAndPaddingForm()).ShowDialog();
    }

    private void anchoringButton_Click(object sender, EventArgs e) {
      (new AnchoringForm()).ShowDialog();
    }

    private void anchoringAllEdgesButton_Click(object sender, EventArgs e) {
      (new AnchoringAllEdgesForm()).ShowDialog();
    }

    private void dockingButton_Click(object sender, EventArgs e) {
      (new DockingForm()).ShowDialog();
    }

    private void groupingButton_Click(object sender, EventArgs e) {
      (new GroupingForm()).ShowDialog();
    }

    private void autoScalingButton_Click(object sender, EventArgs e) {
      (new AutoScalingForm()).ShowDialog();
    }

    private void splittingButton_Click(object sender, EventArgs e) {
      (new SplittingForm()).ShowDialog();
    }

    private void zorderButton_Click(object sender, EventArgs e) {
      (new ZOrderForm()).ShowDialog();
    }

    private void tabOrderButton_Click(object sender, EventArgs e) {
      (new TabOrderForm()).ShowDialog();
    }

    private void toolStripContainerButton_Click(object sender, EventArgs e) {
      (new ToolStripContainerForm()).ShowDialog();
    }

    private void toolStripOverflowButton_Click(object sender, EventArgs e) {
      (new ToolStripOverflowForm()).ShowDialog();
    }

    private void toolStripContainerResizingButton_Click(object sender, EventArgs e) {
      (new ToolStripContainerResizingForm()).ShowDialog();
    }

    private void flowLayoutButton_Click(object sender, EventArgs e) {
      (new FlowLayoutForm()).ShowDialog();
    }

    private void tabularLayoutButton_Click(object sender, EventArgs e) {
      (new TabularLayoutForm()).ShowDialog();
    }

    private void layoutEventButton_Click(object sender, EventArgs e) {
      (new LayoutEventForm()).ShowDialog();
    }

    private void autoSizingButton_Click(object sender, EventArgs e) {
      (new AutoSizingForm()).ShowDialog();
    }
  }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LayoutSample {
  public partial class FlowLayoutForm : Form {
    public FlowLayoutForm() {
      InitializeComponent();
    }
  }
}


public enum FlowDirection {
  // Fields
  BottomUp = 3,
  LeftToRight = 0,
  RightToLeft = 2,
  TopDown = 1
}


namespace LayoutSample {
  partial class FlowLayoutForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.flowLayoutPanel1.SuspendLayout();
      this.SuspendLayout();
      // 
      // flowLayoutPanel1
      // 
      this.flowLayoutPanel1.Controls.Add(this.label1);
      this.flowLayoutPanel1.Controls.Add(this.label2);
      this.flowLayoutPanel1.Controls.Add(this.label3);
      this.flowLayoutPanel1.Controls.Add(this.label4);
      this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 0);
      this.flowLayoutPanel1.Name = "flowLayoutPanel1";
      this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(10);
      this.flowLayoutPanel1.Size = new System.Drawing.Size(517, 114);
      this.flowLayoutPanel1.TabIndex = 0;
      // 
      // label1
      // 
      this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label1.Location = new System.Drawing.Point(20, 20);
      this.label1.Margin = new System.Windows.Forms.Padding(10);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(128, 77);
      this.label1.TabIndex = 0;
      this.label1.Text = "Flow Layout Item 1";
      // 
      // label2
      // 
      this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
      this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
      this.label2.Location = new System.Drawing.Point(168, 20);
      this.label2.Margin = new System.Windows.Forms.Padding(10);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(96, 33);
      this.label2.TabIndex = 1;
      this.label2.Text = "Flow Layout Item 2 Anchor.Top";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label3
      // 
      this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
      this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label3.Location = new System.Drawing.Point(284, 20);
      this.label3.Margin = new System.Windows.Forms.Padding(10);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(96, 77);
      this.label3.TabIndex = 2;
      this.label3.Text = "Flow Layout Item 3 Dock.Fill";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label4
      // 
      this.label4.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
      this.label4.Location = new System.Drawing.Point(400, 64);
      this.label4.Margin = new System.Windows.Forms.Padding(10);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(96, 33);
      this.label4.TabIndex = 3;
      this.label4.Text = "Flow Layout Item 4 Anchor.Bottom";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // FlowLayoutForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(517, 114);
      this.Controls.Add(this.flowLayoutPanel1);
      this.Name = "FlowLayoutForm";
      this.Text = "Flow Layout";
      this.flowLayoutPanel1.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label2;
  }
}
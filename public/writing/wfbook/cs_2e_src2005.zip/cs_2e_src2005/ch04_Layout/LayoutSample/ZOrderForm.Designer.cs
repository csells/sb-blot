namespace LayoutSample {
  partial class ZOrderForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.button1zorder2 = new System.Windows.Forms.Button();
      this.button2zorder1 = new System.Windows.Forms.Button();
      this.button3zorder0 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // button1zorder2
      // 
      this.button1zorder2.Location = new System.Drawing.Point(12, 12);
      this.button1zorder2.Name = "button1zorder2";
      this.button1zorder2.Size = new System.Drawing.Size(116, 68);
      this.button1zorder2.TabIndex = 0;
      this.button1zorder2.Text = "button1 - Z-Order 2";
      // 
      // button2zorder1
      // 
      this.button2zorder1.Location = new System.Drawing.Point(60, 60);
      this.button2zorder1.Name = "button2zorder1";
      this.button2zorder1.Size = new System.Drawing.Size(116, 68);
      this.button2zorder1.TabIndex = 1;
      this.button2zorder1.Text = "button2 - Z-Order 1";
      // 
      // button3zorder0
      // 
      this.button3zorder0.Location = new System.Drawing.Point(108, 108);
      this.button3zorder0.Name = "button3zorder0";
      this.button3zorder0.Size = new System.Drawing.Size(116, 68);
      this.button3zorder0.TabIndex = 2;
      this.button3zorder0.Text = "button3 - Z-Order 0";
      // 
      // ZOrderForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(234, 188);
      this.Controls.Add(this.button3zorder0);
      this.Controls.Add(this.button2zorder1);
      this.Controls.Add(this.button1zorder2);
      this.Name = "ZOrderForm";
      this.Text = "Z-Order";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button button1zorder2;
    private System.Windows.Forms.Button button2zorder1;
    private System.Windows.Forms.Button button3zorder0;
  }
}
﻿namespace LayoutSample {
  partial class MarginsAndPaddingForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.toolStripOverflowButton = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // toolStripOverflowButton
      // 
      this.toolStripOverflowButton.Location = new System.Drawing.Point(21, 21);
      this.toolStripOverflowButton.Margin = new System.Windows.Forms.Padding(10);
      this.toolStripOverflowButton.Name = "toolStripOverflowButton";
      this.toolStripOverflowButton.Padding = new System.Windows.Forms.Padding(10);
      this.toolStripOverflowButton.Size = new System.Drawing.Size(99, 93);
      this.toolStripOverflowButton.TabIndex = 0;
      this.toolStripOverflowButton.Text = "Button: Margin = 10, Padding = 10";
      // 
      // button2
      // 
      this.button2.Location = new System.Drawing.Point(150, 56);
      this.button2.Margin = new System.Windows.Forms.Padding(20);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(180, 22);
      this.button2.TabIndex = 1;
      this.button2.Text = "Button: Margin = 20, Padding = 0";
      // 
      // MarginsAndPaddingForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(480, 183);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.toolStripOverflowButton);
      this.Margin = new System.Windows.Forms.Padding(0);
      this.Name = "MarginsAndPaddingForm";
      this.Padding = new System.Windows.Forms.Padding(10);
      this.Text = "Form: Margin = 0, Padding = 10";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button toolStripOverflowButton;
    private System.Windows.Forms.Button button2;


  }
}
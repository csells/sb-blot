﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace LayoutSample {
  partial class AnchoringForm : Form {
    public AnchoringForm() {
      InitializeComponent();
    }

    //    int delta = 0;

    private void Form1_Load(object sender, EventArgs e) {
      //      delta = ClientRectangle.Width - anchoredTextBox.Width;
    }

    private void Form1_SizeChanged(object sender, EventArgs e) {
      //      anchoredTextBox.Width = ClientRectangle.Width - delta;
    }
  }
}
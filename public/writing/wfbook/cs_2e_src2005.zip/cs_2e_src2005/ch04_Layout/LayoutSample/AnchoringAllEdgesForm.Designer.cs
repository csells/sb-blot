﻿namespace LayoutSample {
  partial class AnchoringAllEdgesForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.toolStripOverflowButton = new System.Windows.Forms.Button();
      this.button2 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button4 = new System.Windows.Forms.Button();
      this.button3 = new System.Windows.Forms.Button();
      this.button6 = new System.Windows.Forms.Button();
      this.button7 = new System.Windows.Forms.Button();
      this.button8 = new System.Windows.Forms.Button();
      this.button9 = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // toolStripOverflowButton
      // 
      this.toolStripOverflowButton.Location = new System.Drawing.Point(12, 12);
      this.toolStripOverflowButton.Name = "toolStripOverflowButton";
      this.toolStripOverflowButton.Size = new System.Drawing.Size(70, 70);
      this.toolStripOverflowButton.TabIndex = 0;
      this.toolStripOverflowButton.Text = "Top, Left";
      // 
      // button2
      // 
      this.button2.Anchor = System.Windows.Forms.AnchorStyles.Top;
      this.button2.Location = new System.Drawing.Point(89, 12);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(70, 70);
      this.button2.TabIndex = 1;
      this.button2.Text = "Top";
      // 
      // button3
      // 
      this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.button3.Location = new System.Drawing.Point(166, 12);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(70, 70);
      this.button3.TabIndex = 2;
      this.button3.Text = "Top, Right";
      // 
      // button4
      // 
      this.button4.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.button4.Location = new System.Drawing.Point(12, 89);
      this.button4.Name = "button4";
      this.button4.Size = new System.Drawing.Size(70, 70);
      this.button4.TabIndex = 3;
      this.button4.Text = "Left";
      // 
      // button3
      // 
      this.button3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.button3.Location = new System.Drawing.Point(88, 88);
      this.button3.Name = "button3";
      this.button3.Size = new System.Drawing.Size(72, 71);
      this.button3.TabIndex = 4;
      this.button3.Text = "Top, Bottom, Left, Right";
      // 
      // button6
      // 
      this.button6.Anchor = System.Windows.Forms.AnchorStyles.Right;
      this.button6.Location = new System.Drawing.Point(166, 89);
      this.button6.Name = "button6";
      this.button6.Size = new System.Drawing.Size(70, 70);
      this.button6.TabIndex = 5;
      this.button6.Text = "Right";
      // 
      // button7
      // 
      this.button7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.button7.Location = new System.Drawing.Point(12, 165);
      this.button7.Name = "button7";
      this.button7.Size = new System.Drawing.Size(70, 70);
      this.button7.TabIndex = 6;
      this.button7.Text = "Bottom, Left";
      // 
      // button8
      // 
      this.button8.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.button8.Location = new System.Drawing.Point(89, 165);
      this.button8.Name = "button8";
      this.button8.Size = new System.Drawing.Size(70, 70);
      this.button8.TabIndex = 7;
      this.button8.Text = "Bottom";
      // 
      // button9
      // 
      this.button9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.button9.Location = new System.Drawing.Point(166, 165);
      this.button9.Name = "button9";
      this.button9.Size = new System.Drawing.Size(70, 70);
      this.button9.TabIndex = 8;
      this.button9.Text = "Bottom, Right";
      // 
      // AnchoringAllEdgesForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.SystemColors.Control;
      this.ClientSize = new System.Drawing.Size(250, 248);
      this.Controls.Add(this.button9);
      this.Controls.Add(this.button8);
      this.Controls.Add(this.button7);
      this.Controls.Add(this.button6);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button4);
      this.Controls.Add(this.button3);
      this.Controls.Add(this.button2);
      this.Controls.Add(this.toolStripOverflowButton);
      this.Name = "AnchoringAllEdgesForm";
      this.Text = "Anchoring All Edges";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button toolStripOverflowButton;
    private System.Windows.Forms.Button button2;
    private System.Windows.Forms.Button button3;
    private System.Windows.Forms.Button button4;
    private System.Windows.Forms.Button button6;
    private System.Windows.Forms.Button button7;
    private System.Windows.Forms.Button button8;
    private System.Windows.Forms.Button button9;
  }
}
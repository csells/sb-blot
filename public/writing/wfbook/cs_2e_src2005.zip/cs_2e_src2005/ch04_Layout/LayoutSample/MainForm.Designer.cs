﻿namespace LayoutSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.marginsAndPaddingButton = new System.Windows.Forms.Button();
      this.anchoringButton = new System.Windows.Forms.Button();
      this.dockingButton = new System.Windows.Forms.Button();
      this.groupingButton = new System.Windows.Forms.Button();
      this.positionAndSizeButton = new System.Windows.Forms.Button();
      this.anchoringAllEdgesButton = new System.Windows.Forms.Button();
      this.autoScalingButton = new System.Windows.Forms.Button();
      this.splittingButton = new System.Windows.Forms.Button();
      this.zorderButton = new System.Windows.Forms.Button();
      this.tabOrderButton = new System.Windows.Forms.Button();
      this.toolStripContainerButton = new System.Windows.Forms.Button();
      this.button1 = new System.Windows.Forms.Button();
      this.toolStripContainerResizingButton = new System.Windows.Forms.Button();
      this.flowLayoutButton = new System.Windows.Forms.Button();
      this.tabularLayoutButton = new System.Windows.Forms.Button();
      this.layoutEventButton = new System.Windows.Forms.Button();
      this.autoSizingButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // marginsAndPaddingButton
      // 
      this.marginsAndPaddingButton.Location = new System.Drawing.Point(12, 110);
      this.marginsAndPaddingButton.Name = "marginsAndPaddingButton";
      this.marginsAndPaddingButton.Size = new System.Drawing.Size(219, 23);
      this.marginsAndPaddingButton.TabIndex = 3;
      this.marginsAndPaddingButton.Text = "Margins and Padding";
      this.marginsAndPaddingButton.Click += new System.EventHandler(this.marginsAndPaddingButton_Click);
      // 
      // anchoringButton
      // 
      this.anchoringButton.Location = new System.Drawing.Point(12, 139);
      this.anchoringButton.Name = "anchoringButton";
      this.anchoringButton.Size = new System.Drawing.Size(219, 23);
      this.anchoringButton.TabIndex = 4;
      this.anchoringButton.Text = "Anchoring";
      this.anchoringButton.Click += new System.EventHandler(this.anchoringButton_Click);
      // 
      // dockingButton
      // 
      this.dockingButton.Location = new System.Drawing.Point(12, 197);
      this.dockingButton.Name = "dockingButton";
      this.dockingButton.Size = new System.Drawing.Size(219, 23);
      this.dockingButton.TabIndex = 6;
      this.dockingButton.Text = "Docking";
      this.dockingButton.Click += new System.EventHandler(this.dockingButton_Click);
      // 
      // groupingButton
      // 
      this.groupingButton.Location = new System.Drawing.Point(271, 110);
      this.groupingButton.Name = "groupingButton";
      this.groupingButton.Size = new System.Drawing.Size(219, 23);
      this.groupingButton.TabIndex = 13;
      this.groupingButton.Text = "Grouping";
      this.groupingButton.Click += new System.EventHandler(this.groupingButton_Click);
      // 
      // positionAndSizeButton
      // 
      this.positionAndSizeButton.Location = new System.Drawing.Point(12, 12);
      this.positionAndSizeButton.Name = "positionAndSizeButton";
      this.positionAndSizeButton.Size = new System.Drawing.Size(219, 23);
      this.positionAndSizeButton.TabIndex = 0;
      this.positionAndSizeButton.Text = "Position and Size";
      this.positionAndSizeButton.Click += new System.EventHandler(this.positionAndSizeButton_Click);
      // 
      // anchoringAllEdgesButton
      // 
      this.anchoringAllEdgesButton.Location = new System.Drawing.Point(12, 168);
      this.anchoringAllEdgesButton.Name = "anchoringAllEdgesButton";
      this.anchoringAllEdgesButton.Size = new System.Drawing.Size(219, 23);
      this.anchoringAllEdgesButton.TabIndex = 5;
      this.anchoringAllEdgesButton.Text = "Anchoring All Edges";
      this.anchoringAllEdgesButton.Click += new System.EventHandler(this.anchoringAllEdgesButton_Click);
      // 
      // autoScalingButton
      // 
      this.autoScalingButton.Location = new System.Drawing.Point(271, 12);
      this.autoScalingButton.Name = "autoScalingButton";
      this.autoScalingButton.Size = new System.Drawing.Size(219, 23);
      this.autoScalingButton.TabIndex = 10;
      this.autoScalingButton.Text = "Auto-Scaling";
      this.autoScalingButton.Click += new System.EventHandler(this.autoScalingButton_Click);
      // 
      // splittingButton
      // 
      this.splittingButton.Location = new System.Drawing.Point(271, 81);
      this.splittingButton.Name = "splittingButton";
      this.splittingButton.Size = new System.Drawing.Size(219, 23);
      this.splittingButton.TabIndex = 12;
      this.splittingButton.Text = "Splitting";
      this.splittingButton.Click += new System.EventHandler(this.splittingButton_Click);
      // 
      // zorderButton
      // 
      this.zorderButton.Location = new System.Drawing.Point(12, 41);
      this.zorderButton.Name = "zorderButton";
      this.zorderButton.Size = new System.Drawing.Size(219, 23);
      this.zorderButton.TabIndex = 1;
      this.zorderButton.Text = "Z-Order";
      this.zorderButton.Click += new System.EventHandler(this.zorderButton_Click);
      // 
      // tabOrderButton
      // 
      this.tabOrderButton.Location = new System.Drawing.Point(12, 70);
      this.tabOrderButton.Name = "tabOrderButton";
      this.tabOrderButton.Size = new System.Drawing.Size(219, 23);
      this.tabOrderButton.TabIndex = 2;
      this.tabOrderButton.Text = "Tab-Order";
      this.tabOrderButton.Click += new System.EventHandler(this.tabOrderButton_Click);
      // 
      // toolStripContainerButton
      // 
      this.toolStripContainerButton.Location = new System.Drawing.Point(12, 226);
      this.toolStripContainerButton.Name = "toolStripContainerButton";
      this.toolStripContainerButton.Size = new System.Drawing.Size(219, 23);
      this.toolStripContainerButton.TabIndex = 7;
      this.toolStripContainerButton.Text = "ToolStripContainer";
      this.toolStripContainerButton.Click += new System.EventHandler(this.toolStripContainerButton_Click);
      // 
      // button1
      // 
      this.button1.Location = new System.Drawing.Point(12, 284);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(219, 23);
      this.button1.TabIndex = 9;
      this.button1.Text = "ToolStrip Overflow";
      this.button1.Click += new System.EventHandler(this.toolStripOverflowButton_Click);
      // 
      // toolStripContainerResizingButton
      // 
      this.toolStripContainerResizingButton.Location = new System.Drawing.Point(12, 255);
      this.toolStripContainerResizingButton.Name = "toolStripContainerResizingButton";
      this.toolStripContainerResizingButton.Size = new System.Drawing.Size(219, 23);
      this.toolStripContainerResizingButton.TabIndex = 8;
      this.toolStripContainerResizingButton.Text = "ToolStripContainer Resizing";
      this.toolStripContainerResizingButton.Click += new System.EventHandler(this.toolStripContainerResizingButton_Click);
      // 
      // flowLayoutButton
      // 
      this.flowLayoutButton.Location = new System.Drawing.Point(271, 139);
      this.flowLayoutButton.Name = "flowLayoutButton";
      this.flowLayoutButton.Size = new System.Drawing.Size(219, 23);
      this.flowLayoutButton.TabIndex = 14;
      this.flowLayoutButton.Text = "Flow Layout";
      this.flowLayoutButton.Click += new System.EventHandler(this.flowLayoutButton_Click);
      // 
      // tabularLayoutButton
      // 
      this.tabularLayoutButton.Location = new System.Drawing.Point(271, 168);
      this.tabularLayoutButton.Name = "tabularLayoutButton";
      this.tabularLayoutButton.Size = new System.Drawing.Size(219, 23);
      this.tabularLayoutButton.TabIndex = 15;
      this.tabularLayoutButton.Text = "Tabular Layout";
      this.tabularLayoutButton.Click += new System.EventHandler(this.tabularLayoutButton_Click);
      // 
      // layoutEventButton
      // 
      this.layoutEventButton.Location = new System.Drawing.Point(271, 197);
      this.layoutEventButton.Name = "layoutEventButton";
      this.layoutEventButton.Size = new System.Drawing.Size(219, 23);
      this.layoutEventButton.TabIndex = 16;
      this.layoutEventButton.Text = "Layout Event";
      this.layoutEventButton.Click += new System.EventHandler(this.layoutEventButton_Click);
      // 
      // autoSizingButton
      // 
      this.autoSizingButton.Location = new System.Drawing.Point(271, 41);
      this.autoSizingButton.Name = "autoSizingButton";
      this.autoSizingButton.Size = new System.Drawing.Size(219, 23);
      this.autoSizingButton.TabIndex = 11;
      this.autoSizingButton.Text = "Auto-Sizing";
      this.autoSizingButton.Click += new System.EventHandler(this.autoSizingButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(502, 321);
      this.Controls.Add(this.autoSizingButton);
      this.Controls.Add(this.layoutEventButton);
      this.Controls.Add(this.flowLayoutButton);
      this.Controls.Add(this.tabularLayoutButton);
      this.Controls.Add(this.toolStripContainerResizingButton);
      this.Controls.Add(this.button1);
      this.Controls.Add(this.toolStripContainerButton);
      this.Controls.Add(this.tabOrderButton);
      this.Controls.Add(this.zorderButton);
      this.Controls.Add(this.splittingButton);
      this.Controls.Add(this.autoScalingButton);
      this.Controls.Add(this.anchoringAllEdgesButton);
      this.Controls.Add(this.positionAndSizeButton);
      this.Controls.Add(this.groupingButton);
      this.Controls.Add(this.dockingButton);
      this.Controls.Add(this.anchoringButton);
      this.Controls.Add(this.marginsAndPaddingButton);
      this.Name = "MainForm";
      this.Text = "Layout Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button marginsAndPaddingButton;
    private System.Windows.Forms.Button anchoringButton;
    private System.Windows.Forms.Button dockingButton;
    private System.Windows.Forms.Button groupingButton;
    private System.Windows.Forms.Button positionAndSizeButton;
    private System.Windows.Forms.Button anchoringAllEdgesButton;
    private System.Windows.Forms.Button autoScalingButton;
    private System.Windows.Forms.Button splittingButton;
    private System.Windows.Forms.Button zorderButton;
    private System.Windows.Forms.Button tabOrderButton;
    private System.Windows.Forms.Button toolStripContainerButton;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.Button toolStripContainerResizingButton;
    private System.Windows.Forms.Button flowLayoutButton;
    private System.Windows.Forms.Button tabularLayoutButton;
    private System.Windows.Forms.Button layoutEventButton;
    private System.Windows.Forms.Button autoSizingButton;
  }
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LayoutSample {
  public partial class AutoSizingForm : Form {
    public AutoSizingForm() {
      InitializeComponent();
    }

    private void AutoSizingForm_Load(object sender, EventArgs e) {
      this.anchoredTextBox.Width = 500;
    }
  }
}
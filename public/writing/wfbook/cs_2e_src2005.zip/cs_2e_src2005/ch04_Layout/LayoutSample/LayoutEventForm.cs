using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace LayoutSample {
  public partial class LayoutEventForm : Form {

    Button button1 = new Button();
    Button button2 = new Button();
    Button button3 = new Button();
    Button button4 = new Button();
    Button button5 = new Button();
    Button button6 = new Button();
    Button button7 = new Button();
    Button button8 = new Button();
    Button button9 = new Button();
    
    public LayoutEventForm() {
      InitializeComponent();

      this.button1.Text = "1";
      this.button2.Text = "2";
      this.button3.Text = "3";
      this.button4.Text = "4";
      this.button5.Text = "5";
      this.button6.Text = "6";
      this.button7.Text = "7";
      this.button8.Text = "8";
      this.button9.Text = "9";
      
      this.Controls.Add(button1);
      this.Controls.Add(button2);
      this.Controls.Add(button3);
      this.Controls.Add(button4);
      this.Controls.Add(button5);
      this.Controls.Add(button6);
      this.Controls.Add(button7);
      this.Controls.Add(button8);
      this.Controls.Add(button9);
    }

    private void LayoutEventForm_Layout(object sender, LayoutEventArgs e) {

      Button[] buttons = new Button[] { button1, button2, button3, 
                                        button4, button3, button6,
                                        button7, button8, button9 };

      // Suspend layout until we're done moving things
      this.SuspendLayout();

      // Arrange the buttons in a grid on the form
      int cx = ClientRectangle.Width / 3;
      int cy = ClientRectangle.Height / 3;
      for( int row = 0; row != 3; ++row ) {
        for( int col = 0; col != 3; ++col ) {
          Button button = buttons[col * 3 + row];
          button.SetBounds(cx * row, cy * col, cx, cy);
        }
      }

      // Set form client size to be multiple of width/height
      SetClientSizeCore(cx * 3, cy * 3);

      // Resume the layout
      this.ResumeLayout();

    }
  }
}
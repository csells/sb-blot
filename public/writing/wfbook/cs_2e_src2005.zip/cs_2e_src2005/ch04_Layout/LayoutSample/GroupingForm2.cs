﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace LayoutSample {
  partial class GroupingForm2 : Form {
    public GroupingForm2() {
      InitializeComponent();
    }
  }
}
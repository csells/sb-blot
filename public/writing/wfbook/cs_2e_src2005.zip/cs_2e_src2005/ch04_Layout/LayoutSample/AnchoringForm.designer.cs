﻿namespace LayoutSample {
  partial class AnchoringForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.anchoredTextBox = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // anchoredTextBox
      // 
      this.anchoredTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.anchoredTextBox.Location = new System.Drawing.Point(135, 12);
      this.anchoredTextBox.Name = "anchoredTextBox";
      this.anchoredTextBox.Size = new System.Drawing.Size(118, 20);
      this.anchoredTextBox.TabIndex = 3;
      this.anchoredTextBox.Text = "anchoredTextBox";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 15);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(119, 13);
      this.label1.TabIndex = 2;
      this.label1.Text = "My perfectly-sized label:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // AnchoringForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(265, 320);
      this.Controls.Add(this.anchoredTextBox);
      this.Controls.Add(this.label1);
      this.MinimumSize = new System.Drawing.Size(257, 84);
      this.Name = "AnchoringForm";
      this.Text = "Anchoring";
      this.SizeChanged += new System.EventHandler(this.Form1_SizeChanged);
      this.Load += new System.EventHandler(this.Form1_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox anchoredTextBox;
    private System.Windows.Forms.Label label1;
  }
}


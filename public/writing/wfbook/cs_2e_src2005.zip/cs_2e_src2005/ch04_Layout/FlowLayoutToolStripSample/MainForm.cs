using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FlowLayoutToolStripSample {
  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
      
      // Flow layout MenuStrip vertically
      MenuStrip ms = this.menuStrip1;
      ms.LayoutStyle = ToolStripLayoutStyle.Flow;
      FlowLayoutSettings flowLayout = ms.LayoutSettings as FlowLayoutSettings;
      flowLayout.FlowDirection = FlowDirection.TopDown;
      ms.Dock = DockStyle.Left;
    }
  }
}


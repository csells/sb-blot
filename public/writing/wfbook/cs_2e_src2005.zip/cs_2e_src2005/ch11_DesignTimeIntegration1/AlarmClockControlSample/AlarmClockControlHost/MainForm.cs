﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlHost {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void alarmClockControlHostFormButton_Click(object sender, EventArgs e) {
      (new AlarmClockControlHostForm()).ShowDialog();
    }

    private void multipleTimeZonesFormButton_Click(object sender, EventArgs e) {
      (new MultipleTimeZonesForm()).ShowDialog();
    }
  }
}
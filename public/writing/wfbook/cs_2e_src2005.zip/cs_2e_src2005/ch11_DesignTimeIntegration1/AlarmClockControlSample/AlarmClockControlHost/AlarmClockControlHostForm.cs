﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlHost {
  partial class AlarmClockControlHostForm : Form {
    public AlarmClockControlHostForm() {
      InitializeComponent();
    }

    private void alarmClockControl_AlarmSounded(object sender, AlarmClockControlLibrary.AlarmSoundedEventArgs e) {
      MessageBox.Show("It's " + e.Alarm.ToString() + ". Wake up!");
    }

    private void alarmClockControl_AlarmChanged(object sender, AlarmClockControlLibrary.AlarmChangedEventArgs e) {
      MessageBox.Show("Alarm changed to " + e.Alarm.ToString());
    }

    private void alarmClockControl_MessageNotification(object sender, AlarmClockControlLibrary.MessageNotificationEventArgs e) {
      MessageBox.Show("You have a message: " + e.Message);

    }
  }
}
﻿namespace AlarmClockControlHost {
  partial class MultipleTimeZonesForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.londonPictureBox = new System.Windows.Forms.PictureBox();
      this.sydneyPictureBox = new System.Windows.Forms.PictureBox();
      this.portlandPictureBox = new System.Windows.Forms.PictureBox();
      this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
      this.alarmClockControl = new AlarmClockControlLibrary.AlarmClockControl();
      ((System.ComponentModel.ISupportInitialize)(this.londonPictureBox)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.sydneyPictureBox)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.portlandPictureBox)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.alarmClockControl)).BeginInit();
      this.SuspendLayout();
      // 
      // londonPictureBox
      // 
      this.londonPictureBox.Image = AlarmClockControlHost.Properties.Resources.LondonOffice;
      this.londonPictureBox.Location = new System.Drawing.Point(13, 13);
      this.londonPictureBox.Name = "londonPictureBox";
      this.londonPictureBox.Size = new System.Drawing.Size(117, 184);
      this.londonPictureBox.TabIndex = 0;
      this.londonPictureBox.TabStop = false;
      this.alarmClockControl.SetTimeZoneModifier(this.londonPictureBox, -11);
      this.toolTip1.SetToolTip(this.londonPictureBox, "Click for London time.");
      this.londonPictureBox.MouseLeave += new System.EventHandler(this.pictureBox_MouseLeave);
      this.londonPictureBox.MouseEnter += new System.EventHandler(this.pictureBox_MouseEnter);
      // 
      // sydneyPictureBox
      // 
      this.sydneyPictureBox.Image = AlarmClockControlHost.Properties.Resources.SydneyOffice;
      this.sydneyPictureBox.Location = new System.Drawing.Point(137, 13);
      this.sydneyPictureBox.Name = "sydneyPictureBox";
      this.sydneyPictureBox.Size = new System.Drawing.Size(117, 184);
      this.sydneyPictureBox.TabIndex = 1;
      this.sydneyPictureBox.TabStop = false;
      this.alarmClockControl.SetTimeZoneModifier(this.sydneyPictureBox, 10);
      this.toolTip1.SetToolTip(this.sydneyPictureBox, "Click for Sydney time.");
      this.sydneyPictureBox.MouseLeave += new System.EventHandler(this.pictureBox_MouseLeave);
      this.sydneyPictureBox.MouseEnter += new System.EventHandler(this.pictureBox_MouseEnter);
      // 
      // portlandPictureBox
      // 
      this.portlandPictureBox.Image = AlarmClockControlHost.Properties.Resources.PortlandOffice;
      this.portlandPictureBox.Location = new System.Drawing.Point(261, 13);
      this.portlandPictureBox.Name = "portlandPictureBox";
      this.portlandPictureBox.Size = new System.Drawing.Size(117, 184);
      this.portlandPictureBox.TabIndex = 2;
      this.portlandPictureBox.TabStop = false;
      this.alarmClockControl.SetTimeZoneModifier(this.portlandPictureBox, -19);
      this.toolTip1.SetToolTip(this.portlandPictureBox, "Click for Portland time.");
      this.portlandPictureBox.MouseLeave += new System.EventHandler(this.pictureBox_MouseLeave);
      this.portlandPictureBox.MouseEnter += new System.EventHandler(this.pictureBox_MouseEnter);
      // 
      // alarmClockControl
      // 
      this.alarmClockControl.BackupAlarm = new System.DateTime(2004, 12, 9, 0, 54, 46, 754);
      this.alarmClockControl.HourHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Black, 2);
      this.alarmClockControl.Location = new System.Drawing.Point(95, 204);
      this.alarmClockControl.MinuteHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Black, 2);
      this.alarmClockControl.Name = "alarmClockControl";
      this.alarmClockControl.PrimaryAlarm = new System.DateTime(2004, 12, 9, 0, 39, 46, 754);
      this.alarmClockControl.SecondHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Red, 2);
      this.alarmClockControl.Size = new System.Drawing.Size(201, 156);
      this.alarmClockControl.TabIndex = 3;
      this.alarmClockControl.Text = "Alarm Clock Control";
      // 
      // MultipleTimeZonesForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(390, 372);
      this.Controls.Add(this.alarmClockControl);
      this.Controls.Add(this.portlandPictureBox);
      this.Controls.Add(this.sydneyPictureBox);
      this.Controls.Add(this.londonPictureBox);
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.MinimumSize = new System.Drawing.Size(398, 359);
      this.Name = "MultipleTimeZonesForm";
      this.Text = "Multiple Time Zones";
      ((System.ComponentModel.ISupportInitialize)(this.londonPictureBox)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.sydneyPictureBox)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.portlandPictureBox)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.alarmClockControl)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.PictureBox londonPictureBox;
    private System.Windows.Forms.PictureBox sydneyPictureBox;
    private System.Windows.Forms.PictureBox portlandPictureBox;
    private System.Windows.Forms.ToolTip toolTip1;
    private AlarmClockControlLibrary.AlarmClockControl alarmClockControl;
  }
}
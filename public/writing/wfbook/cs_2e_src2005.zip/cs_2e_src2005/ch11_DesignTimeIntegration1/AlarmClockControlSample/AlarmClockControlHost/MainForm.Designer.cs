﻿namespace AlarmClockControlHost {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.alarmClockControlHostFormButton = new System.Windows.Forms.Button();
      this.multipleTimeZonesFormButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // alarmClockControlHostFormButton
      // 
      this.alarmClockControlHostFormButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.alarmClockControlHostFormButton.Location = new System.Drawing.Point(13, 13);
      this.alarmClockControlHostFormButton.Name = "alarmClockControlHostFormButton";
      this.alarmClockControlHostFormButton.Size = new System.Drawing.Size(267, 23);
      this.alarmClockControlHostFormButton.TabIndex = 0;
      this.alarmClockControlHostFormButton.Text = "AlarmClockControl Host Form";
      this.alarmClockControlHostFormButton.Click += new System.EventHandler(this.alarmClockControlHostFormButton_Click);
      // 
      // multipleTimeZonesFormButton
      // 
      this.multipleTimeZonesFormButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.multipleTimeZonesFormButton.Location = new System.Drawing.Point(13, 43);
      this.multipleTimeZonesFormButton.Name = "multipleTimeZonesFormButton";
      this.multipleTimeZonesFormButton.Size = new System.Drawing.Size(267, 23);
      this.multipleTimeZonesFormButton.TabIndex = 1;
      this.multipleTimeZonesFormButton.Text = "Multiple Time Zones Form";
      this.multipleTimeZonesFormButton.Click += new System.EventHandler(this.multipleTimeZonesFormButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 80);
      this.Controls.Add(this.multipleTimeZonesFormButton);
      this.Controls.Add(this.alarmClockControlHostFormButton);
      this.Name = "MainForm";
      this.Text = "MainForm";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button alarmClockControlHostFormButton;
    private System.Windows.Forms.Button multipleTimeZonesFormButton;
  }
}
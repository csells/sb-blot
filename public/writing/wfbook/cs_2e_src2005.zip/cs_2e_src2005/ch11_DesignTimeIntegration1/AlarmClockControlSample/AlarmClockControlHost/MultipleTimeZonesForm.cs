﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlHost {
  partial class MultipleTimeZonesForm : Form {
    public MultipleTimeZonesForm() {
      InitializeComponent();
    }

    private void pictureBox_MouseEnter(object sender, EventArgs e) {
      this.Cursor = Cursors.Hand;
    }

    private void pictureBox_MouseLeave(object sender, EventArgs e) {
      this.Cursor = Cursors.Default;
    }
  }
}
﻿namespace AlarmClockControlHost {
  partial class AlarmClockControlHostForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.alarmClockControl = new AlarmClockControlLibrary.AlarmClockControl();
      ((System.ComponentModel.ISupportInitialize)(this.alarmClockControl)).BeginInit();
      this.SuspendLayout();
      // 
      // alarmClockControl
      // 
      this.alarmClockControl.BackupAlarm = new System.DateTime(2005, 5, 23, 19, 25, 38, 854);
      this.alarmClockControl.Dock = System.Windows.Forms.DockStyle.Fill;
      this.alarmClockControl.HourHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Black, 2);
      this.alarmClockControl.Location = new System.Drawing.Point(5, 5);
      this.alarmClockControl.MinuteHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Black, 2);
      this.alarmClockControl.Name = "alarmClockControl";
      this.alarmClockControl.PrimaryAlarm = new System.DateTime(2005, 5, 23, 19, 10, 38, 854);
      this.alarmClockControl.SecondHand = new AlarmClockControlLibrary.Hand(System.Drawing.Color.Red, 2);
      this.alarmClockControl.Size = new System.Drawing.Size(397, 326);
      this.alarmClockControl.TabIndex = 0;
      this.alarmClockControl.Text = "alarmClockControl1";
      this.alarmClockControl.AlarmSounded += new AlarmClockControlLibrary.AlarmSoundedEventHandler(this.alarmClockControl_AlarmSounded);
      this.alarmClockControl.AlarmChanged += new AlarmClockControlLibrary.AlarmChangedEventHandler(this.alarmClockControl_AlarmChanged);
      this.alarmClockControl.MessageNotification += new AlarmClockControlLibrary.MessageNotificationEventHandler(this.alarmClockControl_MessageNotification);
      // 
      // AlarmClockControlHostForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(407, 336);
      this.Controls.Add(this.alarmClockControl);
      this.Name = "AlarmClockControlHostForm";
      this.Padding = new System.Windows.Forms.Padding(5);
      this.Text = "Alarm Clock Control Host";
      ((System.ComponentModel.ISupportInitialize)(this.alarmClockControl)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private AlarmClockControlLibrary.AlarmClockControl alarmClockControl;




























































  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public delegate void MessageNotificationEventHandler(object sender, MessageNotificationEventArgs e);
}

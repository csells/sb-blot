﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Design;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {

  [TypeConverter(typeof(HandConverter))]
  public class Hand {
    private Color color = Color.Black;
    private int width = 1;
    public Hand() {}
    public Hand(Color color, int width) {
      this.color = color;
      this.width = width;
    }

    //[System.ComponentModel.NotifyParentPropertyAttribute(true)]
    [DescriptionAttribute("Sets the color of the clock Hand.")]
    public Color Color {
      get { return this.color; }
      set { this.color = value; }
    }

    //[System.ComponentModel.NotifyParentPropertyAttribute(true)]
    [DescriptionAttribute("Sets the width of the clock Hand.")]
    public int Width {
      get { return this.width; }
      set { this.width = value; }
    }
  }
}

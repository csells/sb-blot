﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public class AlarmSoundedEventArgs : EventArgs {
    private DateTime alarm;
    private AlarmType alarmType;
    public AlarmSoundedEventArgs(DateTime alarm, AlarmType alarmType) {
      this.alarm = alarm;
      this.alarmType = AlarmType;
    }
    public DateTime Alarm {
      get { return this.alarm; }
    }
    public AlarmType AlarmType {
      get { return this.alarmType; }
    }
  }
}

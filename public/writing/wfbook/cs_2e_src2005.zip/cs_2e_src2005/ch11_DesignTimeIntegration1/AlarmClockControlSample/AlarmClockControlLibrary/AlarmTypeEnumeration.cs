﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public enum AlarmType {
    Primary,
    Backup
  }
}

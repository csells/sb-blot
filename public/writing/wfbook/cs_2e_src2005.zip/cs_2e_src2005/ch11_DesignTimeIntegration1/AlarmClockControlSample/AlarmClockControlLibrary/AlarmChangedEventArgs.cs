﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public class AlarmChangedEventArgs : EventArgs {
    public DateTime Alarm;
    public AlarmChangedEventArgs(DateTime alarm) { this.Alarm = alarm; }
  }
}

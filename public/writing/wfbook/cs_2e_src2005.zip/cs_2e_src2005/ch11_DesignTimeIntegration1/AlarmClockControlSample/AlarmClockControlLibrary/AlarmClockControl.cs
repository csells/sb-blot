﻿#region Using directives

using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Data;
using System.Drawing;
using System.Drawing.Design;
using System.Globalization;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlLibrary {

  [ToolboxBitmap(typeof(AlarmClockControl), "AlarmClockControl.ico")]
  //[ToolboxBitmap(typeof(AlarmClockControl), "AlarmClockControl.bmp")]
  [DefaultEvent("AlarmSounded")]
  [DefaultProperty("ShowDigitalTime")]
  [ProvideProperty("TimeZoneModifier", typeof(PictureBox))]
  public partial class AlarmClockControl : ScrollableControl, ISupportInitialize, ISupportInitializeNotification, IExtenderProvider {

    DateTime primaryAlarm = DateTime.Now;
    bool primaryAlarmSet = false;
    DateTime backupAlarm = DateTime.Now.AddMinutes(15);
    bool backupAlarmSet = false;
    Collection<MessageToSelf> messagesToSelf = new Collection<MessageToSelf>();
    bool initializing = false;
    ClockFace face = ClockFace.Both;
    private Hand hourHand = new Hand(Color.Black, 1);
    private Hand minuteHand = new Hand(Color.Black, 1);
    private Hand secondHand = new Hand(Color.Red, 1);
    string digitalTimeFormat = "dd/MM/yyyy hh:mm:ss tt";

    // Mapping of components to numeric timezone offsets
    Hashtable timeZoneModifiers = new Hashtable();
    int timeZoneModifier = 0;

    public AlarmClockControl() {
      InitializeComponent();

      this.DoubleBuffered = true;

      this.PaddingChanged += this.alarmClockControl_PaddingChanged;
    }

    #region ISupportInitializeNotification Members

    public event EventHandler Initialized;

    // Must not be visible at design-time
    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool IsInitialized {
      get { return !this.initializing; }
    }

    #endregion

    #region ISupportInitialize

    public void BeginInit() { this.initializing = true; }
    public void EndInit() {
      if( !this.DesignMode ) {
        // Check alarm values
        if( primaryAlarm >= backupAlarm )
          throw new ArgumentOutOfRangeException("Primary alarm must be before Backup alarm");
        //Initialize timer
        timer.Interval = 1000;
        timer.Tick += this.timer_Tick;
        timer.Enabled = true;
      }
      this.initializing = false;

      // Notify dependent design-time components
      if( this.Initialized != null ) {
        this.Initialized(this, EventArgs.Empty);
      }
    }

    #endregion

    #region IExtenderProvider

    public bool CanExtend(object extendee) {
      // Don't extend self
      if( extendee == this ) return false;

      // Extend suitable controls
      return ((extendee is PictureBox) ||
              (extendee is Panel));
    }

    #endregion

    #region Mouse input handling
    // Track whether mouse button is down
    private bool mouseDown = false;
    protected override void OnMouseDown(MouseEventArgs e) {
      if( this.DesignMode ) return;
      mouseDown = true;
      SetForeColor(e);
      base.OnMouseDown(e);
    }
    protected override void OnMouseMove(MouseEventArgs e) {
      if( this.DesignMode ) return;
      if( mouseDown ) SetForeColor(e);
      base.OnMouseMove(e);
    }
    protected override void OnMouseUp(MouseEventArgs e) {
      if( this.DesignMode ) return;
      SetForeColor(e);
      mouseDown = false;
      base.OnMouseUp(e);
    }
    private void SetForeColor(MouseEventArgs e) {
      if( (e.Button & MouseButtons.Left) == MouseButtons.Left ) {
        int red = (e.X * 255 / (this.ClientRectangle.Width - e.X)) % 256;
        if( red < 0 ) red = -red;
        int green = 0;
        int blue = (e.Y * 255 / (this.ClientRectangle.Height - e.Y)) % 256;
        if( blue < 0 ) blue = -blue;
        this.ForeColor = Color.FromArgb(red, green, blue);
      }
    }
    #endregion

    #region Keyboard input handling
    protected override void OnPreviewKeyDown(PreviewKeyDownEventArgs e) {
      // Specify the arrow keys as input chars
      switch( e.KeyData ) {
        case Keys.Up:
        case Keys.Left:
        case Keys.Down:
        case Keys.Right:
          e.IsInputKey = true;
          return;
      }

      // The rest can be determined by the base class
      base.OnPreviewKeyDown(e);
    }
    protected override void OnKeyDown(KeyEventArgs e) {

      Point location = new Point(this.Left, this.Top);

      switch( e.KeyCode ) {
        case Keys.I:
        case Keys.Up:
          --location.Y;
          break;

        case Keys.J:
        case Keys.Left:
          --location.X;
          break;

        case Keys.K:
        case Keys.Down:
          ++location.Y;
          break;

        case Keys.L:
        case Keys.Right:
          ++location.X;
          break;
      }

      this.Location = location;

      base.OnKeyDown(e);
    }
    //protected override bool IsInputKey(Keys keyData) {
    //  // Make sure we get arrow keys
    //  switch( keyData ) {
    //    case Keys.Up:
    //    case Keys.Left:
    //    case Keys.Down:
    //    case Keys.Right:
    //      return true;
    //  }

    //  // The rest can be determined by the base class
    //  return base.IsInputKey(keyData);
    //}
    #endregion

    [Category("Behavior")]
    [Description("Primary alarm for late risers.")]
    public DateTime PrimaryAlarm {
      get { return this.primaryAlarm; }
      set {

        if( !this.initializing ) {
          if( value >= this.backupAlarm ) {
            throw new ArgumentOutOfRangeException("Primary alarm must be before Backup alarm");
          }
        }

        this.primaryAlarm = value;
        this.primaryAlarmSet = true;

        // Fire AlarmChanged event 
        if( this.AlarmChanged != null ) {
          this.AlarmChanged(this, new AlarmChangedEventArgs(value));
        }

        this.Invalidate();
      }
    }

    [Category("Behavior")]
    [Description("Backup alarm for very very late risers.")]
    public DateTime BackupAlarm {
      get { return this.backupAlarm; }
      set {
        if( !this.initializing ) {
          if( value < this.primaryAlarm ) {
            throw new ArgumentOutOfRangeException("Backup alarm must be after Primary alarm");
          }
        }

        this.backupAlarm = value;
        this.backupAlarmSet = true;

        // Fire AlarmChanged event 
        if( this.AlarmChanged != null ) {
          this.AlarmChanged(this, new AlarmChangedEventArgs(value));
        }

        this.Invalidate();
      }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool IsPrimaryAlarmSet {
      get { return this.primaryAlarmSet; }
    }

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool IsBackupAlarmSet {
      get { return this.backupAlarmSet; }
    }

    [Category("Behavior")]
    [Description("Stuff to remember for later.")]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
    public Collection<MessageToSelf> MessagesToSelf {
      get {
        if( this.messagesToSelf == null ) {
          this.messagesToSelf = new Collection<MessageToSelf>();
        }
        return this.messagesToSelf;
      }
      set { this.messagesToSelf = value; }
    }

    [Category("Behavior")]
    [Description("Sets the timezone difference from the current time.")]
    [DefaultValue(0)]
    [DisplayName("TimeZoneModifier")]
    public int GetTimeZoneModifier(Control extendee) {
      // Return component's timezone offset
      return Convert.ToInt32(this.timeZoneModifiers[extendee]);
    }
    public void SetTimeZoneModifier(Control extendee, object value) {
      // If property isn't provided
      if( value == null ) {
        // Remove it
        this.timeZoneModifiers.Remove(extendee);
        if( !this.DesignMode ) {
          extendee.Click -= this.extendee_Click;
        }
      }
      else {
        // Add the offset as an integer
        timeZoneModifiers[extendee] = Convert.ToInt32(value);
        if( !this.DesignMode ) {
          extendee.Click += this.extendee_Click;
        }
      }
    }

    [Category("Appearance")]
    [Description("Determines the clock face type to display.")]
    [DefaultValue(ClockFace.Both)]
    [Editor(typeof(FaceEditor), typeof(UITypeEditor))]
    public ClockFace Face {
      get { return this.face; }
      set {
        this.face = value;
        this.Invalidate();
      }
    }

    [Category("Appearance")]
    [Description("Sets the color and size of the Hour Hand.")]
    public Hand HourHand {
      get { return this.hourHand; }
      set {
        this.hourHand = value;
        this.Invalidate();
      }
    }
    private bool ShouldSerializeHourHand() {
      // Only serialize non-default values
      return ((this.hourHand.Color != Color.Black) || (this.hourHand.Width != 1));
    }
    private void ResetHourHand() {
      this.hourHand = new Hand(Color.Black, 1);
      this.Invalidate();
    }

    [Category("Appearance")]
    [Description("Sets the color and size of the Minute Hand.")]
    public Hand MinuteHand {
      get { return this.minuteHand; }
      set {
        this.minuteHand = value;
        this.Invalidate();
      }
    }
    private bool ShouldSerializeMinuteHand() {
      // Only serialize non-default values
      return ((this.minuteHand.Color != Color.Black) || (this.minuteHand.Width != 1));
    }
    private void ResetMinuteHand() {
      this.minuteHand = new Hand(Color.Black, 1);
      this.Invalidate();
    }

    [Category("Appearance")]
    [Description("Sets the color and size of the Second Hand.")]
    public Hand SecondHand {
      get { return this.secondHand; }
      set {
        this.secondHand = value;
        this.Invalidate();
      }
    }
    private bool ShouldSerializeSecondHand() {
      // Only serialize non-default values
      return ((this.secondHand.Color != Color.Red) || (this.secondHand.Width != 1));
    }
    private void ResetSecondHand() {
      this.secondHand = new Hand(Color.Red, 1);
      this.Invalidate();
    }

    [Category("Appearance")]
    [Description("The digital time format, constructed from .NET format specifiers.")]
    [DefaultValue("dd/MM/yyyy hh:mm:ss tt")]
    [Editor(typeof(DigitalTimeFormatEditor), typeof(UITypeEditor))]
    public string DigitalTimeFormat {
      get { return this.digitalTimeFormat; }
      set {
        this.digitalTimeFormat = value;
        this.Invalidate();
      }
    }

    [Category("Notification")]
    [Description("Fired when the Alarm property is changed.")]
    public event AlarmChangedEventHandler AlarmChanged;

    [Category("Notification")]
    [Description("Fired when the Alarm goes off.")]
    public event AlarmSoundedEventHandler AlarmSounded;

    [Category("Notification")]
    [Description("Fired when a message to self needs to be read.")]
    public event MessageNotificationEventHandler MessageNotification;

    public void DelayPrimaryAlarm(double minutes) {
      if( this.primaryAlarmSet ) {
        this.primaryAlarm = this.primaryAlarm.AddMinutes(minutes);
      }
    }
    public void DelaySecondaryAlarm(double minutes) {
      if( this.backupAlarmSet ) {
        this.backupAlarm = this.backupAlarm.AddMinutes(minutes);
      }
    }

    protected override void OnPaint(PaintEventArgs e) {

      Graphics g = e.Graphics;

      // Get specified date/time if control in design-time, 
      // or current date/time if control is in run-time
      DateTime now;
      if( this.DesignMode ) {
        // Get pretty date/time for design-time
        now = new DateTime(2002, 12, 31, 15, 00, 20, 0);
      }
      else {
        // Get current date/time and apply the time zone modifier
        now = DateTime.Now.AddHours(timeZoneModifier);
      }

      // Calculate required dimensions
      //Size faceSize = this.ClientRectangle.Size;
      Size faceSize = this.DisplayRectangle.Size;
      int xRadius = faceSize.Width / 2;
      int yRadius = faceSize.Height / 2;
      double degrees;
      int x;
      int y;

      // Make things pretty
      g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

      // Paint either Digital or Analog face
      using( Pen facePen = new Pen(Color.Black, 2) ) {
        if( face != ClockFace.Digital ) {
          g.DrawEllipse(facePen, facePen.Width + this.Padding.Left, facePen.Width + this.Padding.Top, faceSize.Width - facePen.Width * 2, faceSize.Height - facePen.Width * 2);
          using( SolidBrush faceBrush = new SolidBrush(Color.White) ) {
            g.FillEllipse(faceBrush, facePen.Width + this.Padding.Left, facePen.Width + this.Padding.Top, faceSize.Width - facePen.Width * 2, faceSize.Height - facePen.Width * 2);
          }
        }
        else {
          g.DrawRectangle(facePen, 1, 1, faceSize.Width + 1 - facePen.Width * 2, faceSize.Height + 1 - facePen.Width * 2);
          using( SolidBrush faceBrush = new SolidBrush(Color.White) ) {
            g.FillRectangle(faceBrush, 1 + this.Padding.Left, 1 + this.Padding.Top, faceSize.Width + 1 - facePen.Width * 2, faceSize.Height + 1 - facePen.Width * 2);
          }
        }
      }

      // Paint analog clock?
      if( face != ClockFace.Digital ) {
        // Hour hand
        using( Pen hourHandPen = new Pen(this.hourHand.Color, this.hourHand.Width) ) {
          degrees = (90.0 - ((now.Hour / 3.0) + (now.Minute / 180.0)) * 90.0) * (Math.PI / 180.0);
          x = (int)Math.Round((xRadius / 3.0) * Math.Cos(degrees));
          y = (int)-(Math.Round((yRadius / 3.0) * Math.Sin(degrees)));
          g.DrawLine(hourHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
        }

        // Minute hand
        using( Pen minuteHandPen = new Pen(this.minuteHand.Color, this.minuteHand.Width) ) {
          degrees = (90.0 - (now.Minute / 15.0) * 90.0) * (Math.PI / 180.0);
          x = (int)Math.Round((xRadius / 2.0) * Math.Cos(degrees));
          y = (int)-(Math.Round((yRadius / 2.0) * Math.Sin(degrees)));
          g.DrawLine(minuteHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
        }

        // Paint second hand, if so configured
        using( Pen secondHandPen = new Pen(this.secondHand.Color, this.secondHand.Width) ) {
          degrees = (90.0 - (now.Second / 15.0) * 90.0) * (Math.PI / 180.0);
          x = (int)Math.Round((2.0 * xRadius / 3.0) * Math.Cos(degrees));
          y = (int)-(Math.Round((2.0 * yRadius / 3.0) * Math.Sin(degrees)));
          g.DrawLine(secondHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
        }
      }

      // Paint clock text
      if( this.face != ClockFace.Analog ) {
        using( StringFormat format = new StringFormat() )
        using( Brush brush = new SolidBrush(this.ForeColor) ) {
          format.Alignment = StringAlignment.Center;
          string nowFormatted = now.ToString(this.digitalTimeFormat);
          SizeF size = g.MeasureString(nowFormatted, this.Font);
          // Paint digital time
          g.DrawString(nowFormatted, this.Font, brush, xRadius + this.Padding.Left, (yRadius * 1.6F) + this.Padding.Top, format);
        }
      }

      //// Calling the base class OnPaint
      //base.OnPaint(pe);
    }

    private void timer_Tick(object sender, EventArgs e) {

      // Don't do anything if executing at design-time
      //if( this.DesignMode ) return;

      // Refresh clock face
      this.Invalidate();

      // Check to see whether we're within 1 second of the primary alarm
      double primarySeconds = (DateTime.Now - this.primaryAlarm).TotalSeconds;
      if( (primarySeconds >= 0) && (primarySeconds <= 1) ) {
        DateTime alarm = this.primaryAlarm;
        this.primaryAlarm = DateTime.Now; // Reset alarm
        this.primaryAlarmSet = false; // Show alarm only once
        if( this.AlarmSounded != null ) {
          // Sound alarm asynch so clock can keep ticking
          this.AlarmSounded.BeginInvoke(this, new AlarmSoundedEventArgs(this.primaryAlarm, AlarmType.Primary), null, null);
        }
      }

      // Check to see whether we're within 1 second of the backup alarm
      double backupSeconds = (DateTime.Now - this.backupAlarm).TotalSeconds;
      if( (backupSeconds >= 0) && (backupSeconds <= 1) ) {
        DateTime alarm = this.backupAlarm;
        this.backupAlarm = DateTime.Now; // Reset alarm
        this.backupAlarmSet = false; // Show alarm only once
        if( this.AlarmSounded != null ) {
          // Sound alarm asynch so clock can keep ticking
          this.AlarmSounded.BeginInvoke(this, new AlarmSoundedEventArgs(this.backupAlarm, AlarmType.Backup), null, null);
        }
      }

      // Check to see whether we're within 1 second of any messages to self
      MessageToSelf msgToRemove = null;
      DateTime now = DateTime.Now;
      foreach( MessageToSelf msg in messagesToSelf ) {
        double msgSeconds = (now - msg.Occurence).TotalSeconds;
        if( (msgSeconds >= 0) && (msgSeconds <= 1) ) {
          if( this.AlarmSounded != null ) {
            // Send message asynch so clock can keep ticking
            this.MessageNotification.BeginInvoke(this, new MessageNotificationEventArgs(msg.Message), null, null);
          }
          break;
        }
      }
      if( msgToRemove != null ) messagesToSelf.Remove(msgToRemove);

    }

    private void extendee_Click(object sender, System.EventArgs e) {
      // Update the time-zone
      this.timeZoneModifier = this.GetTimeZoneModifier((Control)sender);
    }

    private void alarmClockControl_PaddingChanged(object sender, EventArgs e) {
      this.Invalidate();
    }
  }
}
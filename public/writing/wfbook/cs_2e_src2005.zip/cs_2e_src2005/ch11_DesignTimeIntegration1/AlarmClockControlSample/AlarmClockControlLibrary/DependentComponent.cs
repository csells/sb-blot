using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace AlarmClockControlLibrary {

  internal partial class DependentComponent : Component, ISupportInitialize {
    public DependentComponent() {
      InitializeComponent();
    }

    public DependentComponent(IContainer container) {
      container.Add(this);

      InitializeComponent();
    }

    private AlarmClockControl alarmClockControl;
    public AlarmClockControl AlarmClockControl {
      get { return alarmClockControl; }
      set { alarmClockControl = value; }
    }


    #region ISupportInitialize Members

    public void BeginInit() {}
    public void EndInit() {
      ISupportInitializeNotification notifier = this.alarmClockControl as ISupportInitializeNotification;
      // Is design-time component we�re depending on intialized?
      if( (notifier != null) && !notifier.IsInitialized ) {
        // If not, ask it to let us know when it does, so we
        // can complete our own initialization as per normal
      }
      else {
        // Initialize as per normal
      }
    }

    #endregion

    void notifier_Initialized(object sender, EventArgs e) {
      if( sender == this.alarmClockControl ) {
        // Initialize as per normal
      }
    }
  }
}

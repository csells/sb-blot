﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public enum ClockFace {
    Analog = 0,
    Digital = 1,
    Both = 2
  }
}

﻿#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace AlarmClockControlLibrary {
  public class MessageNotificationEventArgs {
    private string message;
    public MessageNotificationEventArgs(string message) {
      this.message = message;
    }
    public string Message {
      get { return this.message; }
    }
  }
}

﻿namespace TimerComponentSample {
  partial class AlarmForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.setAlarmButton = new System.Windows.Forms.Button();
      this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
      this.label1 = new System.Windows.Forms.Label();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
// 
// setAlarmButton
// 
      this.setAlarmButton.Location = new System.Drawing.Point(132, 36);
      this.setAlarmButton.Name = "setAlarmButton";
      this.setAlarmButton.TabIndex = 0;
      this.setAlarmButton.Text = "Set Alarm";
      this.setAlarmButton.Click += new System.EventHandler(this.setAlarmButton_Click);
// 
// dateTimePicker
// 
      this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker.Location = new System.Drawing.Point(57, 9);
      this.dateTimePicker.Name = "dateTimePicker";
      this.dateTimePicker.Size = new System.Drawing.Size(150, 20);
      this.dateTimePicker.TabIndex = 1;
// 
// label1
// 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(13, 13);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(37, 14);
      this.label1.TabIndex = 2;
      this.label1.Text = "When:";
// 
// timer
// 
      this.timer.Enabled = true;
      this.timer.Interval = 1000;
      this.timer.Tick += new System.EventHandler(this.timer_Tick);
// 
// TimerComponentSampleForm
// 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(224, 70);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.dateTimePicker);
      this.Controls.Add(this.setAlarmButton);
      this.Name = "TimerComponentSampleForm";
      this.Text = "Alarm Form";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button setAlarmButton;
    private System.Windows.Forms.DateTimePicker dateTimePicker;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Timer timer;
  }
}


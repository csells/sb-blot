﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace TimerComponentSample {
  partial class AlarmForm : Form {
    public AlarmForm() {
      InitializeComponent();

      //// Configure the Timer component
      //this.timer.Enabled = true;
      //this.timer.Interval = 1000;
      //this.timer.Tick += this.timer_Tick;
    }

    DateTime alarm = DateTime.MaxValue; // No alarm

    private void setAlarmButton_Click(object sender, EventArgs e) {
      alarm = this.dateTimePicker.Value;
    }

    private void timer_Tick(object sender, EventArgs e) {
      // Check to see whether we're within 1 second of the alarm
      double seconds = (DateTime.Now - alarm).TotalSeconds;
      if( (seconds >= 0) && (seconds <= 1) ) {
        this.alarm = DateTime.MaxValue; // Show alarm only once
        MessageBox.Show("Wake Up!");
      }
    }
  }
}
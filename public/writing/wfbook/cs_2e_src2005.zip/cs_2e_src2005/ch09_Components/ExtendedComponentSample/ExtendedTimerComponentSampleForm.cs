using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ExtendedComponentSample {
  public partial class AlarmComponentSampleForm : Form {
    public AlarmComponentSampleForm() {
      InitializeComponent();
    }

    private void setAlarmButton_Click(object sender, EventArgs e) {
      // Set alarm time
      this.AlarmComponent.Alarm = this.dateTimePicker.Value;
    }
  }
}
﻿#region Using directives

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows.Forms;
using System.Text;

#endregion

namespace ExtendedComponentSample {
  public partial class AlarmComponent : Timer {
    public AlarmComponent() {
      InitializeComponent();
    }

    public AlarmComponent(IContainer container) {
      container.Add(this);
      InitializeComponent();
    }

    // Alarm property
    DateTime alarm = DateTime.MaxValue; // No alarm
    public DateTime Alarm {
      get { return this.alarm; }
      set {
        this.alarm = value;
        // Enable timer for tenth of a second intervals
        this.Interval = 100;
        this.Enabled = true;
      }
    }

    protected override void OnTick(EventArgs e) {
      // Check to see whether we're within 1 second of the alarm
      double seconds = (DateTime.Now - this.alarm).TotalSeconds;
      if( (seconds >= 0) && (seconds <= 1) ) {
        this.alarm = DateTime.MaxValue; // Show alarm only once
        MessageBox.Show("Wake Up!");
        // Disable timer
        this.Enabled = false;
      }
    }
  }
}

﻿#region Using directives

using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

#endregion

namespace AlarmComponentSample {
  public partial class AlarmComponent : Component {

    DateTime alarm = DateTime.MaxValue; // No alarm

    public AlarmComponent() {
      InitializeComponent();
    }

    public AlarmComponent(IContainer container) {
      container.Add(this);
      InitializeComponent();
    }

    public DateTime Alarm {
      get { return this.alarm; }
      set { this.alarm = value; }
    }

    //public event EventHandler AlarmSounded;
    public event AlarmSoundedEventHandler AlarmSounded;

    void timer_Tick(object sender, System.EventArgs e) {
      // Check to see whether we're within 1 second of the alarm
      double seconds = (DateTime.Now - this.alarm).TotalSeconds;
      if( (seconds >= 0) && (seconds <= 1) ) {
        DateTime alarm = this.alarm;
        this.alarm = DateTime.MaxValue; // Show alarm only once
        if( this.AlarmSounded != null ) {
          AlarmSounded(this, new AlarmSoundedEventArgs(alarm));
        }
      }
    }

    public DateTime DelayAlarm(double minutes) {
      if( this.alarm < DateTime.MaxValue ) {
        this.alarm = this.alarm.AddMinutes(minutes);
      }
      return this.alarm;
    }
  }
}

using System;
using System.Collections.Generic;
using System.Text;

namespace AlarmComponentSample {
  // Custom AlarmSounded event handler
  public delegate void AlarmSoundedEventHandler(object sender, AlarmSoundedEventArgs e);
}

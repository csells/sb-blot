namespace AlarmComponentSample {
  partial class AlarmComponentForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.numericUpDown = new System.Windows.Forms.NumericUpDown();
      this.addMinutesButton = new System.Windows.Forms.Button();
      this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
      this.setAlarmButton = new System.Windows.Forms.Button();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // numericUpDown
      // 
      this.numericUpDown.Enabled = false;
      this.numericUpDown.Increment = new decimal(new int[] {
            15,
            0,
            0,
            0});
      this.numericUpDown.Location = new System.Drawing.Point(91, 45);
      this.numericUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
      this.numericUpDown.Name = "numericUpDown";
      this.numericUpDown.Size = new System.Drawing.Size(47, 20);
      this.numericUpDown.TabIndex = 7;
      this.numericUpDown.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
      // 
      // addMinutesButton
      // 
      this.addMinutesButton.Enabled = false;
      this.addMinutesButton.Location = new System.Drawing.Point(12, 43);
      this.addMinutesButton.Name = "addMinutesButton";
      this.addMinutesButton.Size = new System.Drawing.Size(75, 23);
      this.addMinutesButton.TabIndex = 6;
      this.addMinutesButton.Text = "Add Minutes";
      // 
      // dateTimePicker
      // 
      this.dateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker.Location = new System.Drawing.Point(91, 14);
      this.dateTimePicker.Name = "dateTimePicker";
      this.dateTimePicker.Size = new System.Drawing.Size(189, 20);
      this.dateTimePicker.TabIndex = 5;
      // 
      // setAlarmButton
      // 
      this.setAlarmButton.Location = new System.Drawing.Point(12, 12);
      this.setAlarmButton.Name = "setAlarmButton";
      this.setAlarmButton.Size = new System.Drawing.Size(75, 23);
      this.setAlarmButton.TabIndex = 4;
      this.setAlarmButton.Text = "Set Alarm";
      // 
      // Form1
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.numericUpDown);
      this.Controls.Add(this.addMinutesButton);
      this.Controls.Add(this.dateTimePicker);
      this.Controls.Add(this.setAlarmButton);
      this.Name = "Form1";
      this.Text = "Form1";
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.NumericUpDown numericUpDown;
    private System.Windows.Forms.Button addMinutesButton;
    private System.Windows.Forms.DateTimePicker dateTimePicker;
    private System.Windows.Forms.Button setAlarmButton;
  }
}


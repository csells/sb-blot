using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace AlarmComponentSample {
  public partial class AlarmComponentSampleForm : Form {
    public AlarmComponentSampleForm() {
      InitializeComponent();
    }

    private void setAlarmButton_Click(object sender, EventArgs e) {
      this.alarmComponent.Alarm = dateTimePicker.Value;
      this.delayAlarmButton.Enabled = true;
      this.numericUpDown.Enabled = true;
    }

    private void addMinutesButton_Click(object sender, EventArgs e) {
      double minutes = (double)this.numericUpDown.Value;
      DateTime newAlarm = this.alarmComponent.DelayAlarm(minutes);
      this.dateTimePicker.Value = newAlarm;
    }

    private void alarmComponent_AlarmSounded(object sender, AlarmSoundedEventArgs e) {
      MessageBox.Show("It's " + e.Alarm.ToString() + ". Wake up!");
    }
  }
}
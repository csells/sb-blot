namespace AlarmComponentSample {
  partial class AlarmComponentSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      this.numericUpDown = new System.Windows.Forms.NumericUpDown();
      this.delayAlarmButton = new System.Windows.Forms.Button();
      this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
      this.setAlarmButton = new System.Windows.Forms.Button();
      this.alarmComponent = new AlarmComponentSample.AlarmComponent(this.components);
      this.label1 = new System.Windows.Forms.Label();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // numericUpDown
      // 
      this.numericUpDown.Enabled = false;
      this.numericUpDown.Increment = new decimal(new int[] {
            15,
            0,
            0,
            0});
      this.numericUpDown.Location = new System.Drawing.Point(91, 45);
      this.numericUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
      this.numericUpDown.Name = "numericUpDown";
      this.numericUpDown.Size = new System.Drawing.Size(47, 20);
      this.numericUpDown.TabIndex = 7;
      this.numericUpDown.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
      // 
      // delayAlarmButton
      // 
      this.delayAlarmButton.Enabled = false;
      this.delayAlarmButton.Location = new System.Drawing.Point(12, 43);
      this.delayAlarmButton.Name = "delayAlarmButton";
      this.delayAlarmButton.Size = new System.Drawing.Size(75, 23);
      this.delayAlarmButton.TabIndex = 6;
      this.delayAlarmButton.Text = "Delay Alarm";
      // 
      // dateTimePicker
      // 
      this.dateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker.Location = new System.Drawing.Point(91, 14);
      this.dateTimePicker.Name = "dateTimePicker";
      this.dateTimePicker.Size = new System.Drawing.Size(189, 20);
      this.dateTimePicker.TabIndex = 5;
      // 
      // setAlarmButton
      // 
      this.setAlarmButton.Location = new System.Drawing.Point(12, 12);
      this.setAlarmButton.Name = "setAlarmButton";
      this.setAlarmButton.Size = new System.Drawing.Size(75, 23);
      this.setAlarmButton.TabIndex = 4;
      this.setAlarmButton.Text = "Set Alarm";
      this.setAlarmButton.Click += new System.EventHandler(this.setAlarmButton_Click);
      // 
      // alarmComponent
      // 
      this.alarmComponent.Alarm = new System.DateTime(2005, 5, 5, 16, 26, 0, 0);
      this.alarmComponent.AlarmSounded += new AlarmComponentSample.AlarmSoundedEventHandler(this.alarmComponent_AlarmSounded);
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(144, 48);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(43, 13);
      this.label1.TabIndex = 8;
      this.label1.Text = "minutes";
      // 
      // AlarmComponentSampleForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 80);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.numericUpDown);
      this.Controls.Add(this.delayAlarmButton);
      this.Controls.Add(this.dateTimePicker);
      this.Controls.Add(this.setAlarmButton);
      this.Name = "AlarmComponentSampleForm";
      this.Text = "AlarmComponent Sample";
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.NumericUpDown numericUpDown;
    private System.Windows.Forms.Button delayAlarmButton;
    private System.Windows.Forms.DateTimePicker dateTimePicker;
    private System.Windows.Forms.Button setAlarmButton;
    private AlarmComponent alarmComponent;
    private System.Windows.Forms.Label label1;
  }
}
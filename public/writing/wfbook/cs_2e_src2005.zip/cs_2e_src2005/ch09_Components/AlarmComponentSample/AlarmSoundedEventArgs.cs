using System;
using System.Collections.Generic;
using System.Text;

namespace AlarmComponentSample {
  // Custom AlarmSounded event arguments
  public class AlarmSoundedEventArgs : EventArgs {
    private DateTime alarm;
    public AlarmSoundedEventArgs(DateTime alarm) {
      this.alarm = alarm;
    }
    public DateTime Alarm {
      get { return this.alarm; }
    }
  }
}

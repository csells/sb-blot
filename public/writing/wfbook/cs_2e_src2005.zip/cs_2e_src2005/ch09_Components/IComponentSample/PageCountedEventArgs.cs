using System;
using System.Collections.Generic;
using System.Text;

namespace IComponentSample {
  public class PageCountedEventArgs {
    int pageNumber;
    public PageCountedEventArgs(int pageNumber) {
      this.pageNumber = pageNumber;
    }
    public int PageNumber {
      get { return this.pageNumber; }
    }
  }
}

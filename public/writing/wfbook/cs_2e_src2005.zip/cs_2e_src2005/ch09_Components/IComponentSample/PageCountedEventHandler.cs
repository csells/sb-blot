using System;
using System.Collections.Generic;
using System.Text;

namespace IComponentSample {
  public delegate void PageCountedEventHandler(object sender, PageCountedEventArgs e);
}

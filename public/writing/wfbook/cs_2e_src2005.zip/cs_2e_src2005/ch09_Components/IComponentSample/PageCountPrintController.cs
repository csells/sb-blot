using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;

namespace IComponentSample {

  public class PageCountPrintController : PreviewPrintController, IComponent {

    public PageCountPrintController() { }
    public PageCountPrintController(IContainer container) {
      container.Add(this);
    }

    #region PageCountPrintController implementation

    int pageCount;
    PrintDocument document;

    public event PageCountedEventHandler PageCounted;

    protected virtual void OnPageCounted(PageCountedEventArgs e) {
      if( this.PageCounted != null ) {
        this.PageCounted(this, e);
      }
    }

    [Category("Data")]
    [Description("The PrintDocument which needs a page count.")]
    public PrintDocument Document {
      get { return document; }
      set { document = value; }
    }

    public int PageCount() {
      // Must have a print document to generate page count
      if( document == null )
        throw new ArgumentNullException("PrintDocument must be set.");

      // Subsitute this PrintController to cause a Print to initiate the 
      // count, which means that OnStartPrint and OnStartPage are called 
      // as the PrintDocument prints
      PrintController existingController = document.PrintController;
      document.PrintController = this;
      document.Print();
      document.PrintController = existingController;
      return pageCount;
    }

    public override void OnStartPrint(
      PrintDocument document, PrintEventArgs e) {
      base.OnStartPrint(document, e);
      pageCount = 0;
    }

    public override Graphics OnStartPage(PrintDocument document, PrintPageEventArgs e) {
      // Increment page count
      pageCount++;
      OnPageCounted(new PageCountedEventArgs(pageCount));
      return base.OnStartPage(document, e);
    }

    #endregion

    #region IComponent

    private ISite site;

    public event EventHandler Disposed;

    [Browsable(false)]
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public ISite Site {
      get { return this.site; }
      set { this.site = value; }
    }

    #endregion

    #region IDisposable

    private bool disposed;

    //public void Dispose() {
    //  if( !this.disposed ) {
    //    // Release managed resources
    //    this.disposed = true;
    //    if( this.Disposed != null ) this.Disposed(this, EventArgs.Empty);
    //  }
    //}

    public void Dispose() {
      Dispose(true);

      // Prevent Finalize method from being called
      GC.SuppressFinalize(this);
    }

    // NOT CALLED IF COMPONENT IS DISPOSED ALREADY
    // Finalize method in C# is implemented using destructor syntax
    ~PageCountPrintController() {
      // Finalizer is called in case Dispose wasn't, although we
      // can only release native resources at this stage
      Dispose(false);
    }

    // Dispose managed and native resources
    protected virtual void Dispose(bool disposing) {
      if( !this.disposed ) {
        // If IDisposable.Dispose() was called
        if( disposing ) {
          // Release managed resources
        }
        // If IDisposable.Dispose() or finalizer were called
        // Release native resources

        // Only release resources once
        this.disposed = true;

        // Let interested parties know
        if( this.Disposed != null ) this.Disposed(this, EventArgs.Empty);
      }
    }

    #endregion
  }
}


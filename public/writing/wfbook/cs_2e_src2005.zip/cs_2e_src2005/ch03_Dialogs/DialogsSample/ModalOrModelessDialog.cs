﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace DialogsSample {
  partial class ModalOrModelessDialog : Form {
    public ModalOrModelessDialog() {
      InitializeComponent();
    }

    private void ModalOrModelessDialog_Load(object sender, EventArgs e) {
      if( this.Modal ) {
        // Show as a fixed-sized modal dialog
        this.FormBorderStyle = FormBorderStyle.FixedDialog;
        this.Text = "Modal, " + this.FormBorderStyle.ToString();
      }
      else {
        // Show as a sizeable modeless dialog
        this.FormBorderStyle = FormBorderStyle.Sizable;
        this.Text = "Modeless, " + this.FormBorderStyle.ToString();
      }
    }
  }
}
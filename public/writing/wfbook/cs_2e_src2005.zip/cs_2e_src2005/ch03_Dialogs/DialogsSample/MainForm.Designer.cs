﻿namespace DialogsSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.colorDialogButton = new System.Windows.Forms.Button();
      this.fontDialogButton = new System.Windows.Forms.Button();
      this.openFileDialogButton = new System.Windows.Forms.Button();
      this.pageSetupDialogButton = new System.Windows.Forms.Button();
      this.printDialogButton = new System.Windows.Forms.Button();
      this.printPreviewDialogButton = new System.Windows.Forms.Button();
      this.saveFileDialogButton = new System.Windows.Forms.Button();
      this.customDialogButton = new System.Windows.Forms.Button();
      this.folderBrowserDialogButton = new System.Windows.Forms.Button();
      this.colorDialog = new System.Windows.Forms.ColorDialog();
      this.fontDialog = new System.Windows.Forms.FontDialog();
      this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
      this.pageSetupDialog = new System.Windows.Forms.PageSetupDialog();
      this.printDialog = new System.Windows.Forms.PrintDialog();
      this.printPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
      this.saveFileDialog = new System.Windows.Forms.SaveFileDialog();
      this.folderBrowserDialog = new System.Windows.Forms.FolderBrowserDialog();
      this.modeCheckDialogButton = new System.Windows.Forms.Button();
      this.loadModalRadioButton = new System.Windows.Forms.RadioButton();
      this.loadModelessRadioButton = new System.Windows.Forms.RadioButton();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.loadMyDialogModalFixedRadioButton = new System.Windows.Forms.RadioButton();
      this.loadMyDialogModalRadioButton = new System.Windows.Forms.RadioButton();
      this.loadMyDialogModelessRadioButton = new System.Windows.Forms.RadioButton();
      this.showDialogPropertiesButton = new System.Windows.Forms.Button();
      this.menuStrip = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.menuStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // colorDialogButton
      // 
      this.colorDialogButton.Location = new System.Drawing.Point(12, 74);
      this.colorDialogButton.Name = "colorDialogButton";
      this.colorDialogButton.Size = new System.Drawing.Size(136, 23);
      this.colorDialogButton.TabIndex = 0;
      this.colorDialogButton.Text = "Color Dialog";
      this.colorDialogButton.Click += new System.EventHandler(this.colorDialogButton_Click);
      // 
      // fontDialogButton
      // 
      this.fontDialogButton.Location = new System.Drawing.Point(12, 104);
      this.fontDialogButton.Name = "fontDialogButton";
      this.fontDialogButton.Size = new System.Drawing.Size(136, 23);
      this.fontDialogButton.TabIndex = 1;
      this.fontDialogButton.Text = "Font Dialog";
      this.fontDialogButton.Click += new System.EventHandler(this.fontDialogButton_Click);
      // 
      // openFileDialogButton
      // 
      this.openFileDialogButton.Location = new System.Drawing.Point(12, 134);
      this.openFileDialogButton.Name = "openFileDialogButton";
      this.openFileDialogButton.Size = new System.Drawing.Size(136, 23);
      this.openFileDialogButton.TabIndex = 2;
      this.openFileDialogButton.Text = "Open File Dialog";
      this.openFileDialogButton.Click += new System.EventHandler(this.openFileDialogButton_Click);
      // 
      // pageSetupDialogButton
      // 
      this.pageSetupDialogButton.Location = new System.Drawing.Point(12, 164);
      this.pageSetupDialogButton.Name = "pageSetupDialogButton";
      this.pageSetupDialogButton.Size = new System.Drawing.Size(136, 23);
      this.pageSetupDialogButton.TabIndex = 3;
      this.pageSetupDialogButton.Text = "Page Setup Dialog";
      this.pageSetupDialogButton.Click += new System.EventHandler(this.pageSetupDialogButton_Click);
      // 
      // printDialogButton
      // 
      this.printDialogButton.Location = new System.Drawing.Point(12, 194);
      this.printDialogButton.Name = "printDialogButton";
      this.printDialogButton.Size = new System.Drawing.Size(136, 23);
      this.printDialogButton.TabIndex = 4;
      this.printDialogButton.Text = "Print Dialog";
      this.printDialogButton.Click += new System.EventHandler(this.printDialogButton_Click);
      // 
      // printPreviewDialogButton
      // 
      this.printPreviewDialogButton.Location = new System.Drawing.Point(12, 224);
      this.printPreviewDialogButton.Name = "printPreviewDialogButton";
      this.printPreviewDialogButton.Size = new System.Drawing.Size(136, 23);
      this.printPreviewDialogButton.TabIndex = 5;
      this.printPreviewDialogButton.Text = "Print Preview Dialog";
      this.printPreviewDialogButton.Click += new System.EventHandler(this.printPreviewDialogButton_Click);
      // 
      // saveFileDialogButton
      // 
      this.saveFileDialogButton.Location = new System.Drawing.Point(12, 254);
      this.saveFileDialogButton.Name = "saveFileDialogButton";
      this.saveFileDialogButton.Size = new System.Drawing.Size(136, 23);
      this.saveFileDialogButton.TabIndex = 6;
      this.saveFileDialogButton.Text = "Save File Dialog";
      this.saveFileDialogButton.Click += new System.EventHandler(this.saveFileDialogButton_Click);
      // 
      // customDialogButton
      // 
      this.customDialogButton.Location = new System.Drawing.Point(12, 313);
      this.customDialogButton.Name = "customDialogButton";
      this.customDialogButton.Size = new System.Drawing.Size(136, 23);
      this.customDialogButton.TabIndex = 8;
      this.customDialogButton.Text = "Custom Dialog";
      this.customDialogButton.Click += new System.EventHandler(this.customDialogButton_Click);
      // 
      // folderBrowserDialogButton
      // 
      this.folderBrowserDialogButton.Location = new System.Drawing.Point(12, 284);
      this.folderBrowserDialogButton.Name = "folderBrowserDialogButton";
      this.folderBrowserDialogButton.Size = new System.Drawing.Size(136, 23);
      this.folderBrowserDialogButton.TabIndex = 7;
      this.folderBrowserDialogButton.Text = "Folder Browser Dialog";
      this.folderBrowserDialogButton.Click += new System.EventHandler(this.folderBrowserDialogButton_Click);
      // 
      // colorDialog
      // 
      this.colorDialog.Color = System.Drawing.Color.Red;
      // 
      // printPreviewDialog
      // 
      this.printPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog.Enabled = true;
      this.printPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog.Icon")));
      this.printPreviewDialog.Name = "printPreviewDialog";
      this.printPreviewDialog.Visible = false;
      // 
      // modeCheckDialogButton
      // 
      this.modeCheckDialogButton.Location = new System.Drawing.Point(7, 51);
      this.modeCheckDialogButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
      this.modeCheckDialogButton.Name = "modeCheckDialogButton";
      this.modeCheckDialogButton.Size = new System.Drawing.Size(136, 23);
      this.modeCheckDialogButton.TabIndex = 2;
      this.modeCheckDialogButton.Text = "Mode Check Dialog";
      this.modeCheckDialogButton.Click += new System.EventHandler(this.modeCheckButton_Click);
      // 
      // loadModalRadioButton
      // 
      this.loadModalRadioButton.AutoSize = true;
      this.loadModalRadioButton.Checked = true;
      this.loadModalRadioButton.Location = new System.Drawing.Point(7, 14);
      this.loadModalRadioButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
      this.loadModalRadioButton.Name = "loadModalRadioButton";
      this.loadModalRadioButton.Size = new System.Drawing.Size(54, 17);
      this.loadModalRadioButton.TabIndex = 0;
      this.loadModalRadioButton.TabStop = true;
      this.loadModalRadioButton.Text = "Modal";
      // 
      // loadModelessRadioButton
      // 
      this.loadModelessRadioButton.AutoSize = true;
      this.loadModelessRadioButton.Location = new System.Drawing.Point(7, 32);
      this.loadModelessRadioButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
      this.loadModelessRadioButton.Name = "loadModelessRadioButton";
      this.loadModelessRadioButton.Size = new System.Drawing.Size(70, 17);
      this.loadModelessRadioButton.TabIndex = 1;
      this.loadModelessRadioButton.Text = "Modeless";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.loadModalRadioButton);
      this.groupBox1.Controls.Add(this.loadModelessRadioButton);
      this.groupBox1.Controls.Add(this.modeCheckDialogButton);
      this.groupBox1.Location = new System.Drawing.Point(164, 194);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(146, 80);
      this.groupBox1.TabIndex = 10;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Mode Check";
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.loadMyDialogModalFixedRadioButton);
      this.groupBox2.Controls.Add(this.loadMyDialogModalRadioButton);
      this.groupBox2.Controls.Add(this.loadMyDialogModelessRadioButton);
      this.groupBox2.Controls.Add(this.showDialogPropertiesButton);
      this.groupBox2.Location = new System.Drawing.Point(164, 74);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(146, 100);
      this.groupBox2.TabIndex = 9;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Dialog Properties";
      // 
      // loadMyDialogModalFixedRadioButton
      // 
      this.loadMyDialogModalFixedRadioButton.AutoSize = true;
      this.loadMyDialogModalFixedRadioButton.Location = new System.Drawing.Point(7, 51);
      this.loadMyDialogModalFixedRadioButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
      this.loadMyDialogModalFixedRadioButton.Name = "loadMyDialogModalFixedRadioButton";
      this.loadMyDialogModalFixedRadioButton.Size = new System.Drawing.Size(88, 17);
      this.loadMyDialogModalFixedRadioButton.TabIndex = 2;
      this.loadMyDialogModalFixedRadioButton.Text = "Modal - Fixed";
      // 
      // loadMyDialogModalRadioButton
      // 
      this.loadMyDialogModalRadioButton.AutoSize = true;
      this.loadMyDialogModalRadioButton.Location = new System.Drawing.Point(7, 34);
      this.loadMyDialogModalRadioButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 0);
      this.loadMyDialogModalRadioButton.Name = "loadMyDialogModalRadioButton";
      this.loadMyDialogModalRadioButton.Size = new System.Drawing.Size(54, 17);
      this.loadMyDialogModalRadioButton.TabIndex = 1;
      this.loadMyDialogModalRadioButton.Text = "Modal";
      // 
      // loadMyDialogModelessRadioButton
      // 
      this.loadMyDialogModelessRadioButton.AutoSize = true;
      this.loadMyDialogModelessRadioButton.Checked = true;
      this.loadMyDialogModelessRadioButton.Location = new System.Drawing.Point(7, 17);
      this.loadMyDialogModelessRadioButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 1);
      this.loadMyDialogModelessRadioButton.Name = "loadMyDialogModelessRadioButton";
      this.loadMyDialogModelessRadioButton.Size = new System.Drawing.Size(70, 17);
      this.loadMyDialogModelessRadioButton.TabIndex = 0;
      this.loadMyDialogModelessRadioButton.TabStop = true;
      this.loadMyDialogModelessRadioButton.Text = "Modeless";
      // 
      // showDialogPropertiesButton
      // 
      this.showDialogPropertiesButton.Location = new System.Drawing.Point(7, 71);
      this.showDialogPropertiesButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
      this.showDialogPropertiesButton.Name = "showDialogPropertiesButton";
      this.showDialogPropertiesButton.Size = new System.Drawing.Size(136, 23);
      this.showDialogPropertiesButton.TabIndex = 3;
      this.showDialogPropertiesButton.Text = "Show Dialog Properties";
      this.showDialogPropertiesButton.Click += new System.EventHandler(this.showDialogPropertiesButton_Click);
      // 
      // menuStrip
      // 
      this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
      this.menuStrip.Location = new System.Drawing.Point(0, 0);
      this.menuStrip.Name = "menuStrip";
      this.menuStrip.Size = new System.Drawing.Size(323, 24);
      this.menuStrip.TabIndex = 12;
      this.menuStrip.Text = "menuStrip";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Size = new System.Drawing.Size(35, 20);
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
      this.exitToolStripMenuItem.Text = "E&xit";
      this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(323, 377);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.colorDialogButton);
      this.Controls.Add(this.fontDialogButton);
      this.Controls.Add(this.openFileDialogButton);
      this.Controls.Add(this.pageSetupDialogButton);
      this.Controls.Add(this.printDialogButton);
      this.Controls.Add(this.printPreviewDialogButton);
      this.Controls.Add(this.saveFileDialogButton);
      this.Controls.Add(this.customDialogButton);
      this.Controls.Add(this.folderBrowserDialogButton);
      this.Controls.Add(this.menuStrip);
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.MainMenuStrip = this.menuStrip;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.Name = "MainForm";
      this.Text = "Dialogs Sample";
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      this.menuStrip.ResumeLayout(false);
      this.menuStrip.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button colorDialogButton;
    private System.Windows.Forms.Button fontDialogButton;
    private System.Windows.Forms.Button openFileDialogButton;
    private System.Windows.Forms.Button pageSetupDialogButton;
    private System.Windows.Forms.Button printDialogButton;
    private System.Windows.Forms.Button printPreviewDialogButton;
    private System.Windows.Forms.Button saveFileDialogButton;
    private System.Windows.Forms.Button customDialogButton;
    private System.Windows.Forms.Button folderBrowserDialogButton;
    private System.Windows.Forms.ColorDialog colorDialog;
    private System.Windows.Forms.FontDialog fontDialog;
    private System.Windows.Forms.OpenFileDialog openFileDialog;
    private System.Windows.Forms.PageSetupDialog pageSetupDialog;
    private System.Windows.Forms.PrintDialog printDialog;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog;
    private System.Windows.Forms.SaveFileDialog saveFileDialog;
    private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog;
    private System.Windows.Forms.Button modeCheckDialogButton;
    private System.Windows.Forms.RadioButton loadModalRadioButton;
    private System.Windows.Forms.RadioButton loadModelessRadioButton;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.RadioButton loadMyDialogModalFixedRadioButton;
    private System.Windows.Forms.RadioButton loadMyDialogModalRadioButton;
    private System.Windows.Forms.RadioButton loadMyDialogModelessRadioButton;
    private System.Windows.Forms.Button showDialogPropertiesButton;
    private System.Windows.Forms.MenuStrip menuStrip;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
  }
}


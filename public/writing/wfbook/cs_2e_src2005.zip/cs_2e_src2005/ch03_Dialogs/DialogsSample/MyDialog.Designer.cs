﻿namespace DialogsSample {
  partial class MyDialog {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.formBorderStyleLabel = new System.Windows.Forms.Label();
      this.controlBoxLabel = new System.Windows.Forms.Label();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.label6 = new System.Windows.Forms.Label();
      this.helpButtonLabel = new System.Windows.Forms.Label();
      this.minimizeBoxLabel = new System.Windows.Forms.Label();
      this.maximizeBoxLabel = new System.Windows.Forms.Label();
      this.showInTaskBarLabel = new System.Windows.Forms.Label();
      this.sizeGripStyleLabel = new System.Windows.Forms.Label();
      this.label8 = new System.Windows.Forms.Label();
      this.showIconLabel = new System.Windows.Forms.Label();
      this.label9 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // formBorderStyleLabel
      // 
      this.formBorderStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.formBorderStyleLabel.AutoSize = true;
      this.formBorderStyleLabel.Location = new System.Drawing.Point(104, 29);
      this.formBorderStyleLabel.Margin = new System.Windows.Forms.Padding(2);
      this.formBorderStyleLabel.Name = "formBorderStyleLabel";
      this.formBorderStyleLabel.Size = new System.Drawing.Size(35, 13);
      this.formBorderStyleLabel.TabIndex = 13;
      this.formBorderStyleLabel.Text = "label8";
      this.formBorderStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // controlBoxLabel
      // 
      this.controlBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.controlBoxLabel.AutoSize = true;
      this.controlBoxLabel.Location = new System.Drawing.Point(104, 12);
      this.controlBoxLabel.Margin = new System.Windows.Forms.Padding(2);
      this.controlBoxLabel.Name = "controlBoxLabel";
      this.controlBoxLabel.Size = new System.Drawing.Size(35, 13);
      this.controlBoxLabel.TabIndex = 10;
      this.controlBoxLabel.Text = "label7";
      this.controlBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(13, 12);
      this.label1.Margin = new System.Windows.Forms.Padding(2);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(61, 13);
      this.label1.TabIndex = 8;
      this.label1.Text = "ControlBox:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(13, 29);
      this.label2.Margin = new System.Windows.Forms.Padding(2);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(87, 13);
      this.label2.TabIndex = 9;
      this.label2.Text = "FormBorderStyle:";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label3
      // 
      this.label3.AutoSize = true;
      this.label3.Location = new System.Drawing.Point(13, 46);
      this.label3.Margin = new System.Windows.Forms.Padding(2);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(63, 13);
      this.label3.TabIndex = 7;
      this.label3.Text = "HelpButton:";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(13, 63);
      this.label4.Margin = new System.Windows.Forms.Padding(2);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(68, 13);
      this.label4.TabIndex = 4;
      this.label4.Text = "MinimizeBox:";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(14, 80);
      this.label5.Margin = new System.Windows.Forms.Padding(2);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(71, 13);
      this.label5.TabIndex = 3;
      this.label5.Text = "MaximizeBox:";
      this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.Location = new System.Drawing.Point(14, 97);
      this.label6.Margin = new System.Windows.Forms.Padding(2);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(86, 13);
      this.label6.TabIndex = 6;
      this.label6.Text = "ShowInTaskBar:";
      this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // helpButtonLabel
      // 
      this.helpButtonLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.helpButtonLabel.AutoSize = true;
      this.helpButtonLabel.Location = new System.Drawing.Point(104, 46);
      this.helpButtonLabel.Margin = new System.Windows.Forms.Padding(2);
      this.helpButtonLabel.Name = "helpButtonLabel";
      this.helpButtonLabel.Size = new System.Drawing.Size(35, 13);
      this.helpButtonLabel.TabIndex = 14;
      this.helpButtonLabel.Text = "label8";
      this.helpButtonLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // minimizeBoxLabel
      // 
      this.minimizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.minimizeBoxLabel.AutoSize = true;
      this.minimizeBoxLabel.Location = new System.Drawing.Point(104, 63);
      this.minimizeBoxLabel.Margin = new System.Windows.Forms.Padding(2);
      this.minimizeBoxLabel.Name = "minimizeBoxLabel";
      this.minimizeBoxLabel.Size = new System.Drawing.Size(35, 13);
      this.minimizeBoxLabel.TabIndex = 15;
      this.minimizeBoxLabel.Text = "label8";
      this.minimizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // maximizeBoxLabel
      // 
      this.maximizeBoxLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.maximizeBoxLabel.AutoSize = true;
      this.maximizeBoxLabel.Location = new System.Drawing.Point(104, 80);
      this.maximizeBoxLabel.Margin = new System.Windows.Forms.Padding(2);
      this.maximizeBoxLabel.Name = "maximizeBoxLabel";
      this.maximizeBoxLabel.Size = new System.Drawing.Size(35, 13);
      this.maximizeBoxLabel.TabIndex = 16;
      this.maximizeBoxLabel.Text = "label8";
      this.maximizeBoxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // showInTaskBarLabel
      // 
      this.showInTaskBarLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.showInTaskBarLabel.AutoSize = true;
      this.showInTaskBarLabel.Location = new System.Drawing.Point(104, 97);
      this.showInTaskBarLabel.Margin = new System.Windows.Forms.Padding(2);
      this.showInTaskBarLabel.Name = "showInTaskBarLabel";
      this.showInTaskBarLabel.Size = new System.Drawing.Size(35, 13);
      this.showInTaskBarLabel.TabIndex = 11;
      this.showInTaskBarLabel.Text = "label8";
      this.showInTaskBarLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // sizeGripStyleLabel
      // 
      this.sizeGripStyleLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.sizeGripStyleLabel.AutoSize = true;
      this.sizeGripStyleLabel.Location = new System.Drawing.Point(104, 131);
      this.sizeGripStyleLabel.Margin = new System.Windows.Forms.Padding(2);
      this.sizeGripStyleLabel.Name = "sizeGripStyleLabel";
      this.sizeGripStyleLabel.Size = new System.Drawing.Size(35, 13);
      this.sizeGripStyleLabel.TabIndex = 12;
      this.sizeGripStyleLabel.Text = "label8";
      this.sizeGripStyleLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label8
      // 
      this.label8.AutoSize = true;
      this.label8.Location = new System.Drawing.Point(14, 131);
      this.label8.Margin = new System.Windows.Forms.Padding(2);
      this.label8.Name = "label8";
      this.label8.Size = new System.Drawing.Size(72, 13);
      this.label8.TabIndex = 5;
      this.label8.Text = "SizeGripStyle:";
      this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // showIconLabel
      // 
      this.showIconLabel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.showIconLabel.AutoSize = true;
      this.showIconLabel.Location = new System.Drawing.Point(104, 114);
      this.showIconLabel.Margin = new System.Windows.Forms.Padding(2);
      this.showIconLabel.Name = "showIconLabel";
      this.showIconLabel.Size = new System.Drawing.Size(35, 13);
      this.showIconLabel.TabIndex = 18;
      this.showIconLabel.Text = "label8";
      this.showIconLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label9
      // 
      this.label9.AutoSize = true;
      this.label9.Location = new System.Drawing.Point(13, 114);
      this.label9.Margin = new System.Windows.Forms.Padding(2);
      this.label9.Name = "label9";
      this.label9.Size = new System.Drawing.Size(58, 13);
      this.label9.TabIndex = 17;
      this.label9.Text = "ShowIcon:";
      this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // MyDialog
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoSize = true;
      this.ClientSize = new System.Drawing.Size(198, 154);
      this.Controls.Add(this.showIconLabel);
      this.Controls.Add(this.label9);
      this.Controls.Add(this.formBorderStyleLabel);
      this.Controls.Add(this.controlBoxLabel);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label3);
      this.Controls.Add(this.label4);
      this.Controls.Add(this.label5);
      this.Controls.Add(this.label6);
      this.Controls.Add(this.helpButtonLabel);
      this.Controls.Add(this.minimizeBoxLabel);
      this.Controls.Add(this.maximizeBoxLabel);
      this.Controls.Add(this.showInTaskBarLabel);
      this.Controls.Add(this.sizeGripStyleLabel);
      this.Controls.Add(this.label8);
      this.Name = "MyDialog";
      this.Text = "MyDialog";
      this.Load += new System.EventHandler(this.MyDialog_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label formBorderStyleLabel;
    private System.Windows.Forms.Label controlBoxLabel;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label helpButtonLabel;
    private System.Windows.Forms.Label minimizeBoxLabel;
    private System.Windows.Forms.Label maximizeBoxLabel;
    private System.Windows.Forms.Label showInTaskBarLabel;
    private System.Windows.Forms.Label sizeGripStyleLabel;
    private System.Windows.Forms.Label label8;
    private System.Windows.Forms.Label showIconLabel;
    private System.Windows.Forms.Label label9;
  }
}
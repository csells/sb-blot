﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace DialogsSample {
  partial class MyDialog : Form {
    public MyDialog() {
      InitializeComponent();
    }

    private void MyDialog_Load(object sender, EventArgs e) {
      controlBoxLabel.Text = this.ControlBox.ToString();
      formBorderStyleLabel.Text = this.FormBorderStyle.ToString();
      helpButtonLabel.Text = this.HelpButton.ToString();
      maximizeBoxLabel.Text = this.MaximizeBox.ToString();
      minimizeBoxLabel.Text = this.MinimizeBox.ToString();
      showInTaskBarLabel.Text = this.ShowInTaskbar.ToString();
      showIconLabel.Text = this.ShowIcon.ToString();
      sizeGripStyleLabel.Text = this.SizeGripStyle.ToString();
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

#endregion

namespace DialogsSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void colorDialogButton_Click(object sender, EventArgs e) {
//      ColorDialog dlg = new ColorDialog();
//      dlg.Color = Color.Red;
//      DialogResult result = dlg.ShowDialog();
//      if( result == DialogResult.OK ) {
//        MessageBox.Show("You picked " + dlg.Color.ToString(), "Color Picked");
//      }

      DialogResult result = colorDialog.ShowDialog();
      if( result == DialogResult.OK ) {
        MessageBox.Show("You picked " + colorDialog.Color.ToString(), "Color Picked");
      }
    }

    private void fontDialogButton_Click(object sender, EventArgs e) {
      fontDialog.ShowDialog();
    }

    private void openFileDialogButton_Click(object sender, EventArgs e) {
//      openFileDialog.ShowDialog();
      OpenFileDialog dlg = new OpenFileDialog();
      DialogResult result = dlg.ShowDialog();
      if( result == DialogResult.OK ) {
        MessageBox.Show("You picked: " + dlg.FileName);
      }
    }

    private void pageSetupDialogButton_Click(object sender, EventArgs e) {
      pageSetupDialog.ShowDialog();
    }

    private void printDialogButton_Click(object sender, EventArgs e) {
      printDialog.ShowDialog();
    }

    private void printPreviewDialogButton_Click(object sender, EventArgs e) {
      printPreviewDialog.ShowDialog();
    }

    private void saveFileDialogButton_Click(object sender, EventArgs e) {
      saveFileDialog.ShowDialog();
    }

    private void folderBrowserDialogButton_Click(object sender, EventArgs e) {
      folderBrowserDialog.ShowDialog();
    }

    private void customDialogButton_Click(object sender, EventArgs e) {

//      MyDialog dlg = new MyDialog();
//
//      // Show as main window
//      dlg.Text = "My Main Window";
//      dlg.Show();
//
//      // Show a sizeble modal dialog
//      dlg.Text = "My Sizeable Modal Dialog";
//      dlg.HelpButton = true;
//      dlg.MinimizeBox = false;
//      dlg.MaximizeBox = false;
//      dlg.ShowInTaskbar = false;
//      dlg.ShowDialog();
//
//      // Show as a fixed-sized modal dialog
//      dlg.Text = "My Fixed-Size Modal Dialog";
//      dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
//      dlg.HelpButton = true;
//      dlg.MinimizeBox = false;
//      dlg.MaximizeBox = false;
//      dlg.ShowInTaskbar = false;
//      dlg.ShowDialog();
//
//      // Show as a sizeable modeless dialog
//      dlg.Text = "My Sizeable Modeless Dialog";
//      dlg.HelpButton = true;
//      dlg.MinimizeBox = false;
//      dlg.MaximizeBox = false;
//      dlg.ShowInTaskbar = false;
//      dlg.Show();
//
//      // Show as a sizeable modeless dialog
//      dlg.Text = "My Fixed-Size Modeless Toolbox";
//      dlg.HelpButton = true;
//      dlg.MinimizeBox = false;
//      dlg.MaximizeBox = false;
//      dlg.ShowInTaskbar = false;
//      dlg.FormBorderStyle = FormBorderStyle.FixedToolWindow;
//      dlg.Show();

      LoanApplicationDialog dlg = new LoanApplicationDialog();
      dlg.ApplicantName = "Joe Borrower";
      dlg.ShowDialog();
      DialogResult result = dlg.DialogResult;
      if( result == DialogResult.OK ) {
        string msg = string.Format("{0}\n{1}\n{2}\n\nApproved!",
                                   "Name: " + dlg.ApplicantName,
                                   "Phone #: " + dlg.ApplicantPhoneNumber,
                                   "Amount: " + dlg.ApplicantLoanAmount);
        MessageBox.Show(msg, "Loan Application Request");
      }
    }

    private void modeCheckButton_Click(object sender, EventArgs e) {
      ModalOrModelessDialog dlg = new ModalOrModelessDialog();
      if( this.loadModalRadioButton.Checked ) {
        dlg.ShowDialog();
      }
      else {
        dlg.Show();
      }
    }

    private void showDialogPropertiesButton_Click(object sender, EventArgs e) {
      MyDialog dlg = new MyDialog();
      
      // Show modeless?
      if( this.loadMyDialogModelessRadioButton.Checked ) {
        dlg.Text = "My Main Window";
        dlg.Show();
        return;
      }
      
      // Dialogs don't do this:
      dlg.HelpButton = true;
      dlg.MinimizeBox = false;
      dlg.MaximizeBox = false;
      dlg.ShowInTaskbar = false;
      
      // Show modal?
      if( this.loadMyDialogModalRadioButton.Checked ) {
        dlg.Text = "My Sizeable Modal Dialog";
        dlg.ShowIcon = false;
        dlg.ShowDialog();
        return;
      }
      
      // Show modal and fixed
      dlg.Text = "My Fixed Modal Dialog";
      dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
      dlg.ShowDialog();
    }

    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }
  }
}
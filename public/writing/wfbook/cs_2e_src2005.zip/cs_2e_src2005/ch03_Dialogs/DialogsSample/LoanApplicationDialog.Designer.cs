﻿namespace DialogsSample {
  partial class LoanApplicationDialog {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LoanApplicationDialog));
      this.applicantLoanAmountTextBox = new System.Windows.Forms.TextBox();
      this.label1 = new System.Windows.Forms.Label();
      this.applicantPhoneNoTextBox = new System.Windows.Forms.TextBox();
      this.applicantNameTextBox = new System.Windows.Forms.TextBox();
      this.label2 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.okButton = new System.Windows.Forms.Button();
      this.cancelButton = new System.Windows.Forms.Button();
      this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
      this.splitGroupBox = new System.Windows.Forms.GroupBox();
      this.secondNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.firstNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.label5 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.toolTip = new System.Windows.Forms.ToolTip(this.components);
      this.infoProvider = new System.Windows.Forms.ErrorProvider(this.components);
      this.helpProvider = new System.Windows.Forms.HelpProvider();
      ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
      this.splitGroupBox.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.secondNumericUpDown)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.firstNumericUpDown)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.infoProvider)).BeginInit();
      this.SuspendLayout();
      // 
      // applicantLoanAmountTextBox
      // 
      this.applicantLoanAmountTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.helpProvider.SetHelpKeyword(this.applicantLoanAmountTextBox, "loanApplicationDialog.htm#loanAmount");
      this.helpProvider.SetHelpNavigator(this.applicantLoanAmountTextBox, System.Windows.Forms.HelpNavigator.Topic);
      this.helpProvider.SetHelpString(this.applicantLoanAmountTextBox, "Please enter a valid loan amount: x.xx");
      this.infoProvider.SetIconPadding(this.applicantLoanAmountTextBox, 2);
      this.errorProvider.SetIconPadding(this.applicantLoanAmountTextBox, 2);
      this.applicantLoanAmountTextBox.Location = new System.Drawing.Point(120, 70);
      this.applicantLoanAmountTextBox.Name = "applicantLoanAmountTextBox";
      this.helpProvider.SetShowHelp(this.applicantLoanAmountTextBox, true);
      this.applicantLoanAmountTextBox.Size = new System.Drawing.Size(223, 20);
      this.applicantLoanAmountTextBox.TabIndex = 5;
      this.toolTip.SetToolTip(this.applicantLoanAmountTextBox, "Please enter a valid loan amount: x.xx");
      this.applicantLoanAmountTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantLoanAmountTextBox_Validating);
      // 
      // label1
      // 
      this.label1.Location = new System.Drawing.Point(13, 12);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(101, 23);
      this.label1.TabIndex = 0;
      this.label1.Text = "Applicant Name:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // applicantPhoneNoTextBox
      // 
      this.applicantPhoneNoTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.helpProvider.SetHelpKeyword(this.applicantPhoneNoTextBox, "loanApplicationDialog.htm#phoneNo");
      this.helpProvider.SetHelpNavigator(this.applicantPhoneNoTextBox, System.Windows.Forms.HelpNavigator.Topic);
      this.helpProvider.SetHelpString(this.applicantPhoneNoTextBox, "Please enter an Australian phone number: (xx) xxxx-xxxx");
      this.errorProvider.SetIconPadding(this.applicantPhoneNoTextBox, 2);
      this.infoProvider.SetIconPadding(this.applicantPhoneNoTextBox, 2);
      this.applicantPhoneNoTextBox.Location = new System.Drawing.Point(120, 42);
      this.applicantPhoneNoTextBox.Name = "applicantPhoneNoTextBox";
      this.helpProvider.SetShowHelp(this.applicantPhoneNoTextBox, true);
      this.applicantPhoneNoTextBox.Size = new System.Drawing.Size(223, 20);
      this.applicantPhoneNoTextBox.TabIndex = 3;
      this.toolTip.SetToolTip(this.applicantPhoneNoTextBox, "Please enter an Australian phone number: (xx) xxxx-xxxx");
      this.applicantPhoneNoTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantPhoneNoTextBox_Validating);
      // 
      // applicantNameTextBox
      // 
      this.applicantNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.helpProvider.SetHelpKeyword(this.applicantNameTextBox, "loanApplicationDialog.htm#name");
      this.helpProvider.SetHelpNavigator(this.applicantNameTextBox, System.Windows.Forms.HelpNavigator.Topic);
      this.helpProvider.SetHelpString(this.applicantNameTextBox, "Please enter a name");
      this.errorProvider.SetIconPadding(this.applicantNameTextBox, 2);
      this.infoProvider.SetIconPadding(this.applicantNameTextBox, 2);
      this.applicantNameTextBox.Location = new System.Drawing.Point(120, 12);
      this.applicantNameTextBox.Margin = new System.Windows.Forms.Padding(3, 3, 5, 3);
      this.applicantNameTextBox.Name = "applicantNameTextBox";
      this.helpProvider.SetShowHelp(this.applicantNameTextBox, true);
      this.applicantNameTextBox.Size = new System.Drawing.Size(223, 20);
      this.applicantNameTextBox.TabIndex = 1;
      this.toolTip.SetToolTip(this.applicantNameTextBox, "Please enter a name");
      this.applicantNameTextBox.Validated += new System.EventHandler(this.applicantNameTextBox_Validated);
      this.applicantNameTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantNameTextBox_Validating);
      // 
      // label2
      // 
      this.label2.Location = new System.Drawing.Point(13, 41);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(101, 23);
      this.label2.TabIndex = 2;
      this.label2.Text = "Applicant Phone #:";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // label3
      // 
      this.label3.Location = new System.Drawing.Point(13, 70);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(101, 23);
      this.label3.TabIndex = 4;
      this.label3.Text = "Loan Amount:";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // okButton
      // 
      this.okButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.okButton.DialogResult = System.Windows.Forms.DialogResult.OK;
      this.okButton.Location = new System.Drawing.Point(186, 155);
      this.okButton.Name = "okButton";
      this.okButton.Size = new System.Drawing.Size(75, 23);
      this.okButton.TabIndex = 7;
      this.okButton.Text = "OK";
      this.okButton.Click += new System.EventHandler(this.okButton_Click);
      // 
      // cancelButton
      // 
      this.cancelButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.cancelButton.CausesValidation = false;
      this.cancelButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
      this.cancelButton.Location = new System.Drawing.Point(268, 155);
      this.cancelButton.Name = "cancelButton";
      this.cancelButton.Size = new System.Drawing.Size(75, 23);
      this.cancelButton.TabIndex = 8;
      this.cancelButton.Text = "Cancel";
      // 
      // errorProvider
      // 
      this.errorProvider.ContainerControl = this;
      // 
      // splitGroupBox
      // 
      this.splitGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.splitGroupBox.Controls.Add(this.secondNumericUpDown);
      this.splitGroupBox.Controls.Add(this.firstNumericUpDown);
      this.splitGroupBox.Controls.Add(this.label5);
      this.splitGroupBox.Controls.Add(this.label4);
      this.infoProvider.SetIconPadding(this.splitGroupBox, 2);
      this.errorProvider.SetIconPadding(this.splitGroupBox, 2);
      this.splitGroupBox.Location = new System.Drawing.Point(12, 96);
      this.splitGroupBox.Name = "splitGroupBox";
      this.splitGroupBox.Size = new System.Drawing.Size(331, 43);
      this.splitGroupBox.TabIndex = 6;
      this.splitGroupBox.TabStop = false;
      this.splitGroupBox.Text = "% Loan Repayment";
      this.toolTip.SetToolTip(this.splitGroupBox, "First and second repayments must add up to 100%.");
      this.splitGroupBox.Validating += new System.ComponentModel.CancelEventHandler(this.applicantLoanAmountRepaymentGroupBox_Validating);
      // 
      // secondNumericUpDown
      // 
      this.secondNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.helpProvider.SetHelpKeyword(this.secondNumericUpDown, "loanApplicationDialog.htm#secondrepaymentpercent");
      this.helpProvider.SetHelpNavigator(this.secondNumericUpDown, System.Windows.Forms.HelpNavigator.Topic);
      this.helpProvider.SetHelpString(this.secondNumericUpDown, "Please enter a % of the loan amount to repay second");
      this.secondNumericUpDown.Location = new System.Drawing.Point(282, 16);
      this.secondNumericUpDown.Name = "secondNumericUpDown";
      this.helpProvider.SetShowHelp(this.secondNumericUpDown, true);
      this.secondNumericUpDown.Size = new System.Drawing.Size(43, 20);
      this.secondNumericUpDown.TabIndex = 3;
      this.toolTip.SetToolTip(this.secondNumericUpDown, "Please enter a % of the loan amount to repay second");
      // 
      // firstNumericUpDown
      // 
      this.helpProvider.SetHelpKeyword(this.firstNumericUpDown, "loanApplicationDialog.htm#firstrepaymentpercent");
      this.helpProvider.SetHelpNavigator(this.firstNumericUpDown, System.Windows.Forms.HelpNavigator.Topic);
      this.helpProvider.SetHelpString(this.firstNumericUpDown, "Please enter a % of the loan amount to repay first");
      this.firstNumericUpDown.Location = new System.Drawing.Point(110, 16);
      this.firstNumericUpDown.Name = "firstNumericUpDown";
      this.helpProvider.SetShowHelp(this.firstNumericUpDown, true);
      this.firstNumericUpDown.Size = new System.Drawing.Size(43, 20);
      this.firstNumericUpDown.TabIndex = 1;
      this.toolTip.SetToolTip(this.firstNumericUpDown, "Please enter a % of the loan amount to repay first");
      // 
      // label5
      // 
      this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label5.AutoSize = true;
      this.label5.Location = new System.Drawing.Point(171, 18);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(105, 13);
      this.label5.TabIndex = 2;
      this.label5.Text = "2nd Repayment  (%):";
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.Location = new System.Drawing.Point(6, 18);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(98, 13);
      this.label4.TabIndex = 0;
      this.label4.Text = "1st Repayment (%):";
      // 
      // toolTip
      // 
      this.toolTip.IsBalloon = true;
      this.toolTip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
      this.toolTip.ToolTipTitle = "Loan Application";
      // 
      // infoProvider
      // 
      this.infoProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
      this.infoProvider.ContainerControl = this;
      this.infoProvider.Icon = ((System.Drawing.Icon)(resources.GetObject("infoProvider.Icon")));
      // 
      // helpProvider
      // 
      this.helpProvider.HelpNamespace = "dialogs.chm";
      // 
      // LoanApplicationDialog
      // 
      this.AcceptButton = this.okButton;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
      this.CancelButton = this.cancelButton;
      this.ClientSize = new System.Drawing.Size(371, 190);
      this.Controls.Add(this.splitGroupBox);
      this.Controls.Add(this.applicantNameTextBox);
      this.Controls.Add(this.cancelButton);
      this.Controls.Add(this.okButton);
      this.Controls.Add(this.applicantLoanAmountTextBox);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.applicantPhoneNoTextBox);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label3);
      this.HelpButton = true;
      this.MaximizeBox = false;
      this.MinimizeBox = false;
      this.MinimumSize = new System.Drawing.Size(379, 224);
      this.Name = "LoanApplicationDialog";
      this.ShowInTaskbar = false;
      this.Text = "Loan Application";
      this.HelpButtonClicked += new System.ComponentModel.CancelEventHandler(this.LoanApplicationDialog_HelpButtonClicked);
      this.HelpRequested += new System.Windows.Forms.HelpEventHandler(this.LoanApplicationDialog_HelpRequested);
      this.Load += new System.EventHandler(this.LoanApplicationDialog_Load);
      ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
      this.splitGroupBox.ResumeLayout(false);
      this.splitGroupBox.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.secondNumericUpDown)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.firstNumericUpDown)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.infoProvider)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.TextBox applicantLoanAmountTextBox;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.TextBox applicantPhoneNoTextBox;
    private System.Windows.Forms.TextBox applicantNameTextBox;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Button okButton;
    private System.Windows.Forms.Button cancelButton;
    private System.Windows.Forms.ErrorProvider errorProvider;
    private System.Windows.Forms.ToolTip toolTip;
    private System.Windows.Forms.ErrorProvider infoProvider;
    private System.Windows.Forms.GroupBox splitGroupBox;
    private System.Windows.Forms.NumericUpDown secondNumericUpDown;
    private System.Windows.Forms.NumericUpDown firstNumericUpDown;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.HelpProvider helpProvider;
  }
}
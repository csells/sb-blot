﻿#region Using directives

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

#endregion

namespace DialogsSample {
  partial class LoanApplicationDialog : Form {
    public LoanApplicationDialog() {
      InitializeComponent();
    }

    private Regex rgxOzPhone = new Regex(@"^\(\d{2}\) \d{4}-\d{4}$");
    private Regex rgxLoanAmount = new Regex(@"^\$+\d{1,}.\d{2}$");

    public string ApplicantName {
      get { return this.applicantNameTextBox.Text; }
      set { this.applicantNameTextBox.Text = value; }
    }

    public string ApplicantPhoneNumber {
      get { return this.applicantPhoneNoTextBox.Text; }
      set { this.applicantPhoneNoTextBox.Text = value; }
    }

    public string ApplicantLoanAmount {
      get { return this.applicantLoanAmountTextBox.Text; }
      set { this.applicantLoanAmountTextBox.Text = value; }
    }

    private void LoanApplicationDialog_Load(object sender, EventArgs e) {
      // Use tooltips to populate the "information provider"
      foreach( Control control in this.Controls ) {
        string toolTip = this.toolTip.GetToolTip(control);
        if( toolTip.Length == 0 ) continue;
        this.infoProvider.SetError(control, toolTip);
      }

      // Set current Path directory to help folder
      // Only needed if help file not in same folder as executing assembly
      if( !Environment.CurrentDirectory.ToLower().EndsWith(@"\help") ) {
        Environment.CurrentDirectory = Path.Combine(Environment.CurrentDirectory, @"..\..\help");
      }
    }

    private void okButton_Click(object sender, EventArgs e) {
      //      this.DialogResult = DialogResult.OK;
      //      this.Close();
      if( !this.Validate() ) {
        this.DialogResult = DialogResult.None;
      }

      if( !this.ValidateChildren(ValidationConstraints.Selectable) ) {
        this.DialogResult = DialogResult.None;
      }

    }

    //    private void cancelButton_Click(object sender, EventArgs e) {
    //      // Close will seet the DialogResult to Cancel, so setting
    //      // it explicitly is just good manners
    //      this.DialogResult = DialogResult.Cancel;
    //      this.Close();
    //    }

    private void applicantNameTextBox_Validating(object sender, CancelEventArgs e) {
      //      // Check that applicant name exists
      //      string error = null;
      //      if( ((Control)sender).Text.Trim().Length == 0 ) {
      ////        MessageBox.Show("Please enter a name", "Error");
      //        error = "Please enter a name";
      //        e.Cancel = true;
      //      }
      //      this.errorProvider.SetError((Control)sender, error);

      //      string toolTip = this.toolTip.GetToolTip((Control)sender);
      //      if( string.IsNullOrEmpty(((Control)sender).Text) ) {
      //        // Show the error when there is no text in the text box
      //        this.errorProvider.SetError((Control)sender, toolTip);
      //        this.infoProvider.SetError((Control)sender, null);
      //        e.Cancel = true;
      //      }
      //      else {
      //        // Show the info when there is text in the text box
      //        this.errorProvider.SetError((Control)sender, null);
      //        this.infoProvider.SetError((Control)sender, toolTip);
      //      }
      UpdateErrorStatus(((Control)sender).Text.Trim().Length != 0, (Control)sender, e);
    }
    private void applicantNameTextBox_Validated(object sender, EventArgs e) {
      //      MessageBox.Show("Thanks, " + applicantNameTextBox.Text, "Nice Name!");
    }
    private void applicantPhoneNoTextBox_Validating(object sender, CancelEventArgs e) {
      //      string error = null;
      //      // Check that a valid Australian application phone exists
      //      if( !rgxOzPhone.IsMatch(( (Control)sender ).Text) ) {
      //        error = "Please enter an Australian phone number: (xx) xxxx-xxxx";
      ////        MessageBox.Show("Please enter an Australian phone number: (xx) xxxx-xxxx", "Error");
      //        e.Cancel = true;
      //      }
      //      this.errorProvider.SetError((Control)sender, error);

      //      string toolTip = this.toolTip.GetToolTip((Control)sender);
      //      if( !rgxOzPhone.IsMatch(((Control)sender).Text) ) {
      //        // Show the error when there is no text in the text box
      //        this.errorProvider.SetError((Control)sender, toolTip);
      //        this.infoProvider.SetError((Control)sender, null);
      //        e.Cancel = true;
      //      }
      //      else {
      //        // Show the info when there is text in the text box
      //        this.errorProvider.SetError((Control)sender, null);
      //        this.infoProvider.SetError((Control)sender, toolTip);
      //      }
      UpdateErrorStatus(rgxOzPhone.IsMatch(((Control)sender).Text), (Control)sender, e);
    }
    private void applicantLoanAmountTextBox_Validating(object sender, CancelEventArgs e) {
      //      string error = null;
      //      // Check that a valid applicant loan amount was provided
      //      if( !rgxLoanAmount.IsMatch(( (Control)sender ).Text) ) {
      //        error = "Please enter a valid loan amount: x.xx";
      ////        MessageBox.Show("Please enter a valid loan amount: x.xx", "Error");
      //        e.Cancel = true;
      //      }
      //      this.errorProvider.SetError((Control)sender, error);
      //      string toolTip = this.toolTip.GetToolTip((Control)sender);
      //      if( !rgxLoanAmount.IsMatch(((Control)sender).Text) ) {
      //        // Show the error when there is no text in the text box
      //        this.errorProvider.SetError((Control)sender, toolTip);
      //        this.infoProvider.SetError((Control)sender, null);
      //        e.Cancel = true;
      //      }
      //      else {
      //        // Show the info when there is text in the text box
      //        this.errorProvider.SetError((Control)sender, null);
      //        this.infoProvider.SetError((Control)sender, toolTip);
      //      }
      UpdateErrorStatus(rgxLoanAmount.IsMatch(((Control)sender).Text), (Control)sender, e);
    }
    private void applicantLoanAmountRepaymentGroupBox_Validating(object sender, CancelEventArgs e) {
      //// Check that 1st and 2nd percentages sum up to 100
      //string error = null;
      //if( (this.firstNumericUpDown.Value +
      //     this.secondNumericUpDown.Value != 100) ) {
      //  error = "First and second repayments must add up to 100%.";
      //  e.Cancel = true;
      //}
      //this.errorProvider.SetError((Control)sender, error);

      // Repayment split must add up to 100%
      UpdateErrorStatus((this.firstNumericUpDown.Value + this.secondNumericUpDown.Value == 100), (Control)sender, e);
    }

    private void UpdateErrorStatus(bool isValid, Control control, CancelEventArgs e) {
      string toolTip = this.toolTip.GetToolTip(control);
      if( isValid ) {
        // Show the info when there is text in the text box
        this.errorProvider.SetError(control, null);
        this.infoProvider.SetError(control, toolTip);
      }
      else {
        // Show the error when there is no text in the text box
        this.errorProvider.SetError(control, toolTip);
        this.infoProvider.SetError(control, null);
        e.Cancel = true;
      }
    }

    private void LoanApplicationDialog_HelpRequested(object sender, HelpEventArgs e) {
      //// If no mouse button was clicked, F1 got us here
      //if( Control.MouseButtons == MouseButtons.None ) {

      //  // open a help file...
      //  string file = Path.GetFullPath("loanApplicationDialog.htm");
      //  Help.ShowHelp(this, file);

      //  string subtopic = null;
      //  if( this.ActiveControl == this.applicantNameTextBox ) {
      //    subtopic = "name";
      //  }
      //  else if( this.ActiveControl == this.applicantPhoneNoTextBox ) {
      //    subtopic = "phoneNo";
      //  }
      //  else if( this.ActiveControl == this.applicantLoanAmountTextBox ) {
      //    subtopic = "loanAmount";
      //  }
      //  else if( this.ActiveControl == this.firstNumericUpDown ) {
      //    subtopic = "firstrepaymentpercent";
      //  }
      //  else if( this.ActiveControl == this.secondNumericUpDown ) {
      //    subtopic = "secondrepaymentpercent";
      //  }
      //  Help.ShowHelp(this, "dialogs.chm", "loanApplicationDialog.htm#" + subtopic);
      //  e.Handled = true;
      //}
      //else {
      //  // Convert screen coordinates to client coordinates
      //  Point pt = this.PointToClient(e.MousePos);

      //  // Find clicked control
      //  Control control = FindChildAtPoint(this, pt);
      //  if( control == null ) return;

      //  // Return help for control
      //  string help = toolTip.GetToolTip(control);
      //  if( help.Length == 0 ) return;
      //  Help.ShowPopup(this, help, e.MousePos);
      //  e.Handled = true;
      //}
    }

    private Control FindChildAtPoint(Control parent, Point pt) {
      // Find a child
      Control child = parent.GetChildAtPoint(pt);

      // If no child, this is the control at the mouse cursor
      if( child == null ) return parent;

      // If a child, offset our current position to be relative to the child
      Point childPoint = new Point(pt.X - child.Location.X, pt.Y - child.Location.Y);

      // Find child of child control at offset position
      return FindChildAtPoint(child, childPoint);
    }

    private void LoanApplicationDialog_HelpButtonClicked(object sender, CancelEventArgs e) {

      // Show help for currently active control
      string subtopic = null;
      if( this.ActiveControl == this.applicantNameTextBox ) {
        subtopic = "name";
      }
      else if( this.ActiveControl == this.applicantPhoneNoTextBox ) {
        subtopic = "phoneNo";
      }
      else if( this.ActiveControl == this.applicantLoanAmountTextBox ) {
        subtopic = "loanAmount";
      }
      Help.ShowHelp(this, "dialogs.chm", "loanApplicationDialog.htm#" + subtopic);

      // Don't allow users to click a control to find its help,
      // as we just did that for the active control
      e.Cancel = true;
    }
  }
}

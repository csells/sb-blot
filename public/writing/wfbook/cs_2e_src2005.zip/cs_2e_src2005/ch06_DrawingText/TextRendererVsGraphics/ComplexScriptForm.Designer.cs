namespace TextRendererVsGraphics {
  partial class ComplexScriptForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
      this.textrendererPictureBox = new System.Windows.Forms.PictureBox();
      this.label1 = new System.Windows.Forms.Label();
      this.graphicsPictureBox = new System.Windows.Forms.PictureBox();
      this.label2 = new System.Windows.Forms.Label();
      this.tableLayoutPanel1.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.textrendererPictureBox)).BeginInit();
      ((System.ComponentModel.ISupportInitialize)(this.graphicsPictureBox)).BeginInit();
      this.SuspendLayout();
      // 
      // tableLayoutPanel1
      // 
      this.tableLayoutPanel1.ColumnCount = 2;
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 100F));
      this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
      this.tableLayoutPanel1.Controls.Add(this.textrendererPictureBox, 1, 1);
      this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
      this.tableLayoutPanel1.Controls.Add(this.graphicsPictureBox, 1, 0);
      this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
      this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
      this.tableLayoutPanel1.Name = "tableLayoutPanel1";
      this.tableLayoutPanel1.RowCount = 2;
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
      this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
      this.tableLayoutPanel1.Size = new System.Drawing.Size(535, 418);
      this.tableLayoutPanel1.TabIndex = 2;
      // 
      // textrendererPictureBox
      // 
      this.textrendererPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.textrendererPictureBox.Location = new System.Drawing.Point(103, 212);
      this.textrendererPictureBox.Name = "textrendererPictureBox";
      this.textrendererPictureBox.Size = new System.Drawing.Size(429, 203);
      this.textrendererPictureBox.TabIndex = 1;
      this.textrendererPictureBox.TabStop = false;
      this.textrendererPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.textrendererPictureBox_Paint);
      // 
      // label1
      // 
      this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label1.Location = new System.Drawing.Point(3, 0);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(94, 209);
      this.label1.TabIndex = 2;
      this.label1.Text = "Graphics:";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // graphicsPictureBox
      // 
      this.graphicsPictureBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.graphicsPictureBox.Location = new System.Drawing.Point(103, 3);
      this.graphicsPictureBox.Name = "graphicsPictureBox";
      this.graphicsPictureBox.Size = new System.Drawing.Size(429, 203);
      this.graphicsPictureBox.TabIndex = 0;
      this.graphicsPictureBox.TabStop = false;
      this.graphicsPictureBox.Paint += new System.Windows.Forms.PaintEventHandler(this.graphicsPictureBox_Paint);
      // 
      // label2
      // 
      this.label2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.label2.Location = new System.Drawing.Point(3, 209);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(94, 209);
      this.label2.TabIndex = 3;
      this.label2.Text = "TextRenderer:";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
      // 
      // ComplexScriptForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(535, 418);
      this.Controls.Add(this.tableLayoutPanel1);
      this.Name = "ComplexScriptForm";
      this.Text = "Complex Script";
      this.tableLayoutPanel1.ResumeLayout(false);
      ((System.ComponentModel.ISupportInitialize)(this.textrendererPictureBox)).EndInit();
      ((System.ComponentModel.ISupportInitialize)(this.graphicsPictureBox)).EndInit();
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
    private System.Windows.Forms.PictureBox graphicsPictureBox;
    private System.Windows.Forms.PictureBox textrendererPictureBox;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;

  }
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TextRendererVsGraphics {
  public partial class DeviceIndepenceForm : Form {
    public DeviceIndepenceForm() {
      InitializeComponent();
    }

    private void printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e) {
      Graphics g = e.Graphics;

      if( this.gRadioButton.Checked ) {
        g.DrawString(this.printTextBox.Text, this.printTextBox.Font, Brushes.Black, e.MarginBounds);
      }
      else {
        TextRenderer.DrawText(g, this.printTextBox.Text, this.printTextBox.Font, e.MarginBounds, Color.Black);
      }
    }

    private void printButton_Click(object sender, EventArgs e) {
      this.printDocument.Print();
    }
  }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TextRendererVsGraphics {
  public partial class ShellConsistencyForm : Form {
    public ShellConsistencyForm() {
      InitializeComponent();
    }

    private void gOKButton_Paint(object sender, PaintEventArgs e) {
      // Draw OK button using Graphics
      ButtonRenderer.DrawButton(e.Graphics, this.gOKButton.ClientRectangle, System.Windows.Forms.VisualStyles.PushButtonState.Default);
      using( Font font = new Font("Tahoma", 8) ) {
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        e.Graphics.DrawString("OK", font, Brushes.Black, this.gOKButton.ClientRectangle, format);
      }
    }

    private void gCancelButton_Paint(object sender, PaintEventArgs e) {
      // Draw Cancel button using Graphics
      ButtonRenderer.DrawButton(e.Graphics, this.gCancelButton.ClientRectangle, System.Windows.Forms.VisualStyles.PushButtonState.Normal);
      using( Font font = new Font("Tahoma", 8) ) {
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        e.Graphics.DrawString("Cancel", font, Brushes.Black, this.gCancelButton.ClientRectangle, format);
      }
    }

    private void tOKButton_Paint(object sender, PaintEventArgs e) {
      // Draw OK button using TextRenderer
      ButtonRenderer.DrawButton(e.Graphics, this.tOKButton.ClientRectangle, System.Windows.Forms.VisualStyles.PushButtonState.Default);
      using( Font font = new Font("Tahoma", 8) ) {
        TextFormatFlags format = TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter;
        TextRenderer.DrawText(e.Graphics, "OK", font, this.gCancelButton.ClientRectangle, this.ForeColor, format);
      }
    }

    private void tCancelButton_Paint(object sender, PaintEventArgs e) {
      // Draw Cancel button using TextRenderer
      ButtonRenderer.DrawButton(e.Graphics, this.tCancelButton.ClientRectangle, System.Windows.Forms.VisualStyles.PushButtonState.Normal);
      using( Font font = new Font("Tahoma", 8) ) {
        TextFormatFlags format = TextFormatFlags.VerticalCenter | TextFormatFlags.HorizontalCenter;
        TextRenderer.DrawText(e.Graphics, "Cancel", font, this.gCancelButton.ClientRectangle, this.ForeColor, format);
      }
    }
  }
}
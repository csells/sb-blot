using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace TextRendererVsGraphics {
  public partial class ClearTypeRenderingForm : Form {
    public ClearTypeRenderingForm() {
      InitializeComponent();
    }

    private void gLetterPanel_Paint(object sender, PaintEventArgs e) {
      StringFormat format = new StringFormat();
      format.LineAlignment = StringAlignment.Center;
      format.Alignment = StringAlignment.Center;
      e.Graphics.DrawString("A", this.gLetterPanel.Font, Brushes.Black, this.gLetterPanel.ClientRectangle, format);
    }
    
    private void tLetterPanel_Paint(object sender, PaintEventArgs e) {
      TextFormatFlags format = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter;
      TextRenderer.DrawText(e.Graphics, "A", this.tLetterPanel.Font, this.tLetterPanel.ClientRectangle, this.ForeColor);
    }
  }
}
namespace TextRendererVsGraphics {
  partial class DeviceIndepenceForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.printDocument = new System.Drawing.Printing.PrintDocument();
      this.printTextBox = new System.Windows.Forms.TextBox();
      this.printButton = new System.Windows.Forms.Button();
      this.gRadioButton = new System.Windows.Forms.RadioButton();
      this.tRadioButton = new System.Windows.Forms.RadioButton();
      this.label1 = new System.Windows.Forms.Label();
      this.SuspendLayout();
      // 
      // printDocument
      // 
      this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
      // 
      // printTextBox
      // 
      this.printTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.printTextBox.Location = new System.Drawing.Point(89, 58);
      this.printTextBox.Name = "printTextBox";
      this.printTextBox.Size = new System.Drawing.Size(321, 31);
      this.printTextBox.TabIndex = 0;
      // 
      // printButton
      // 
      this.printButton.Location = new System.Drawing.Point(335, 95);
      this.printButton.Name = "printButton";
      this.printButton.Size = new System.Drawing.Size(75, 23);
      this.printButton.TabIndex = 1;
      this.printButton.Text = "Print";
      this.printButton.UseVisualStyleBackColor = true;
      this.printButton.Click += new System.EventHandler(this.printButton_Click);
      // 
      // gRadioButton
      // 
      this.gRadioButton.AutoSize = true;
      this.gRadioButton.Checked = true;
      this.gRadioButton.Location = new System.Drawing.Point(15, 12);
      this.gRadioButton.Name = "gRadioButton";
      this.gRadioButton.Size = new System.Drawing.Size(121, 17);
      this.gRadioButton.TabIndex = 2;
      this.gRadioButton.TabStop = true;
      this.gRadioButton.Text = "Print Using Graphics";
      this.gRadioButton.UseVisualStyleBackColor = true;
      // 
      // tRadioButton
      // 
      this.tRadioButton.AutoSize = true;
      this.tRadioButton.Location = new System.Drawing.Point(15, 35);
      this.tRadioButton.Name = "tRadioButton";
      this.tRadioButton.Size = new System.Drawing.Size(144, 17);
      this.tRadioButton.TabIndex = 3;
      this.tRadioButton.Text = "Print Using TextRenderer";
      this.tRadioButton.UseVisualStyleBackColor = true;
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
      this.label1.Location = new System.Drawing.Point(12, 70);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(71, 13);
      this.label1.TabIndex = 4;
      this.label1.Text = "Text To Print:";
      // 
      // DeviceIndepenceForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(422, 126);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.tRadioButton);
      this.Controls.Add(this.gRadioButton);
      this.Controls.Add(this.printButton);
      this.Controls.Add(this.printTextBox);
      this.Name = "DeviceIndepenceForm";
      this.Text = "Device Independence";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Drawing.Printing.PrintDocument printDocument;
    private System.Windows.Forms.TextBox printTextBox;
    private System.Windows.Forms.Button printButton;
    private System.Windows.Forms.RadioButton gRadioButton;
    private System.Windows.Forms.RadioButton tRadioButton;
    private System.Windows.Forms.Label label1;
  }
}


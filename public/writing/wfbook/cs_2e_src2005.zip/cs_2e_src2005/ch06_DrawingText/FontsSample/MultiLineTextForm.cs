﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class MultiLineTextForm : Form {
    public MultiLineTextForm() {
      InitializeComponent();
    }

    string multiline = "a multi-line string:\nline 2\nline 3";

    private void automaticPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      RectangleF layoutRect = automaticPanel.ClientRectangle;
      g.DrawString(multiline, this.Font, Brushes.Black, layoutRect);

      SizeF size = g.MeasureString(multiline, this.Font, layoutRect.Size);
      g.DrawRectangle(Pens.Black, 0, 0, size.Width, size.Height);
    }

    private void manualPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      float y = 0;

      // Render using multiple calls to MeasureString
      //      foreach( string line in multiline.Split(Environment.NewLine.ToCharArray()) ) {
      //        float width = manualPanel.ClientRectangle.Width;
      //        float height = manualPanel.ClientRectangle.Height - y;
      //        RectangleF rect = new RectangleF(0, y, width, height);
      //        SizeF size = g.MeasureString(line, this.Font, rect.Size);
      //
      //        RectangleF layoutRect = new RectangleF(new PointF(0, y), size);
      //        g.DrawString(line, this.Font, Brushes.Black, layoutRect);
      //        g.DrawRectangle(Pens.Black, 0, y, size.Width, size.Height);
      //
      //        y += size.Height;
      //      }

      // Render using Font.GetHeight
      Pen[] pens = new Pen[] { Pens.Red, Pens.Green, Pens.Blue, };
      foreach( string line in multiline.Split(Environment.NewLine.ToCharArray()) ) {
        float width = manualPanel.ClientRectangle.Width;
        float height = manualPanel.ClientRectangle.Height - y;
        RectangleF layoutRect = new RectangleF(0, y, width, height);

        // Turn off auto-wrapping (we're doing it manually)
        using( StringFormat format = new StringFormat(StringFormatFlags.NoWrap | StringFormatFlags.DisplayFormatControl) ) {
          g.DrawString(line, this.Font, Brushes.Black, layoutRect, format);

          SizeF size = g.MeasureString(line, this.Font, layoutRect.Size, format);
          //g.DrawRectangle(Pens.Black, 0, y, size.Width, size.Height);
          g.DrawRectangle(pens[(int)(y / this.Font.GetHeight(g))], 0, y, size.Width, size.Height);

          // Get ready for the next line
          y += this.Font.GetHeight(g);
        }
      }
    }

    private void manualPanel_Layout(object sender, LayoutEventArgs e) {
      this.automaticPanel.Refresh();
      this.manualPanel.Refresh();
    }
  }
}
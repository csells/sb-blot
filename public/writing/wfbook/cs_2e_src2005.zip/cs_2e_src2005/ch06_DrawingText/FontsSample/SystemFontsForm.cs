﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class SystemFontsForm : Form {
    public SystemFontsForm() {
      InitializeComponent();
    }

    private void SystemFontsForm_Paint(object sender, PaintEventArgs e) {

      Graphics g = e.Graphics;

      int y = 0;

      y += RenderSystemFont(g, "CaptionFont", SystemFonts.CaptionFont, y);
      y += RenderSystemFont(g, "DefaultFont", SystemFonts.DefaultFont, y);
      y += RenderSystemFont(g, "DialogFont", SystemFonts.DialogFont, y);
      y += RenderSystemFont(g, "IconTitleFont", SystemFonts.IconTitleFont, y);
      y += RenderSystemFont(g, "MenuFont", SystemFonts.MenuFont, y);
      y += RenderSystemFont(g, "MessageBoxFont", SystemFonts.MessageBoxFont, y);
      y += RenderSystemFont(g, "SmallCaptionFont", SystemFonts.SmallCaptionFont, y);
      y += RenderSystemFont(g, "StatusFont", SystemFonts.StatusFont, y);
    }

    private int RenderSystemFont(Graphics g, string fontName, Font systemFont, int y) {

      using( StringFormat format = new StringFormat() ) {
        format.FormatFlags = StringFormatFlags.NoWrap;

        // Render system font
        string msg = fontName + ": " + systemFont.Name +
                     " " + systemFont.SizeInPoints.ToString() + "pt" +
                     " " + (systemFont.Bold ? "Bold" : "");
        g.DrawString(msg, systemFont, Brushes.Black, 0, y, format);

        // Calculate and return font height for increment
        SizeF size = g.MeasureString(msg, systemFont);
        systemFont.Dispose();
        return (int)size.Height;
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class OutlineFontsForm : Form {
    public OutlineFontsForm() {
      InitializeComponent();
    }

    private void OutlineFontsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = "Outline";
      RectangleF rect = this.ClientRectangle;
      Font font = this.Font;
      using( StringFormat format = StringFormat.GenericTypographic ) {
        float dpi = g.DpiY;
        using( GraphicsPath path = GetStringPath(s, dpi, rect, font, format) ) {
          g.DrawPath(Pens.Black, path);
        }
      }
    }

    // Need to pass in DPI = 100 for GraphicsUnit == Display
    private GraphicsPath GetStringPath(
      string s,
      float dpi,
      RectangleF rect,
      Font font,
      StringFormat format) {
      GraphicsPath path = new GraphicsPath();
      // Convert font size into appropriate coordinates
      float emSize = dpi * font.SizeInPoints / 72;
      path.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
      return path;
    }
  }
}
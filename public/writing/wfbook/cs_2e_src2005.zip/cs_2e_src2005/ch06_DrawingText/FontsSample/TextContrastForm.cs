﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class TextContrastForm : Form {
    public TextContrastForm() {
      InitializeComponent();
    }

    private void TextContrastForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;

      using( StringFormat format = new StringFormat() ) {
        format.FormatFlags = StringFormatFlags.NoWrap;

        float y = 0;
        for( int i = 0; i <= 12; i += 4 ) {
          g.TextContrast = i;
          string line = "TextContrast = " + i.ToString();
          g.DrawString(line, this.Font, Brushes.Black, 0, y, format);
          y += this.Font.GetHeight(g);
        }
      }
    }
  }
}
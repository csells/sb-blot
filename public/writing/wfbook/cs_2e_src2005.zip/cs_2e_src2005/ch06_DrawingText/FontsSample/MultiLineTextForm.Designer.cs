﻿namespace FontsSample {
  partial class MultiLineTextForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.automaticPanel = new System.Windows.Forms.Panel();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.manualPanel = new System.Windows.Forms.Panel();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 0);
      this.splitContainer1.Name = "splitContainer1";
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
      this.splitContainer1.Size = new System.Drawing.Size(338, 275);
      this.splitContainer1.SplitterDistance = 165;
      this.splitContainer1.TabIndex = 0;
      this.splitContainer1.Text = "splitContainer1";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.automaticPanel);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(165, 275);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Automatic";
      // 
      // automaticPanel
      // 
      this.automaticPanel.BackColor = System.Drawing.Color.White;
      this.automaticPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.automaticPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.automaticPanel.Location = new System.Drawing.Point(3, 31);
      this.automaticPanel.Name = "automaticPanel";
      this.automaticPanel.Size = new System.Drawing.Size(159, 241);
      this.automaticPanel.TabIndex = 0;
      this.automaticPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.automaticPanel_Paint);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.manualPanel);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
      this.groupBox2.Location = new System.Drawing.Point(0, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(169, 275);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Manual";
      // 
      // manualPanel
      // 
      this.manualPanel.BackColor = System.Drawing.Color.White;
      this.manualPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.manualPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.manualPanel.Location = new System.Drawing.Point(3, 31);
      this.manualPanel.Name = "manualPanel";
      this.manualPanel.Size = new System.Drawing.Size(163, 241);
      this.manualPanel.TabIndex = 0;
      this.manualPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.manualPanel_Paint);
      this.manualPanel.Layout += new System.Windows.Forms.LayoutEventHandler(this.manualPanel_Layout);
      // 
      // MultiLineTextForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(338, 275);
      this.Controls.Add(this.splitContainer1);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
      this.Name = "MultiLineTextForm";
      this.Text = "Multi-Line Text";
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Panel automaticPanel;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel manualPanel;
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class FontSizesForm : Form {
    public FontSizesForm() {
      InitializeComponent();
    }

    private float GetPixelsFromPoints(float points, float dpi) {
      return (dpi * points) / 72f;
    }

    private float GetInchesFromPoints(float points, float dpi) {
      return GetPixelsFromPoints(points, dpi) / dpi;
    }

    private float GetPixelsFromDesignUnits(float designUnits, Font font, float dpi) {
      float scale = GetPixelsFromPoints(font.Size, dpi) / font.FontFamily.GetEmHeight(font.Style);
      return designUnits * scale;
    }

    private float GetPointsFromPixels(float pixels, float dpi) {
      return (pixels * 72f) / dpi;
    }

    private void FontSizesForm_Load(object sender, EventArgs e) {
      using( Graphics g = this.CreateGraphics() ) {

        // A 12-point font will be 16 pixels high on a 96 dpi monitor
        //        float dpi = g.DpiY;
        //        float points = 12.0f;
        //        float pixels = (points * dpi)/72f;
        //        MessageBox.Show(pixels.ToString());

        // A 12-point font will be 16 pixels high on a 96 dpi monitor
        //        float points = 12.0f;
        //        float designUnits = 2048;
        //        float pixels = 


        listBox1.Items.Add(string.Format("Font.Name=                       {0}", this.Font.Name));
        listBox1.Items.Add(string.Format("Font.FontFamly.Name=             {0}", this.Font.FontFamily.Name));
        listBox1.Items.Add(string.Format("Font.Size=                       {0} {1}s (specified Unit)", this.Font.Size, this.Font.Unit.ToString()));
        listBox1.Items.Add(string.Format("Font.Height=                     {0} Pixels", this.Font.Height));
        listBox1.Items.Add(string.Format("Font.GetHeight=                  {0} Pixels", this.Font.GetHeight(g)));
        listBox1.Items.Add(string.Format("Font.SizeInPoints=               {0} Points", this.Font.SizeInPoints.ToString()));
        listBox1.Items.Add(string.Format("GetPixels(Font.SizeInPoints)=    {0} Pixels", GetPixelsFromPoints(this.Font.SizeInPoints, g.DpiY)));
//        listBox1.Items.Add(string.Format("GetInches(Font.SizeInPoints)=    {0} Inches", GetInchesFromPoints(this.Font.SizeInPoints, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetEmHeight=     {0} Design Units", this.Font.FontFamily.GetEmHeight(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetEmHeight)=          {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetEmHeight(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetLineSpacing=  {0} Design Units", this.Font.FontFamily.GetLineSpacing(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetLineSpacing)=       {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetLineSpacing(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetCellAscent=   {0} Design Units", this.Font.FontFamily.GetCellAscent(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetCellAscent)=        {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetCellAscent(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Font.FontFamily.GetCellDescent=  {0} Design Units", this.Font.FontFamily.GetCellDescent(FontStyle.Regular)));
        listBox1.Items.Add(string.Format("GetPixels(GetCellDescent)=       {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetCellDescent(this.Font.Style), this.Font, g.DpiY)));
        listBox1.Items.Add(string.Format("Padding=                         {0} Design Units", this.Font.FontFamily.GetLineSpacing(FontStyle.Regular) - (this.Font.FontFamily.GetCellAscent(FontStyle.Regular) + this.Font.FontFamily.GetCellDescent(FontStyle.Regular))));
        listBox1.Items.Add(string.Format("GetPixels(Padding)=              {0} Pixels", GetPixelsFromDesignUnits(this.Font.FontFamily.GetLineSpacing(FontStyle.Regular) - (this.Font.FontFamily.GetCellAscent(FontStyle.Regular) + this.Font.FontFamily.GetCellDescent(FontStyle.Regular)), this.Font, g.DpiY)));
      }
    }
  }
}
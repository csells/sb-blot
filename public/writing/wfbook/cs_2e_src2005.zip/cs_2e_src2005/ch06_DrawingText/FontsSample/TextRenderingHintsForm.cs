﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class TextRenderingHintsForm : Form {
    public TextRenderingHintsForm() {
      InitializeComponent();
    }

    private void TextRenderingHintsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = @"Greetings, Planet Earth";

      TextRenderingHint[] hints = { TextRenderingHint.SystemDefault,
                                    TextRenderingHint.SingleBitPerPixel,
                                    TextRenderingHint.SingleBitPerPixelGridFit,
                                    TextRenderingHint.AntiAlias,
                                    TextRenderingHint.AntiAliasGridFit,
                                    TextRenderingHint.ClearTypeGridFit,
      };

      float y = 0;

      using( StringFormat format = new StringFormat() ) {
        format.FormatFlags = StringFormatFlags.NoWrap;

        foreach( TextRenderingHint hint in hints ) {
          g.TextRenderingHint = hint;
          string line = hint.ToString() + ": " + s;
          g.DrawString(line, this.Font, Brushes.Black, 0, y, format);
          y += this.Font.GetHeight(g) + 10;
        }
      }
    }
  }
}
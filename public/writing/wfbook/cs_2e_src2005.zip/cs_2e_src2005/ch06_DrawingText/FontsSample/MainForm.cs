﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void fontFamiliesButton_Click(object sender, EventArgs e) {
      (new FontFamiliesForm()).ShowDialog();
    }

    private void fontSizesButton_Click(object sender, EventArgs e) {
      (new FontSizesForm()).ShowDialog();
    }

    private void fontSizesDrawnButton_Click(object sender, EventArgs e) {
      (new FontSizesForm2()).ShowDialog();
    }

    private void fontSizesGraphicsVsTextRenderButton_Click(object sender, EventArgs e) {
      (new FontRenderingForm()).ShowDialog();
    }

    private void multiLineTextButton_Click(object sender, EventArgs e) {
      (new MultiLineTextForm()).ShowDialog();
    }

    private void lineLimitButton_Click(object sender, EventArgs e) {
      (new LineLimitForm()).ShowDialog();
    }

    private void trimmingButton_Click(object sender, EventArgs e) {
      (new TrimmingForm()).ShowDialog();
    }

    private void digitSubstitutionButton_Click(object sender, EventArgs e) {
      (new DigitSubstitutionForm()).ShowDialog();
    }

    private void textRenderingHintsButton_Click(object sender, EventArgs e) {
      (new TextRenderingHintsForm()).ShowDialog();
    }

    private void textContrastButton_Click(object sender, EventArgs e) {
      (new TextContrastForm()).ShowDialog();
    }

    private void outlineFontsButton_Click(object sender, EventArgs e) {
      (new OutlineFontsForm()).ShowDialog();
    }

    private void shadowFontsButton_Click(object sender, EventArgs e) {
      (new ShadowFontsForm()).ShowDialog();
    }

    private void systemFontsButton_Click(object sender, EventArgs e) {
      (new SystemFontsForm()).ShowDialog();
    }

    private void perfTextButton_Click(object sender, EventArgs e) {
      (new PerfForm()).ShowDialog();
    }

    private void textRendererButton_Click(object sender, EventArgs e) {
      (new TextRendererForm()).ShowDialog();
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class DigitSubstitutionForm : Form {
    public DigitSubstitutionForm() {
      InitializeComponent();
    }

    private void DigitSubstitutionForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string digits = @"0 1 2 3 4 5 6 7 8 9 10";

      StringDigitSubstitute[] methods = { StringDigitSubstitute.None,
                                          StringDigitSubstitute.National,
                                          StringDigitSubstitute.Traditional,
                                          StringDigitSubstitute.User,
      };

      float y = 0;
      CultureInfo culture = new CultureInfo("th-TH"); // Thailand
      using( StringFormat format = new StringFormat() ) {
        foreach( StringDigitSubstitute method in methods ) {
          format.SetDigitSubstitution(culture.LCID, method);
          g.DrawString(method.ToString() + ": " + digits, this.Font, Brushes.Black, 0, y, format);
          y += this.Font.GetHeight(g);
        }
      }
    }
  }
}
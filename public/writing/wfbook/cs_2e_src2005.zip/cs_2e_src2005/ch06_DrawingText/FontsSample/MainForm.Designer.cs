﻿namespace FontsSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.fontFamiliesButton = new System.Windows.Forms.Button();
      this.fontSizesButton = new System.Windows.Forms.Button();
      this.fontSizesDrawnButton = new System.Windows.Forms.Button();
      this.multiLineTextButton = new System.Windows.Forms.Button();
      this.lineLimitButton = new System.Windows.Forms.Button();
      this.trimmingButton = new System.Windows.Forms.Button();
      this.digitSubstitutionButton = new System.Windows.Forms.Button();
      this.textRenderingHintsButton = new System.Windows.Forms.Button();
      this.textContrastButton = new System.Windows.Forms.Button();
      this.outlineFontsButton = new System.Windows.Forms.Button();
      this.shadowFontsButton = new System.Windows.Forms.Button();
      this.fontSizesGraphicsVsTextRenderButton = new System.Windows.Forms.Button();
      this.systemFontsButton = new System.Windows.Forms.Button();
      this.perfTextButton = new System.Windows.Forms.Button();
      this.textRendererButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // fontFamiliesButton
      // 
      this.fontFamiliesButton.Location = new System.Drawing.Point(13, 13);
      this.fontFamiliesButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.fontFamiliesButton.Name = "fontFamiliesButton";
      this.fontFamiliesButton.Size = new System.Drawing.Size(208, 23);
      this.fontFamiliesButton.TabIndex = 0;
      this.fontFamiliesButton.Text = "Font Families";
      this.fontFamiliesButton.Click += new System.EventHandler(this.fontFamiliesButton_Click);
      // 
      // fontSizesButton
      // 
      this.fontSizesButton.Location = new System.Drawing.Point(13, 39);
      this.fontSizesButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.fontSizesButton.Name = "fontSizesButton";
      this.fontSizesButton.Size = new System.Drawing.Size(208, 23);
      this.fontSizesButton.TabIndex = 1;
      this.fontSizesButton.Text = "Font Sizes";
      this.fontSizesButton.Click += new System.EventHandler(this.fontSizesButton_Click);
      // 
      // fontSizesDrawnButton
      // 
      this.fontSizesDrawnButton.Location = new System.Drawing.Point(13, 65);
      this.fontSizesDrawnButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.fontSizesDrawnButton.Name = "fontSizesDrawnButton";
      this.fontSizesDrawnButton.Size = new System.Drawing.Size(208, 23);
      this.fontSizesDrawnButton.TabIndex = 2;
      this.fontSizesDrawnButton.Text = "Font Sizes (Drawn)";
      this.fontSizesDrawnButton.Click += new System.EventHandler(this.fontSizesDrawnButton_Click);
      // 
      // multiLineTextButton
      // 
      this.multiLineTextButton.Location = new System.Drawing.Point(13, 117);
      this.multiLineTextButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.multiLineTextButton.Name = "multiLineTextButton";
      this.multiLineTextButton.Size = new System.Drawing.Size(208, 23);
      this.multiLineTextButton.TabIndex = 4;
      this.multiLineTextButton.Text = "Multi-Line Text";
      this.multiLineTextButton.Click += new System.EventHandler(this.multiLineTextButton_Click);
      // 
      // lineLimitButton
      // 
      this.lineLimitButton.Location = new System.Drawing.Point(13, 143);
      this.lineLimitButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.lineLimitButton.Name = "lineLimitButton";
      this.lineLimitButton.Size = new System.Drawing.Size(208, 23);
      this.lineLimitButton.TabIndex = 5;
      this.lineLimitButton.Text = "Line Limit";
      this.lineLimitButton.Click += new System.EventHandler(this.lineLimitButton_Click);
      // 
      // trimmingButton
      // 
      this.trimmingButton.Location = new System.Drawing.Point(14, 169);
      this.trimmingButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.trimmingButton.Name = "trimmingButton";
      this.trimmingButton.Size = new System.Drawing.Size(208, 23);
      this.trimmingButton.TabIndex = 6;
      this.trimmingButton.Text = "Trimming";
      this.trimmingButton.Click += new System.EventHandler(this.trimmingButton_Click);
      // 
      // digitSubstitutionButton
      // 
      this.digitSubstitutionButton.Location = new System.Drawing.Point(14, 195);
      this.digitSubstitutionButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.digitSubstitutionButton.Name = "digitSubstitutionButton";
      this.digitSubstitutionButton.Size = new System.Drawing.Size(208, 23);
      this.digitSubstitutionButton.TabIndex = 7;
      this.digitSubstitutionButton.Text = "Digit Substitution";
      this.digitSubstitutionButton.Click += new System.EventHandler(this.digitSubstitutionButton_Click);
      // 
      // textRenderingHintsButton
      // 
      this.textRenderingHintsButton.Location = new System.Drawing.Point(14, 221);
      this.textRenderingHintsButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 2);
      this.textRenderingHintsButton.Name = "textRenderingHintsButton";
      this.textRenderingHintsButton.Size = new System.Drawing.Size(208, 23);
      this.textRenderingHintsButton.TabIndex = 8;
      this.textRenderingHintsButton.Text = "Text Rendering Hints";
      this.textRenderingHintsButton.Click += new System.EventHandler(this.textRenderingHintsButton_Click);
      // 
      // textContrastButton
      // 
      this.textContrastButton.Location = new System.Drawing.Point(14, 247);
      this.textContrastButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 2);
      this.textContrastButton.Name = "textContrastButton";
      this.textContrastButton.Size = new System.Drawing.Size(208, 23);
      this.textContrastButton.TabIndex = 9;
      this.textContrastButton.Text = "Text Contrast";
      this.textContrastButton.Click += new System.EventHandler(this.textContrastButton_Click);
      // 
      // outlineFontsButton
      // 
      this.outlineFontsButton.Location = new System.Drawing.Point(14, 273);
      this.outlineFontsButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 2);
      this.outlineFontsButton.Name = "outlineFontsButton";
      this.outlineFontsButton.Size = new System.Drawing.Size(208, 23);
      this.outlineFontsButton.TabIndex = 10;
      this.outlineFontsButton.Text = "Outline Fonts";
      this.outlineFontsButton.Click += new System.EventHandler(this.outlineFontsButton_Click);
      // 
      // shadowFontsButton
      // 
      this.shadowFontsButton.Location = new System.Drawing.Point(14, 299);
      this.shadowFontsButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 2);
      this.shadowFontsButton.Name = "shadowFontsButton";
      this.shadowFontsButton.Size = new System.Drawing.Size(208, 23);
      this.shadowFontsButton.TabIndex = 11;
      this.shadowFontsButton.Text = "Shadow Fonts";
      this.shadowFontsButton.Click += new System.EventHandler(this.shadowFontsButton_Click);
      // 
      // fontSizesGraphicsVsTextRenderButton
      // 
      this.fontSizesGraphicsVsTextRenderButton.Location = new System.Drawing.Point(13, 91);
      this.fontSizesGraphicsVsTextRenderButton.Name = "fontSizesGraphicsVsTextRenderButton";
      this.fontSizesGraphicsVsTextRenderButton.Size = new System.Drawing.Size(208, 23);
      this.fontSizesGraphicsVsTextRenderButton.TabIndex = 3;
      this.fontSizesGraphicsVsTextRenderButton.Text = "Font Sizes (Graphics vs TextRenderer)";
      this.fontSizesGraphicsVsTextRenderButton.Click += new System.EventHandler(this.fontSizesGraphicsVsTextRenderButton_Click);
      // 
      // systemFontsButton
      // 
      this.systemFontsButton.Location = new System.Drawing.Point(13, 325);
      this.systemFontsButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
      this.systemFontsButton.Name = "systemFontsButton";
      this.systemFontsButton.Size = new System.Drawing.Size(208, 23);
      this.systemFontsButton.TabIndex = 12;
      this.systemFontsButton.Text = "System Fonts";
      this.systemFontsButton.Click += new System.EventHandler(this.systemFontsButton_Click);
      // 
      // perfTextButton
      // 
      this.perfTextButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.perfTextButton.Location = new System.Drawing.Point(15, 399);
      this.perfTextButton.Name = "perfTextButton";
      this.perfTextButton.Size = new System.Drawing.Size(207, 23);
      this.perfTextButton.TabIndex = 13;
      this.perfTextButton.Text = "Graphics vs TextRender Performance";
      this.perfTextButton.Click += new System.EventHandler(this.perfTextButton_Click);
      // 
      // textRendererButton
      // 
      this.textRendererButton.Location = new System.Drawing.Point(15, 352);
      this.textRendererButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
      this.textRendererButton.Name = "textRendererButton";
      this.textRendererButton.Size = new System.Drawing.Size(208, 23);
      this.textRendererButton.TabIndex = 14;
      this.textRendererButton.Text = "TextRenderer";
      this.textRendererButton.Click += new System.EventHandler(this.textRendererButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(237, 434);
      this.Controls.Add(this.textRendererButton);
      this.Controls.Add(this.perfTextButton);
      this.Controls.Add(this.systemFontsButton);
      this.Controls.Add(this.fontSizesGraphicsVsTextRenderButton);
      this.Controls.Add(this.shadowFontsButton);
      this.Controls.Add(this.outlineFontsButton);
      this.Controls.Add(this.textContrastButton);
      this.Controls.Add(this.textRenderingHintsButton);
      this.Controls.Add(this.digitSubstitutionButton);
      this.Controls.Add(this.trimmingButton);
      this.Controls.Add(this.lineLimitButton);
      this.Controls.Add(this.multiLineTextButton);
      this.Controls.Add(this.fontSizesDrawnButton);
      this.Controls.Add(this.fontSizesButton);
      this.Controls.Add(this.fontFamiliesButton);
      this.Name = "MainForm";
      this.Text = "Fonts";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button fontFamiliesButton;
    private System.Windows.Forms.Button fontSizesButton;
    private System.Windows.Forms.Button fontSizesDrawnButton;
    private System.Windows.Forms.Button multiLineTextButton;
    private System.Windows.Forms.Button lineLimitButton;
    private System.Windows.Forms.Button trimmingButton;
    private System.Windows.Forms.Button digitSubstitutionButton;
    private System.Windows.Forms.Button textRenderingHintsButton;
    private System.Windows.Forms.Button textContrastButton;
    private System.Windows.Forms.Button outlineFontsButton;
    private System.Windows.Forms.Button shadowFontsButton;
    private System.Windows.Forms.Button fontSizesGraphicsVsTextRenderButton;
    private System.Windows.Forms.Button systemFontsButton;
    private System.Windows.Forms.Button perfTextButton;
    private System.Windows.Forms.Button textRendererButton;
  }
}


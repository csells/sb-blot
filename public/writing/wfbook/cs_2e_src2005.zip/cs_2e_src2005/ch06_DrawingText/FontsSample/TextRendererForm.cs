using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace FontsSample {
  public partial class TextRendererForm : Form {
    public TextRendererForm() {
      InitializeComponent();
    }

    private void TextRendererForm_Paint(object sender, PaintEventArgs e) {
      
      Graphics g = e.Graphics;
      Size proposedSize = this.ClientRectangle.Size;
      
      //// Calculate rendered text size
      //Size size = TextRenderer.MeasureText(g, "Text To Measure", this.Font, proposedSize);
      //// Render text to calculated size
      //Rectangle rect = new Rectangle(0, 0, size.Width, size.Height);
      //TextRenderer.DrawText(g, "Text To Measure", this.Font, rect, Color.Black);
      
      // Display formatted text
      TextFormatFlags flags = TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter | TextFormatFlags.WordEllipsis;
      Rectangle rect = this.ClientRectangle;
      TextRenderer.DrawText(g, "Text To Measure", this.Font, rect, Color.Black, flags);
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class ShadowFontsForm : Form {
    public ShadowFontsForm() {
      InitializeComponent();
    }

    private void ShadowFontsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = "Shadow";
      float offset = 4;
      SizeF size = new SizeF(this.ClientRectangle.Width - offset, this.ClientRectangle.Height - offset);
      RectangleF rectShadow = new RectangleF(offset, offset, size.Width, size.Height);
      RectangleF rect = new RectangleF(0, 0, size.Width, size.Height);
      Font font = this.Font;
      using( StringFormat format = StringFormat.GenericTypographic ) {
        float dpi = g.DpiY;
        using( GraphicsPath pathShadow = GetStringPath(s, dpi, rectShadow, font, format) )
        using( GraphicsPath path = GetStringPath(s, dpi, rect, font, format) ) {
          g.FillPath(Brushes.Black, pathShadow);
          g.FillPath(Brushes.Red, path);
        }
      }
    }

    // Need to pass in DPI = 100 for GraphicsUnit == Display
    private GraphicsPath GetStringPath(string s, float dpi, RectangleF rect, Font font, StringFormat format) {
      GraphicsPath path = new GraphicsPath();
      float emSize = dpi * font.SizeInPoints / 72;
      path.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
      return path;
    }
  }
}
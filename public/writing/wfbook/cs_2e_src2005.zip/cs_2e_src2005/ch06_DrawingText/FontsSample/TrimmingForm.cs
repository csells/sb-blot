﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class TrimmingForm : Form {
    public TrimmingForm() {
      InitializeComponent();
    }

    private void TrimmingForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string s = @"a long string that could be trimmed any old place";
      string file = @"c:\a\long\file\name\that\could\be\trimmed\any\old\place.ext";

      StringTrimming[] trimmings = { StringTrimming.None,
                                     StringTrimming.Character,
                                     StringTrimming.EllipsisCharacter,
                                     StringTrimming.Word,
                                     StringTrimming.EllipsisWord,
                                     StringTrimming.EllipsisPath,
      };

      float y = 0;
      using( StringFormat format = new StringFormat() ) {
        format.FormatFlags = StringFormatFlags.LineLimit;

        // Docs say that tab stops are spaces, but they're world-coords
        SizeF size =
          g.MeasureString(
          StringTrimming.EllipsisCharacter.ToString(), this.Font);
        format.SetTabStops(0, new float[] { size.Width + 10, 0 });

        foreach( StringTrimming trimming in trimmings ) {
          format.Trimming = trimming;
          string line = trimming.ToString() + ":\t" + s;
          if( trimming == StringTrimming.EllipsisPath ) {
            line = trimming.ToString() + ":\t" + file;
          }
          RectangleF rect = new RectangleF(0, y, this.ClientRectangle.Width, this.Font.GetHeight(g) * 1.5f);
          g.DrawString(line, this.Font, Brushes.Black, rect, format);
          y += this.Font.GetHeight(g);
        }
      }
    }
  }
}
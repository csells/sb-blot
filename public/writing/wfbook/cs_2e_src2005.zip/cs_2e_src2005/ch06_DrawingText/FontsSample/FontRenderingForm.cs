﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Drawing.Text;

#endregion

namespace FontsSample {

  partial class FontRenderingForm : Form {

    private string _fontFamily = "Arial";
    private int _fontSize = 100;

    public FontRenderingForm() {

      InitializeComponent();

      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);

      // Load available fonts and select default
      foreach( FontFamily fontFamily in FontFamily.Families ) {
        if( !fontFamily.IsStyleAvailable(FontStyle.Regular) ) continue;
        this.fontFamilytoolStripItem.Items.Add(fontFamily.Name);
      }
      this.fontFamilytoolStripItem.SelectedItem = _fontFamily;

      // Load font sizes and select default
      for( int fontSize = 6; fontSize <= 130; fontSize++ ) {
        this.fontSizetoolStripItem.Items.Add(fontSize);
      }
      this.fontSizetoolStripItem.SelectedItem = _fontSize;

      // When any font details change, we need to reflect it
      this.fontFamilytoolStripItem.TextChanged += currentFont_Changed;
      this.fontSizetoolStripItem.TextChanged += currentFont_Changed;
      this.lettersTextBox.TextChanged += currentFont_Changed;
      this.boldToolStripButton.Click += currentFont_Changed;
      this.italicToolStripButton.Click += currentFont_Changed;
      this.strikeOutToolStripButton.Click += currentFont_Changed;
      this.underlineToolStripButton.Click += currentFont_Changed;
    }

    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }

    private void currentFont_Changed(object sender, EventArgs e) {
      this.textRendererDrawTextlPanel.Invalidate();
      this.graphicsDrawStringPanel.Invalidate();
    }

    private void splitContainer1_SplitterMoved(object sender, SplitterEventArgs e) {
      this.textRendererDrawTextlPanel.Invalidate();
      this.graphicsDrawStringPanel.Invalidate();
    }

    // Using TextRenderer.DrawText()
    private void textRendererDrawTextlPanel_Paint(object sender, PaintEventArgs e) {

      using( Font font = GetFont() ) {

        Graphics g = e.Graphics;

        FontSizes fontSizes = new FontSizes(font, g);
        float lineSpacing = fontSizes.LineSpacingInPixels;
        float cellAscent = fontSizes.CellAscentInPixels;
        float cellDescent = fontSizes.CellDescentInPixels;
        float leading = fontSizes.LeadingInPixels;
        Size cellSize = TextRenderer.MeasureText(e.Graphics, this.lettersTextBox.Text, font);
        int cellWidth = cellSize.Width;
        int x = 50;
        int y = 30 + (int)Math.Ceiling(cellAscent);

        using( Font descriptorFont = new Font("Arial", 8) ) {
          DrawMarker(g, descriptorFont, Color.Black, x, y, 20, "Baseline");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth, y - cellAscent, y, x, "CellAscent");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 50, y, y + cellDescent, x, "CellDescent");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 100, y + cellDescent, y + cellDescent + leading, x, "Leading");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 150, y - cellAscent, y - cellAscent + lineSpacing, x, "LineSpacing");
        }

        TextRenderer.DrawText(g, this.lettersTextBox.Text, font, new Point(x, y - fontSizes.CellAscentInPixelsRounded), Color.Black, TextFormatFlags.Default);

        this.propertyGrid.SelectedObject = fontSizes;
      }
    }

    // Using Graphics.DrawString()
    private void graphicsDrawStringPanel_Paint(object sender, PaintEventArgs e) {

      using( Font font = GetFont() ) {

        Graphics g = e.Graphics;

        FontSizes fontSizes = new FontSizes(font, g);
        float lineSpacing = fontSizes.LineSpacingInPixels;
        float cellAscent = fontSizes.CellAscentInPixels;
        float cellDescent = fontSizes.CellDescentInPixels;
        float leading = fontSizes.LeadingInPixels;
        Size cellSize = g.MeasureString(this.lettersTextBox.Text, font).ToSize();
        int cellWidth = cellSize.Width;
        int x = 50;
        int y = 30 + (int)Math.Ceiling(cellAscent);

        using( Font descriptorFont = new Font("Arial", 8) ) {
          DrawMarker(g, descriptorFont, Color.Black, x, y, 20, "Baseline");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth, y - cellAscent, y, x, "CellAscent");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 50, y, y + cellDescent, x, "CellDescent");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 100, y + cellDescent, y + cellDescent + leading, x, "Leading");
          DrawBar(g, descriptorFont, Color.Black, x + cellWidth + 150, y - cellAscent, y - cellAscent + lineSpacing, x, "LineSpacing");
        }

        g.DrawString(this.lettersTextBox.Text, font, Brushes.Black, x, y - cellAscent);
      }
    }

    private void DrawBar(Graphics g, Font font, Color color, float x, float y1, float y2, int cellLeft, string label) {
      using( Pen pen = new Pen(color) ) {
        pen.DashStyle = DashStyle.Dash;
        g.DrawLine(pen, x, y1, x, y2);
        g.DrawLine(pen, x - 10, y1, x + 10, y1);
        g.DrawLine(pen, cellLeft - 10, y2, x + 10, y2);
        using( StringFormat format = new StringFormat() ) {
          format.Alignment = StringAlignment.Center;
          using( Brush brush = new SolidBrush(color) ) {
            g.DrawString(label, font, brush, x, y1 - font.GetHeight(g), format);
          }
        }
      }
    }

    private void DrawMarker(Graphics g, Font font, Color color, int x, int y, int size, string label) {
      using( Pen pen = new Pen(color, 1) ) {
        pen.EndCap = LineCap.ArrowAnchor;
        g.DrawLine(pen, x - size, y - size, x - 10, y);
        int labelX = x - size - TextRenderer.MeasureText(g, label, font).Width / 2;
        TextRenderer.DrawText(g, label, font, new Point(labelX, y - font.Height - size - 2), color);
      }
    }

    private Font GetFont() {
      // Get font family name
      string fontFamily = this.fontFamilytoolStripItem.Text;

      // Get font size
      int fontSize;
      if( !int.TryParse(this.fontSizetoolStripItem.Text, out fontSize) ) {
        fontSize = 10;
      }

      // Get font style
      FontStyle style = new FontStyle();
      if( this.boldToolStripButton.Checked ) style = style | FontStyle.Bold;
      if( this.italicToolStripButton.Checked ) style = style | FontStyle.Italic;
      if( this.strikeOutToolStripButton.Checked ) style = style | FontStyle.Strikeout;
      if( this.underlineToolStripButton.Checked ) style = style | FontStyle.Underline;

      return new Font(fontFamily, fontSize, style, GraphicsUnit.Point);
    }
  }

  public class FontSizes {

    private int _height;
    private float _getHeight;
    private float _size;
    private float _sizeInPoints;
    private GraphicsUnit _unit;
    private int _lineSpacing;
    private int _cellAscent;
    private int _cellDescent;
    private int _leading;

    private float _lineSpacingInPixels;
    private float _cellAscentInPixels;
    private float _cellDescentInPixels;
    private float _leadingInPixels;

    public FontSizes(Font font, Graphics g) {

      _height = font.Height;
      _getHeight = font.GetHeight();
      _size = font.Size;
      _sizeInPoints = font.SizeInPoints;
      _unit = font.Unit;

      _lineSpacing = font.FontFamily.GetLineSpacing(font.Style);
      _cellAscent = font.FontFamily.GetCellAscent(font.Style);
      _cellDescent = font.FontFamily.GetCellDescent(font.Style);
      _leading = _lineSpacing - _cellAscent - _cellDescent;

      _lineSpacingInPixels = GetPixelsFromDesignUnits(font.FontFamily.GetLineSpacing(font.Style), font, g.DpiY);
      _cellAscentInPixels = GetPixelsFromDesignUnits(font.FontFamily.GetCellAscent(font.Style), font, g.DpiY);
      _cellDescentInPixels = GetPixelsFromDesignUnits(font.FontFamily.GetCellDescent(font.Style), font, g.DpiY);
      _leadingInPixels = _lineSpacingInPixels - _cellAscentInPixels - _cellDescentInPixels;
    }

    [Category("Native Font Sizes")]
    public int Height { get { return _height; } }
    [Category("Native Font Sizes")]
    public float GetHeight { get { return _getHeight; } }
    [Category("Native Font Sizes")]
    public float Size { get { return _size; } }
    [Category("Native Font Sizes")]
    public float SizeInPoints { get { return _sizeInPoints; } }
    [Category("Native Font Sizes")]
    public GraphicsUnit Unit { get { return _unit; } }

    [Category("Font Family Sizes")]
    public float LineSpacing { get { return _lineSpacing; } }
    [Category("Font Family Sizes")]
    public float CellAscent { get { return _cellAscent; } }
    [Category("Font Family Sizes")]
    public float CellDescent { get { return _cellDescent; } }
    [Category("Font Family Sizes")]
    public float Leading { get { return _leading; } }

    [Category("Font Family Sizes in Pixels Float")]
    public float LineSpacingInPixels { get { return _lineSpacingInPixels; } }
    [Category("Font Family Sizes in Pixels Float")]
    public float CellAscentInPixels { get { return _cellAscentInPixels; } }
    [Category("Font Family Sizes in Pixels Float")]
    public float CellDescentInPixels { get { return _cellDescentInPixels; } }
    [Category("Font Family Sizes in Pixels Float")]
    public float LeadingInPixels { get { return _leadingInPixels; } }

    [Category("Font Family Sizes in Pixels Int")]
    public int LineSpacingInPixelsRounded { get { return (int)Math.Round(_lineSpacingInPixels, 0, MidpointRounding.AwayFromZero); } }
    [Category("Font Family Sizes in Pixels Int")]
    public int CellAscentInPixelsRounded { get { return (int)Math.Round(_cellAscentInPixels, 0, MidpointRounding.AwayFromZero); } }
    [Category("Font Family Sizes in Pixels Int")]
    public int CellDescentInPixelsRounded { get { return (int)Math.Round(_cellDescentInPixels, 0, MidpointRounding.AwayFromZero); } }
    [Category("Font Family Sizes in Pixels Int")]
    public int LeadingInPixelsRounded { get { return (int)Math.Round(_leadingInPixels, 0, MidpointRounding.AwayFromZero); } }

    private float GetPixelsFromPoints(float points, float dpi) {
      return (dpi * points) / 72f;
    }

    private float GetPixelsFromDesignUnits(float designUnits, Font font, float dpi) {
      float scale = GetPixelsFromPoints(font.Size, dpi) / font.FontFamily.GetEmHeight(font.Style);
      return designUnits * scale;
    }
  }
}
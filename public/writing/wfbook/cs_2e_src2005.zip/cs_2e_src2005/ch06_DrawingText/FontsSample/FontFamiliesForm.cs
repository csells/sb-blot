﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class FontFamiliesForm : Form {
    public FontFamiliesForm() {
      InitializeComponent();
    }

    private void FontFamiliesForm_Load(object sender, EventArgs e) {
      foreach( FontFamily family in FontFamily.Families ) {
        // Can filter based on available styles
        if( !family.IsStyleAvailable(FontStyle.Bold) ) continue;

        familiesListBox.Items.Add(family.Name);
      }

      InstalledFontCollection installedFonts = new InstalledFontCollection();
      foreach( FontFamily family in installedFonts.Families ) {
        installedFamiliesListBox.Items.Add(family.Name);
      }
    }
  }
}
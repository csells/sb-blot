﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class FontSizesForm2 : Form {
    public FontSizesForm2() {
      InitializeComponent();
    }

    private float GetPixelsFromPoints(float points, float dpi) {
      return (dpi * points) / 72f;
    }

    private float GetPixelsFromDesignUnits(float designUnits, Font font, float dpi) {
      float scale = GetPixelsFromPoints(font.Size, dpi) / font.FontFamily.GetEmHeight(font.Style);
      return designUnits * scale;
    }

    private void DrawBar(Graphics g, Font font, float x, float y1, float y2, string label) {
      g.DrawLine(Pens.Black, x, y1, x, y2);
      g.DrawLine(Pens.Black, x - 10, y1, x + 10, y1);
      g.DrawLine(Pens.Black, x - 1000, y2, x + 10, y2);
      using( StringFormat format = new StringFormat() ) {
        format.Alignment = StringAlignment.Center;
        g.DrawString(label, font, Brushes.Black, x, y1 - font.GetHeight(g), format);
      }
    }

    private void FontSizesForm2_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      g.TextRenderingHint = TextRenderingHint.AntiAlias;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height;
      string s = "Ŷŷ";
      Font font = this.Font;
      FontFamily family = font.FontFamily;
      float lineSpacing = GetPixelsFromDesignUnits(family.GetLineSpacing(font.Style), font, g.DpiY);
      float cellAscent = GetPixelsFromDesignUnits(family.GetCellAscent(font.Style), font, g.DpiY);
      float cellDescent = GetPixelsFromDesignUnits(family.GetCellDescent(font.Style), font, g.DpiY);
      float leading = lineSpacing - cellAscent - cellDescent;
      int cellWidth = g.MeasureString(s, font).ToSize().Width;
      int x = 0;
      int y = 20 + (int)Math.Ceiling(cellAscent);

      //g.DrawLine(Pens.Black, 0, y, width, y);
      g.DrawString(s, this.Font, Brushes.Black, x, y - cellAscent);

      using( Font barFont = new Font("MS Sans Serif", 8.25f) ) {
        g.DrawString("baseline", barFont, Brushes.Black, x, y - barFont.GetHeight(g));
        DrawBar(g, barFont, x + cellWidth, y - cellAscent, y, "CellAscent");
        DrawBar(g, barFont, x + cellWidth + 50, y, y + cellDescent, "CellDescent");
        DrawBar(g, barFont, x + cellWidth + 100, y + cellDescent, y + cellDescent + leading, "Leading");
        DrawBar(g, barFont, x + cellWidth + 150, y - cellAscent, y - cellAscent + lineSpacing, "LineSpacing");
      }
    }
  }
}
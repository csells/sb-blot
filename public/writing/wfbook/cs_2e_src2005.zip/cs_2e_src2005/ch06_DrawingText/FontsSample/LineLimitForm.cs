﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class LineLimitForm : Form {
    public LineLimitForm() {
      InitializeComponent();
    }

    string s = "line 1\nline 2\nline 3\nline 4\nline 5\nline 6\nline 7\nline 8\nline 9\nline 10";

    private void panel1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( StringFormat format = new StringFormat() ) {
        Rectangle rect = panel1.ClientRectangle;
        rect.Inflate(-10, -10);
        g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
      }
    }

    private void panel2_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( StringFormat format = new StringFormat(StringFormatFlags.LineLimit) ) {
        Rectangle rect = panel1.ClientRectangle;
        rect.Inflate(-10, -10);
        g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
      }
    }

    private void panel3_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( StringFormat format = new StringFormat(StringFormatFlags.NoClip) ) {
        Rectangle rect = panel1.ClientRectangle;
        rect.Inflate(-10, -10);
        g.DrawString(s, panel1.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
      }
    }

    private void LineLimitForm_Layout(object sender, LayoutEventArgs e) {
      this.panel1.Refresh();
      this.panel2.Refresh();
      this.panel3.Refresh();
    }

  }
}
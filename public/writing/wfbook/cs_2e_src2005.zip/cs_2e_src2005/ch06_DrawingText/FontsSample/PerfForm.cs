﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace FontsSample {
  partial class PerfForm : Form {
    public PerfForm() {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
    
    }

    private void Form1_Click(object sender, EventArgs e)
    {
      string msg = "test test test test";
      
      DateTime start1 = DateTime.Now;
      int count1 = 0;
      Graphics g = this.CreateGraphics();
      while( DateTime.Now < start1.AddSeconds(10) ) {
        SizeF size = g.MeasureString(msg, this.Font);
        g.DrawString(msg, this.Font, Brushes.Black, 0, 0);
        count1++;
      }

      DateTime start2 = DateTime.Now;
      int count2 = 0;
      while( DateTime.Now < start2.AddSeconds(10) ) {
        Size size = TextRenderer.MeasureText(g, msg, this.Font);
        TextRenderer.DrawText(g, msg, this.Font, new Point(0, 0), Color.Black);
        count2++;
      }
      
      MessageBox.Show("Graphics: " + count1.ToString() + ", TextRenderer: " + count2.ToString());
    }
  }
}
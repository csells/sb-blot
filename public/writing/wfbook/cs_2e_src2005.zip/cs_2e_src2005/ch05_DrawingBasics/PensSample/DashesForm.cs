﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace PensSample {
  partial class DashesForm : Form {
    public DashesForm() {
      InitializeComponent();
    }

    private void DashesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] dashNames = Enum.GetNames(typeof(DashStyle));
      Array.Sort(dashNames);

      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 2;
      int height = this.ClientRectangle.Height / ((dashNames.Length) / 2);
      Brush blackBrush = Brushes.Black;

      //Debug.Assert(dashNames.Length % 2 == 0);

      foreach( string dashName in dashNames ) {
        using( Pen pen = new Pen(Color.Black, 12) ) {
          pen.DashStyle = (DashStyle)Enum.Parse(typeof(DashStyle), dashName);
//          pen.DashCap = DashCap.Triangle;
          if( pen.DashStyle == DashStyle.Custom ) {
            // Set increasing dashes with constant spaces
            pen.DashPattern = new float[] { 1f, 1f, 2f, 1f, 3f, 1f, 4f,1f, };
          }
          g.DrawLine(pen, x + 10, y + height * 2 / 3, x + width - 20, y + height * 2 / 3);
          g.DrawString(dashName, this.Font, blackBrush, x + 10, y);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }
    }
  }
}
﻿namespace PensSample {
  partial class PensSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.lineCapsButton = new System.Windows.Forms.Button();
      this.dashesButton = new System.Windows.Forms.Button();
      this.alignmentsButton = new System.Windows.Forms.Button();
      this.joinsButton = new System.Windows.Forms.Button();
      this.compoundsButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
// 
// lineCapsButton
// 
      this.lineCapsButton.Location = new System.Drawing.Point(30, 13);
      this.lineCapsButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.lineCapsButton.Name = "lineCapsButton";
      this.lineCapsButton.Size = new System.Drawing.Size(122, 23);
      this.lineCapsButton.TabIndex = 0;
      this.lineCapsButton.Text = "Line Caps";
      this.lineCapsButton.Click += new System.EventHandler(this.lineCapsButton_Click);
// 
// dashesButton
// 
      this.dashesButton.Location = new System.Drawing.Point(30, 41);
      this.dashesButton.Name = "dashesButton";
      this.dashesButton.Size = new System.Drawing.Size(122, 23);
      this.dashesButton.TabIndex = 1;
      this.dashesButton.Text = "Dashes";
      this.dashesButton.Click += new System.EventHandler(this.dashesButton_Click);
// 
// alignmentsButton
// 
      this.alignmentsButton.Location = new System.Drawing.Point(30, 69);
      this.alignmentsButton.Name = "alignmentsButton";
      this.alignmentsButton.Size = new System.Drawing.Size(122, 23);
      this.alignmentsButton.TabIndex = 2;
      this.alignmentsButton.Text = "Alignments";
      this.alignmentsButton.Click += new System.EventHandler(this.alignmentsButton_Click);
// 
// joinsButton
// 
      this.joinsButton.Location = new System.Drawing.Point(30, 97);
      this.joinsButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.joinsButton.Name = "joinsButton";
      this.joinsButton.Size = new System.Drawing.Size(122, 23);
      this.joinsButton.TabIndex = 3;
      this.joinsButton.Text = "Joins";
      this.joinsButton.Click += new System.EventHandler(this.joinsButton_Click);
// 
// compoundsButton
// 
      this.compoundsButton.Location = new System.Drawing.Point(30, 125);
      this.compoundsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.compoundsButton.Name = "compoundsButton";
      this.compoundsButton.Size = new System.Drawing.Size(122, 23);
      this.compoundsButton.TabIndex = 4;
      this.compoundsButton.Text = "Compounds";
      this.compoundsButton.Click += new System.EventHandler(this.compoundsButton_Click);
// 
// PensSampleForm
// 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(182, 161);
      this.Controls.Add(this.compoundsButton);
      this.Controls.Add(this.joinsButton);
      this.Controls.Add(this.alignmentsButton);
      this.Controls.Add(this.dashesButton);
      this.Controls.Add(this.lineCapsButton);
      this.Name = "PensSampleForm";
      this.Text = "Pens Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button lineCapsButton;
    private System.Windows.Forms.Button dashesButton;
    private System.Windows.Forms.Button alignmentsButton;
    private System.Windows.Forms.Button joinsButton;
    private System.Windows.Forms.Button compoundsButton;
  }
}


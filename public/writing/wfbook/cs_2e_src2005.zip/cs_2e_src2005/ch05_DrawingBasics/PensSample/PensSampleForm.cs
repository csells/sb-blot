﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace PensSample {
  partial class PensSampleForm : Form {
    public PensSampleForm() {
      InitializeComponent();
    }

    private void lineCapsButton_Click(object sender, EventArgs e) {
      (new LineCapsForm()).ShowDialog();
    }

    private void dashesButton_Click(object sender, EventArgs e) {
      (new DashesForm()).ShowDialog();
    }

    private void alignmentsButton_Click(object sender, EventArgs e) {
      (new AlignmentsForm()).ShowDialog();
    }

    private void joinsButton_Click(object sender, EventArgs e) {
      (new JoinsForm()).ShowDialog();
    }

    private void compoundsButton_Click(object sender, EventArgs e) {
      (new CompoundsForm()).ShowDialog();
    }
  }
}
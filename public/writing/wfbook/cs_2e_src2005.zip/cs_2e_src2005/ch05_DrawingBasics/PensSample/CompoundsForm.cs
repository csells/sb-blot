﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace PensSample {
  partial class CompoundsForm : Form {
    public CompoundsForm() {
      InitializeComponent();
    }

    private void CompoundForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Pen pen = new Pen(Color.Black, 20) ) {
        // Set percentages of width where line starts, then space starts,
        // then line starts again in alternating pattern
        pen.CompoundArray =
          new float[] { 0.0f, 0.25f, 0.45f, 0.55f, 0.75f,1.0f, };
        g.DrawRectangle(pen, new Rectangle(20, 20, this.ClientRectangle.Width - 40, this.ClientRectangle.Height - 40));
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace PensSample {
  partial class MiterClippedJoinsForm : Form {
    public MiterClippedJoinsForm() {
      InitializeComponent();

      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    private void JoinsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] joinNames = Enum.GetNames(typeof(LineJoin));
      Array.Sort(joinNames);

      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height / 4;
      int x = this.ClientRectangle.Width / 4;
      int y = 0; 
      Brush blackBrush = Brushes.Black;
      Pen whitePen = System.Drawing.Pens.White;

      // MiterClipped Join
      using( Pen blackPen = new Pen(Color.Black, 10) ) {
        
        blackPen.LineJoin = LineJoin.MiterClipped;
        blackPen.MiterLimit = 5.0F;
        
        for( int i = 1; i <= 4; ++i ) {
          GraphicsPath path = new GraphicsPath();
          path.AddLine(x, y + 20, x + (width / 2), y + 20);
          path.AddLine(x + (width / 2), y + 20, x + (i * 20), y + 50);
          g.DrawPath(blackPen, path);
          
          y += height;
        }
      }
    }
  }
}
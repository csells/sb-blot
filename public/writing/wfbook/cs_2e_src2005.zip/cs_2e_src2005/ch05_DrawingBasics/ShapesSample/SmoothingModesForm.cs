﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ShapesSample {
  partial class SmoothingModesForm : Form {
    public SmoothingModesForm() {
      InitializeComponent();
    }

    private void SmoothingModesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 2;
      int height = this.ClientRectangle.Height;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;
      int fontHeight = this.FontHeight;
      
      using( Pen pen = new Pen(Color.Red, 4) ) {

        g.SmoothingMode = SmoothingMode.None;
        g.DrawCurve(pen, new Point[] { new Point(x + 20, y + height - fontHeight - 20), new Point(x + width - 20, y + height - fontHeight - 20), new Point(x + 20, y + 20), new Point(x + width - 20, y + 20), }, 1.0f);
        g.DrawString(g.SmoothingMode.ToString(), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
        
        g.SmoothingMode = SmoothingMode.AntiAlias;
        g.DrawCurve(pen, new Point[] { new Point(x + 20, y + height - fontHeight - 20), new Point(x + width - 20, y + height - fontHeight - 20), new Point(x + 20, y + 20), new Point(x + width - 20, y + 20), }, 1.0f);
        g.DrawString(g.SmoothingMode.ToString(), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
    }
  }
}
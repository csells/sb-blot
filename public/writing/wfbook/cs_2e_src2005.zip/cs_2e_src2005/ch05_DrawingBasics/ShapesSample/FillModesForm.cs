﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ShapesSample {
  partial class FillModesForm : Form {
    public FillModesForm() {
      InitializeComponent();
    }

    private void FillModesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 2;
      int height = this.ClientRectangle.Height;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = System.Drawing.Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( Pen pen = new Pen(Color.Red, 4) )
      using( Pen pointPen = new Pen(Color.Black, 3) ) {
        pointPen.StartCap = pointPen.EndCap = LineCap.SquareAnchor;
        FillMode fill = FillMode.Winding;
        Point[] points = null;

        fill = FillMode.Winding;
        points = new Point[] { new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, height / 2), new Point(x + width - 25, y + 25), new Point(x + 25, y + 25), new Point(x + width - 25, height / 2), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.FillClosedCurve(fillBrush, points, fill);
        g.DrawClosedCurve(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        g.DrawString(string.Format("FillMode= {0}", fill), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        fill = FillMode.Alternate;
        points = new Point[] { new Point(x + 25, y + height - 25), new Point(x + width - 25, y + height - 25), new Point(x + 25, height / 2), new Point(x + width - 25, y + 25), new Point(x + 25, y + 25), new Point(x + width - 25, height / 2), };
        g.DrawRectangle(Pens.Black, x, y, width, height);
        g.FillClosedCurve(fillBrush, points, fill);
        g.DrawClosedCurve(pen, points);
        foreach( Point point in points ) g.DrawLine(pointPen, new Point(point.X, point.Y), new Point(point.X + 1, point.Y));
        for( int i = 0; i != points.Length; ++i ) g.DrawString(i.ToString(), this.Font, blackBrush, points[i]);
        g.DrawString(string.Format("FillMode= {0}", fill), this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

      }
    }
  }
}
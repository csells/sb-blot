﻿namespace ShapesSample {
  partial class ShapesSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.shapesButton = new System.Windows.Forms.Button();
      this.curvesButton = new System.Windows.Forms.Button();
      this.bezierCurvesButton = new System.Windows.Forms.Button();
      this.fillModesButton = new System.Windows.Forms.Button();
      this.smoothingModesButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // shapesButton
      // 
      this.shapesButton.Location = new System.Drawing.Point(31, 13);
      this.shapesButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.shapesButton.Name = "shapesButton";
      this.shapesButton.Size = new System.Drawing.Size(113, 23);
      this.shapesButton.TabIndex = 0;
      this.shapesButton.Text = "Shapes";
      this.shapesButton.Click += new System.EventHandler(this.shapesButton_Click);
      // 
      // curvesButton
      // 
      this.curvesButton.Location = new System.Drawing.Point(31, 41);
      this.curvesButton.Name = "curvesButton";
      this.curvesButton.Size = new System.Drawing.Size(113, 23);
      this.curvesButton.TabIndex = 1;
      this.curvesButton.Text = "Curves";
      this.curvesButton.Click += new System.EventHandler(this.curvesButton_Click);
      // 
      // bezierCurvesButton
      // 
      this.bezierCurvesButton.Location = new System.Drawing.Point(31, 69);
      this.bezierCurvesButton.Name = "bezierCurvesButton";
      this.bezierCurvesButton.Size = new System.Drawing.Size(113, 23);
      this.bezierCurvesButton.TabIndex = 2;
      this.bezierCurvesButton.Text = "Bezier Curves";
      this.bezierCurvesButton.Click += new System.EventHandler(this.bezierCurvesButton_Click);
      // 
      // fillModesButton
      // 
      this.fillModesButton.Location = new System.Drawing.Point(31, 97);
      this.fillModesButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.fillModesButton.Name = "fillModesButton";
      this.fillModesButton.Size = new System.Drawing.Size(113, 23);
      this.fillModesButton.TabIndex = 3;
      this.fillModesButton.Text = "Fill Modes";
      this.fillModesButton.Click += new System.EventHandler(this.fillModesButton_Click);
      // 
      // smoothingModesButton
      // 
      this.smoothingModesButton.Location = new System.Drawing.Point(31, 125);
      this.smoothingModesButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.smoothingModesButton.Name = "smoothingModesButton";
      this.smoothingModesButton.Size = new System.Drawing.Size(113, 23);
      this.smoothingModesButton.TabIndex = 4;
      this.smoothingModesButton.Text = "Smoothing Modes";
      this.smoothingModesButton.Click += new System.EventHandler(this.smoothingModesButton_Click);
      // 
      // ShapesSampleForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(179, 161);
      this.Controls.Add(this.smoothingModesButton);
      this.Controls.Add(this.fillModesButton);
      this.Controls.Add(this.bezierCurvesButton);
      this.Controls.Add(this.curvesButton);
      this.Controls.Add(this.shapesButton);
      this.Name = "ShapesSampleForm";
      this.Text = "Shapes";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button shapesButton;
    private System.Windows.Forms.Button curvesButton;
    private System.Windows.Forms.Button bezierCurvesButton;
    private System.Windows.Forms.Button fillModesButton;
    private System.Windows.Forms.Button smoothingModesButton;
  }
}


﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace ShapesSample {
  partial class ShapesSampleForm : Form {
    public ShapesSampleForm() {
      InitializeComponent();
    }

    private void shapesButton_Click(object sender, EventArgs e) {
      (new ShapesForm()).ShowDialog();
    }

    private void curvesButton_Click(object sender, EventArgs e) {
      (new CurvesForm()).ShowDialog();
    }

    private void bezierCurvesButton_Click(object sender, EventArgs e) {
      (new BeziersForm()).ShowDialog();
    }

    private void fillModesButton_Click(object sender, EventArgs e) {
      (new FillModesForm()).ShowDialog();
    }

    private void smoothingModesButton_Click(object sender, EventArgs e) {
      (new SmoothingModesForm()).ShowDialog();
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ShapesSample {
  partial class ShapesForm : Form {
    public ShapesForm() {
      InitializeComponent();
    }

    private void ShapesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 3;
      int height = this.ClientRectangle.Height / 3;
      Brush blackBrush = Brushes.Black;
      Brush fillBrush = Brushes.Gray;
      Pen whitePen = System.Drawing.Pens.White;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      int fontHeight = this.Font.Height;
      
      using( Pen pen = new Pen(Color.Red, 4) ) {
        // Arc
        g.DrawArc(pen, x + 10, y + 10, width - 20, height - fontHeight, 180, 180);
        g.DrawString("Arc", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Bezier
        g.DrawBezier(pen, new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10));
        g.DrawString("Bezier", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Closed Curve
        g.FillClosedCurve(fillBrush, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawClosedCurve(pen, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Closed Curve", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Curve
        g.DrawCurve(pen, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Curve", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Ellipse
        g.FillEllipse(fillBrush, x + 10, y + 10, width - 20, height - fontHeight - 10);
        g.DrawEllipse(pen, x + 10, y + 10, width - 20, height - fontHeight - 10);
        g.DrawString("Ellipse", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Lines
        g.DrawLines(pen, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Lines", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Pie
        g.FillPie(fillBrush, x + 10, y + 10, width - 20, height - fontHeight - 10, 180, 180);
        g.DrawPie(pen, x + 10, y + 10, width - 20, height - fontHeight - 10, 180, 180);
        g.DrawString("Pie", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Polygon
        g.FillPolygon(fillBrush, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawPolygon(pen, new Point[] { new Point(x + 10, y + height - fontHeight - 10), new Point(x + width - 20, y + height - fontHeight - 10), new Point(x + 10, y + 10), new Point(x + width - 20, y + 10), });
        g.DrawString("Polygon", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);

        // Rectangle
        g.FillRectangle(fillBrush, x + 10, y + 10, width - 20, height - fontHeight - 10);
        g.DrawRectangle(pen, x + 10, y + 10, width - 20, height - fontHeight - 10);
        g.DrawString("Rectangle", this.Font, blackBrush, new Rectangle(x, y, width, height), format);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
    }


    void DrawOutlinedString(string s, Graphics g, RectangleF rect) {

      StringFormat format = StringFormat.GenericTypographic;
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      
      GraphicsPath path = new GraphicsPath();
      // Convert font size into appropriate coordinates
      float emSize = g.DpiY * this.Font.SizeInPoints / 72;
      path.AddString(s, this.Font.FontFamily, (int)this.Font.Style, emSize, rect, format);
      g.DrawPath(Pens.Black, path);
      g.FillPath(Brushes.White, path);
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class PanningForm : Form {
    public PanningForm() {
      InitializeComponent();
    }

    Bitmap bmp = new Bitmap(typeof(PanningForm), "Soap Bubbles.bmp");
    Size offset = new Size(0, 0);

    private void upButton_Click(object sender, EventArgs e) {
      offset.Height += 10;
      panningPanel.Refresh();
    }

    private void rightButton_Click(object sender, EventArgs e) {
      offset.Width -= 10;
      panningPanel.Refresh();
    }

    private void downButton_Click(object sender, EventArgs e) {
      offset.Height -= 10;
      panningPanel.Refresh();
    }

    private void leftButton_Click(object sender, EventArgs e) {
      offset.Width += 10;
      panningPanel.Refresh();
    }

    private void panningPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Rectangle destRect = this.panningPanel.ClientRectangle;
      Rectangle srcRect = new Rectangle(offset.Width, offset.Height, destRect.Width, destRect.Height);
      g.DrawImage(bmp, destRect, srcRect, g.PageUnit);
    }
  }
}
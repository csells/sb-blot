﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class TransparencyForm : Form {
    public TransparencyForm() {
      InitializeComponent();
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    string backgroundString = "the quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\nthe quick brown fox jumps over the lazy dog\n";

    private void TransparencyForm_Layout(object sender, LayoutEventArgs e) {
      originalColorsPanel.Refresh();
      whiteBackgroundPanel.Refresh();
      madeTransparentPanel.Refresh();
    }

    private void originalColorsPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.originalColorsPanel.ClientRectangle.Width - rect.Width) / 2, (this.originalColorsPanel.ClientRectangle.Height - rect.Height) / 2);
        g.DrawImage(bmp, rect);
      }
    }

    private void whiteBackgroundPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        // Set the image attribute's color mappings
        ColorMap[] colorMap = new ColorMap[1];
        colorMap[0] = new ColorMap();
        colorMap[0].OldColor = bmp.GetPixel(0, bmp.Height - 1);
        colorMap[0].NewColor = Color.White;
        ImageAttributes attr = new ImageAttributes();
        attr.SetRemapTable(colorMap);

        // Draw using the color map
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.whiteBackgroundPanel.ClientRectangle.Width - rect.Width) / 2, (this.whiteBackgroundPanel.ClientRectangle.Height - rect.Height) / 2);
        g.DrawImage(bmp, rect, 0, 0, rect.Width, rect.Height, g.PageUnit, attr);
      }
    }

    private void madeTransparent_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Draw the text in the background
        g.DrawString(backgroundString, this.Font, Brushes.Black, this.ClientRectangle);

        // Make the bottom left pixel the transparent color
        bmp.MakeTransparent();
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.whiteBackgroundPanel.ClientRectangle.Width - rect.Width) / 2, (this.whiteBackgroundPanel.ClientRectangle.Height - rect.Height) / 2);
        g.DrawImage(bmp, rect);

        //        // Set the image attribute's color mappings
        //        ColorMap[] colorMap = new ColorMap[1];
        //        colorMap[0] = new ColorMap();
        //        colorMap[0].OldColor = bmp.GetPixel(0, bmp.Height - 1);
        //        colorMap[0].NewColor = Color.Transparent;
        //        ImageAttributes attr = new ImageAttributes();
        //        attr.SetRemapTable(colorMap);
        //
        //        // Draw using the color map
        //        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        //        rect.Offset((this.panel2.ClientRectangle.Width - rect.Width)/2, (this.panel2.ClientRectangle.Height - rect.Height)/2);
        //        g.DrawImage(bmp, rect, 0, 0, rect.Width, rect.Height, g.PageUnit, attr);
      }
    }
  }
}
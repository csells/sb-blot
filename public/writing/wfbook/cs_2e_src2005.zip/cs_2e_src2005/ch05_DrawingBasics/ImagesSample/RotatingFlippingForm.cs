﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class RotatingFlippingForm : Form {
    public RotatingFlippingForm() {
      InitializeComponent();
    }

    private void RotatingFlippingForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] rotateFlipNames = Enum.GetNames(typeof(RotateFlipType));
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 4;
      int height = this.ClientRectangle.Height / (rotateFlipNames.Length / 4);
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      //Debug.Assert(rotateFlipNames.Length % 4 == 0);
      Array.Sort(rotateFlipNames);

      foreach( string rotateFlipName in rotateFlipNames ) {
        using( Bitmap bitmap = new Bitmap(this.GetType(), "BEANY.BMP") ) {
          RotateFlipType rotateFlip = (RotateFlipType)Enum.Parse(typeof(RotateFlipType), rotateFlipName);
          bitmap.RotateFlip(rotateFlip);
          Rectangle rect = new Rectangle(x, y, width, height);
          g.DrawImageUnscaled(bitmap, x, y);
          g.DrawRectangle(blackPen, rect);
          g.DrawString(rotateFlipName, this.Font, blackBrush, rect, format);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }
    }
  }
}
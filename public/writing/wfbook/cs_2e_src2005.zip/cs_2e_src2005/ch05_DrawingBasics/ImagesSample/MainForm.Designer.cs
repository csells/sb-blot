﻿namespace ImagesSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.scalingClippingButton = new System.Windows.Forms.Button();
      this.panningButton = new System.Windows.Forms.Button();
      this.skewingButton = new System.Windows.Forms.Button();
      this.rotatingFlippingButton = new System.Windows.Forms.Button();
      this.recoloringButton = new System.Windows.Forms.Button();
      this.transparencyButton = new System.Windows.Forms.Button();
      this.animationButton = new System.Windows.Forms.Button();
      this.drawingToImagesButton = new System.Windows.Forms.Button();
      this.iconsButton = new System.Windows.Forms.Button();
      this.cursorsButton = new System.Windows.Forms.Button();
      this.pictureBoxAnimationButton = new System.Windows.Forms.Button();
      this.animatedCursorsButton = new System.Windows.Forms.Button();
      this.coloredCursorsButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // scalingClippingButton
      // 
      this.scalingClippingButton.Location = new System.Drawing.Point(13, 13);
      this.scalingClippingButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.scalingClippingButton.Name = "scalingClippingButton";
      this.scalingClippingButton.Size = new System.Drawing.Size(126, 23);
      this.scalingClippingButton.TabIndex = 0;
      this.scalingClippingButton.Text = "Scaling vs Clipping";
      this.scalingClippingButton.Click += new System.EventHandler(this.scalingClippingButton_Click);
      // 
      // panningButton
      // 
      this.panningButton.Location = new System.Drawing.Point(13, 39);
      this.panningButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.panningButton.Name = "panningButton";
      this.panningButton.Size = new System.Drawing.Size(126, 23);
      this.panningButton.TabIndex = 1;
      this.panningButton.Text = "Panning";
      this.panningButton.Click += new System.EventHandler(this.panningButton_Click);
      // 
      // skewingButton
      // 
      this.skewingButton.Location = new System.Drawing.Point(13, 65);
      this.skewingButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.skewingButton.Name = "skewingButton";
      this.skewingButton.Size = new System.Drawing.Size(126, 23);
      this.skewingButton.TabIndex = 2;
      this.skewingButton.Text = "Skewing";
      this.skewingButton.Click += new System.EventHandler(this.skewingButton_Click);
      // 
      // rotatingFlippingButton
      // 
      this.rotatingFlippingButton.Location = new System.Drawing.Point(13, 91);
      this.rotatingFlippingButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.rotatingFlippingButton.Name = "rotatingFlippingButton";
      this.rotatingFlippingButton.Size = new System.Drawing.Size(126, 23);
      this.rotatingFlippingButton.TabIndex = 3;
      this.rotatingFlippingButton.Text = "Rotating and Flipping";
      this.rotatingFlippingButton.Click += new System.EventHandler(this.rotatingFlippingButton_Click);
      // 
      // recoloringButton
      // 
      this.recoloringButton.Location = new System.Drawing.Point(13, 117);
      this.recoloringButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.recoloringButton.Name = "recoloringButton";
      this.recoloringButton.Size = new System.Drawing.Size(126, 23);
      this.recoloringButton.TabIndex = 4;
      this.recoloringButton.Text = "Re-Coloring";
      this.recoloringButton.Click += new System.EventHandler(this.recoloringButton_Click);
      // 
      // transparencyButton
      // 
      this.transparencyButton.Location = new System.Drawing.Point(13, 143);
      this.transparencyButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 1);
      this.transparencyButton.Name = "transparencyButton";
      this.transparencyButton.Size = new System.Drawing.Size(126, 23);
      this.transparencyButton.TabIndex = 5;
      this.transparencyButton.Text = "Transparency";
      this.transparencyButton.Click += new System.EventHandler(this.transparencyButton_Click);
      // 
      // animationButton
      // 
      this.animationButton.Location = new System.Drawing.Point(13, 169);
      this.animationButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.animationButton.Name = "animationButton";
      this.animationButton.Size = new System.Drawing.Size(126, 23);
      this.animationButton.TabIndex = 6;
      this.animationButton.Text = "Animation";
      this.animationButton.Click += new System.EventHandler(this.animationButton_Click);
      // 
      // drawingToImagesButton
      // 
      this.drawingToImagesButton.Location = new System.Drawing.Point(13, 221);
      this.drawingToImagesButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.drawingToImagesButton.Name = "drawingToImagesButton";
      this.drawingToImagesButton.Size = new System.Drawing.Size(126, 23);
      this.drawingToImagesButton.TabIndex = 8;
      this.drawingToImagesButton.Text = "Drawing to Images";
      this.drawingToImagesButton.Click += new System.EventHandler(this.drawingToImagesButton_Click);
      // 
      // iconsButton
      // 
      this.iconsButton.Location = new System.Drawing.Point(13, 247);
      this.iconsButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 2);
      this.iconsButton.Name = "iconsButton";
      this.iconsButton.Size = new System.Drawing.Size(126, 23);
      this.iconsButton.TabIndex = 9;
      this.iconsButton.Text = "Icons";
      this.iconsButton.Click += new System.EventHandler(this.iconsButton_Click);
      // 
      // cursorsButton
      // 
      this.cursorsButton.Location = new System.Drawing.Point(13, 273);
      this.cursorsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.cursorsButton.Name = "cursorsButton";
      this.cursorsButton.Size = new System.Drawing.Size(126, 23);
      this.cursorsButton.TabIndex = 10;
      this.cursorsButton.Text = "Cursors";
      this.cursorsButton.Click += new System.EventHandler(this.cursorsButton_Click);
      // 
      // pictureBoxAnimationButton
      // 
      this.pictureBoxAnimationButton.Location = new System.Drawing.Point(13, 195);
      this.pictureBoxAnimationButton.Name = "pictureBoxAnimationButton";
      this.pictureBoxAnimationButton.Size = new System.Drawing.Size(126, 23);
      this.pictureBoxAnimationButton.TabIndex = 7;
      this.pictureBoxAnimationButton.Text = "PictureBox Animation";
      this.pictureBoxAnimationButton.Click += new System.EventHandler(this.pictureBoxAnimationButton_Click);
      // 
      // animatedCursorsButton
      // 
      this.animatedCursorsButton.Location = new System.Drawing.Point(12, 301);
      this.animatedCursorsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.animatedCursorsButton.Name = "animatedCursorsButton";
      this.animatedCursorsButton.Size = new System.Drawing.Size(126, 23);
      this.animatedCursorsButton.TabIndex = 11;
      this.animatedCursorsButton.Text = "Animated Cursors";
      this.animatedCursorsButton.Click += new System.EventHandler(this.animatedCursorsButton_Click);
      // 
      // coloredCursorsButton
      // 
      this.coloredCursorsButton.Location = new System.Drawing.Point(13, 329);
      this.coloredCursorsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.coloredCursorsButton.Name = "coloredCursorsButton";
      this.coloredCursorsButton.Size = new System.Drawing.Size(126, 23);
      this.coloredCursorsButton.TabIndex = 12;
      this.coloredCursorsButton.Text = "Colored Cursors";
      this.coloredCursorsButton.Click += new System.EventHandler(this.coloredCursorsButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(151, 362);
      this.Controls.Add(this.coloredCursorsButton);
      this.Controls.Add(this.animatedCursorsButton);
      this.Controls.Add(this.pictureBoxAnimationButton);
      this.Controls.Add(this.cursorsButton);
      this.Controls.Add(this.iconsButton);
      this.Controls.Add(this.drawingToImagesButton);
      this.Controls.Add(this.animationButton);
      this.Controls.Add(this.transparencyButton);
      this.Controls.Add(this.recoloringButton);
      this.Controls.Add(this.rotatingFlippingButton);
      this.Controls.Add(this.skewingButton);
      this.Controls.Add(this.panningButton);
      this.Controls.Add(this.scalingClippingButton);
      this.Name = "MainForm";
      this.Text = "Images";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button scalingClippingButton;
    private System.Windows.Forms.Button panningButton;
    private System.Windows.Forms.Button skewingButton;
    private System.Windows.Forms.Button rotatingFlippingButton;
    private System.Windows.Forms.Button recoloringButton;
    private System.Windows.Forms.Button transparencyButton;
    private System.Windows.Forms.Button animationButton;
    private System.Windows.Forms.Button drawingToImagesButton;
    private System.Windows.Forms.Button iconsButton;
    private System.Windows.Forms.Button cursorsButton;
    private System.Windows.Forms.Button pictureBoxAnimationButton;
    private System.Windows.Forms.Button animatedCursorsButton;
    private System.Windows.Forms.Button coloredCursorsButton;
  }
}


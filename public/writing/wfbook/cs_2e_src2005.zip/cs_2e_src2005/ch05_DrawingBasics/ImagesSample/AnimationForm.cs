﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class AnimationForm : Form {
    public AnimationForm() {
      InitializeComponent();
      
      //this.animatedLabel.Image = Image.FromFile(@"c:\animatedgif.gif");
    }

    // Load animated GIF
    Bitmap gif = new Bitmap(typeof(AnimationForm), "AnimatedGif.GIF");
    int currentFrame;
    int frameCount;
    
    private void AnimationForm_Load(object sender, EventArgs e) {
      // Set client size to size of image
      this.SetClientSizeCore(gif.Width, gif.Height + statusStrip1.Height);

      // Check if image supports animation
      if( ImageAnimator.CanAnimate(gif) ) {
        // Subscribe to an event indicating the next frame should be shown
        ImageAnimator.Animate(gif, gif_FrameChanged);
        currentFrame = 1;
        frameCount = gif.GetFrameCount(FrameDimension.Time);
        this.toolStripStatusLabel1.Text = string.Format("Frame {0} of {1}", currentFrame, frameCount);
      }
      else {
        this.toolStripStatusLabel1.Text = "Can't animate";
      }
    }

    private void AnimationForm_Paint(object sender, PaintEventArgs e) {
      // Update image's current frame
      ImageAnimator.UpdateFrames(gif);

      // Draw image's active frame
      Graphics g = e.Graphics;
      Rectangle rect = this.ClientRectangle;
      rect.Height -= this.statusStrip1.Height;
      g.DrawImage(gif, rect);
    }
    
    private void gif_FrameChanged(object sender, EventArgs e) {
      if( this.InvokeRequired ) {
        // Transition from worker thread to UI thread
        this.BeginInvoke(
          new EventHandler(gif_FrameChanged),
          new object[] { sender, e });
      }
      else {
        currentFrame++;
        this.toolStripStatusLabel1.Text = string.Format("Frame {0} of {1}", currentFrame, frameCount);
        if( currentFrame == frameCount ) currentFrame = 0;

        // Trigger Paint event to draw next frame
        this.Invalidate();
      }
    }
  }
}
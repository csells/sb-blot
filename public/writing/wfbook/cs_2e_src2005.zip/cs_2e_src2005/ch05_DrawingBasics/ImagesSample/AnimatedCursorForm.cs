using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ImagesSample {
  public partial class AnimatedCursorForm : Form {

    [DllImport("user32.dll")]
    static extern IntPtr LoadCursorFromFile(string lpFileName);
    
    static Cursor AnimatedCursor;
    
    static AnimatedCursorForm() {
      // Load animated cursor once for the lifetime of the application
      IntPtr cursor = LoadCursorFromFile(@"c:\windows\cursors\hourglas.ani");
      AnimatedCursor = new Cursor(cursor);
    }
    
    public AnimatedCursorForm() {
      InitializeComponent();
    }
    
    private void AnimatedCursorForm_MouseEnter(object sender, EventArgs e) {
      this.Cursor = AnimatedCursor;
    }

    private void AnimatedCursorForm_MouseLeave(object sender, EventArgs e) {
      this.Cursor = Cursors.Default;
    }
  }
}
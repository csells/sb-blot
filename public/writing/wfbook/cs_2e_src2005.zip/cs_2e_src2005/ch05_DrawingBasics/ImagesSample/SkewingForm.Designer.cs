﻿namespace ImagesSample {
  partial class SkewingForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.leftButton = new System.Windows.Forms.Button();
      this.rightButton = new System.Windows.Forms.Button();
      this.downButton = new System.Windows.Forms.Button();
      this.upButton = new System.Windows.Forms.Button();
      this.skewingPanel = new System.Windows.Forms.Panel();
      this.SuspendLayout();
      // 
      // leftButton
      // 
      this.leftButton.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.leftButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.leftButton.Location = new System.Drawing.Point(13, 121);
      this.leftButton.Name = "leftButton";
      this.leftButton.Size = new System.Drawing.Size(27, 23);
      this.leftButton.TabIndex = 5;
      this.leftButton.Text = "<";
      this.leftButton.Click += new System.EventHandler(this.leftButton_Click);
      // 
      // rightButton
      // 
      this.rightButton.Anchor = System.Windows.Forms.AnchorStyles.Right;
      this.rightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rightButton.Location = new System.Drawing.Point(253, 121);
      this.rightButton.Name = "rightButton";
      this.rightButton.Size = new System.Drawing.Size(27, 23);
      this.rightButton.TabIndex = 6;
      this.rightButton.Text = ">";
      this.rightButton.Click += new System.EventHandler(this.rightButton_Click);
      // 
      // downButton
      // 
      this.downButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.downButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.downButton.Location = new System.Drawing.Point(137, 231);
      this.downButton.Name = "downButton";
      this.downButton.Size = new System.Drawing.Size(27, 23);
      this.downButton.TabIndex = 7;
      this.downButton.Text = "v";
      this.downButton.Click += new System.EventHandler(this.downButton_Click);
      // 
      // upButton
      // 
      this.upButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
      this.upButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.upButton.Location = new System.Drawing.Point(137, 13);
      this.upButton.Name = "upButton";
      this.upButton.Size = new System.Drawing.Size(27, 23);
      this.upButton.TabIndex = 8;
      this.upButton.Text = "^";
      this.upButton.Click += new System.EventHandler(this.upButton_Click);
      // 
      // skewingPanel
      // 
      this.skewingPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.skewingPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.skewingPanel.Location = new System.Drawing.Point(47, 43);
      this.skewingPanel.Name = "skewingPanel";
      this.skewingPanel.Size = new System.Drawing.Size(199, 181);
      this.skewingPanel.TabIndex = 4;
      this.skewingPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.skewingPanel_Paint);
      // 
      // SkewingForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.leftButton);
      this.Controls.Add(this.rightButton);
      this.Controls.Add(this.downButton);
      this.Controls.Add(this.upButton);
      this.Controls.Add(this.skewingPanel);
      this.Name = "SkewingForm";
      this.Text = "Skewing";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button leftButton;
    private System.Windows.Forms.Button rightButton;
    private System.Windows.Forms.Button downButton;
    private System.Windows.Forms.Button upButton;
    private System.Windows.Forms.Panel skewingPanel;
  }
}
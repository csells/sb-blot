﻿namespace ImagesSample {
  partial class TransparencyForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.groupBox3 = new System.Windows.Forms.GroupBox();
      this.originalColorsPanel = new System.Windows.Forms.Panel();
      this.splitContainer2 = new System.Windows.Forms.SplitContainer();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.whiteBackgroundPanel = new System.Windows.Forms.Panel();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.madeTransparentPanel = new System.Windows.Forms.Panel();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.groupBox3.SuspendLayout();
      this.splitContainer2.Panel1.SuspendLayout();
      this.splitContainer2.Panel2.SuspendLayout();
      this.splitContainer2.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 0);
      this.splitContainer1.Name = "splitContainer1";
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.groupBox3);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
      this.splitContainer1.Size = new System.Drawing.Size(463, 315);
      this.splitContainer1.SplitterDistance = 155;
      this.splitContainer1.TabIndex = 0;
      this.splitContainer1.Text = "splitContainer1";
      // 
      // groupBox3
      // 
      this.groupBox3.Controls.Add(this.originalColorsPanel);
      this.groupBox3.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox3.Location = new System.Drawing.Point(0, 0);
      this.groupBox3.Name = "groupBox3";
      this.groupBox3.Size = new System.Drawing.Size(155, 315);
      this.groupBox3.TabIndex = 0;
      this.groupBox3.TabStop = false;
      this.groupBox3.Text = "Original Colors";
      // 
      // originalColorsPanel
      // 
      this.originalColorsPanel.BackColor = System.Drawing.Color.White;
      this.originalColorsPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.originalColorsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.originalColorsPanel.Location = new System.Drawing.Point(3, 16);
      this.originalColorsPanel.Name = "originalColorsPanel";
      this.originalColorsPanel.Size = new System.Drawing.Size(149, 296);
      this.originalColorsPanel.TabIndex = 0;
      this.originalColorsPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.originalColorsPanel_Paint);
      // 
      // splitContainer2
      // 
      this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer2.Location = new System.Drawing.Point(0, 0);
      this.splitContainer2.Name = "splitContainer2";
      // 
      // splitContainer2.Panel1
      // 
      this.splitContainer2.Panel1.Controls.Add(this.groupBox1);
      // 
      // splitContainer2.Panel2
      // 
      this.splitContainer2.Panel2.Controls.Add(this.groupBox2);
      this.splitContainer2.Size = new System.Drawing.Size(304, 315);
      this.splitContainer2.SplitterDistance = 156;
      this.splitContainer2.TabIndex = 0;
      this.splitContainer2.Text = "splitContainer2";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.whiteBackgroundPanel);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(156, 315);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "White Background";
      // 
      // whiteBackgroundPanel
      // 
      this.whiteBackgroundPanel.BackColor = System.Drawing.Color.White;
      this.whiteBackgroundPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.whiteBackgroundPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.whiteBackgroundPanel.Location = new System.Drawing.Point(3, 16);
      this.whiteBackgroundPanel.Name = "whiteBackgroundPanel";
      this.whiteBackgroundPanel.Size = new System.Drawing.Size(150, 296);
      this.whiteBackgroundPanel.TabIndex = 0;
      this.whiteBackgroundPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.whiteBackgroundPanel_Paint);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.madeTransparentPanel);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(0, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(144, 315);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Made Transparent";
      // 
      // madeTransparentPanel
      // 
      this.madeTransparentPanel.BackColor = System.Drawing.Color.White;
      this.madeTransparentPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.madeTransparentPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.madeTransparentPanel.Location = new System.Drawing.Point(3, 16);
      this.madeTransparentPanel.Name = "madeTransparentPanel";
      this.madeTransparentPanel.Size = new System.Drawing.Size(138, 296);
      this.madeTransparentPanel.TabIndex = 0;
      this.madeTransparentPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.madeTransparent_Paint);
      // 
      // TransparencyForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(463, 315);
      this.Controls.Add(this.splitContainer1);
      this.Name = "TransparencyForm";
      this.Text = "Transparency";
      this.Layout += new System.Windows.Forms.LayoutEventHandler(this.TransparencyForm_Layout);
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.ResumeLayout(false);
      this.groupBox3.ResumeLayout(false);
      this.splitContainer2.Panel1.ResumeLayout(false);
      this.splitContainer2.Panel2.ResumeLayout(false);
      this.splitContainer2.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.SplitContainer splitContainer2;
    private System.Windows.Forms.GroupBox groupBox3;
    private System.Windows.Forms.Panel originalColorsPanel;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.Panel whiteBackgroundPanel;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel madeTransparentPanel;
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class CursorsForm : Form {
    public CursorsForm() {
      InitializeComponent();
    }

    private void CursorsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 4;
      int height = this.ClientRectangle.Height / 7;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      Cursor[] cursors = new Cursor[] { System.Windows.Forms.Cursors.Default,
                                        System.Windows.Forms.Cursors.AppStarting,
                                        System.Windows.Forms.Cursors.Arrow,
                                        System.Windows.Forms.Cursors.Cross,
                                        System.Windows.Forms.Cursors.Hand,
                                        System.Windows.Forms.Cursors.Help,
                                        System.Windows.Forms.Cursors.HSplit,
                                        System.Windows.Forms.Cursors.IBeam,
                                        System.Windows.Forms.Cursors.No,
                                        System.Windows.Forms.Cursors.NoMove2D,
                                        System.Windows.Forms.Cursors.NoMoveHoriz,
                                        System.Windows.Forms.Cursors.NoMoveVert,
                                        System.Windows.Forms.Cursors.PanEast,
                                        System.Windows.Forms.Cursors.PanNE,
                                        System.Windows.Forms.Cursors.PanNorth,
                                        System.Windows.Forms.Cursors.PanNW,
                                        System.Windows.Forms.Cursors.PanSE,
                                        System.Windows.Forms.Cursors.PanSouth,
                                        System.Windows.Forms.Cursors.PanSW,
                                        System.Windows.Forms.Cursors.PanWest,
                                        System.Windows.Forms.Cursors.SizeAll,
                                        System.Windows.Forms.Cursors.SizeNESW,
                                        System.Windows.Forms.Cursors.SizeNS,
                                        System.Windows.Forms.Cursors.SizeNWSE,
                                        System.Windows.Forms.Cursors.SizeWE,
                                        System.Windows.Forms.Cursors.UpArrow,
                                        System.Windows.Forms.Cursors.VSplit,
                                        System.Windows.Forms.Cursors.WaitCursor,
      };

      bool defaultCursor = true;
      foreach( Cursor cursor in cursors ) {
        int cursorWidth = 32;
        int cursorHeight = 32;
        Rectangle rect = new Rectangle(x, y, width, height);
        Rectangle cursorRect = new Rectangle(x + (width - cursorWidth) / 2, y + (height - cursorHeight) / 2, cursorWidth, cursorHeight);
        cursor.Draw(g, cursorRect);
        string cursorName = GetCursorName(cursor);
        if( defaultCursor ) {
          defaultCursor = false;
          cursorName = "Default";
        }
        g.DrawString(cursorName, this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
    }

    private string GetCursorName(Cursor cursor) {
      if( cursor == System.Windows.Forms.Cursors.AppStarting ) return "AppStarting";
      if( cursor == System.Windows.Forms.Cursors.Arrow ) return "Arrow";
      if( cursor == System.Windows.Forms.Cursors.Cross ) return "Cross";
      if( cursor == System.Windows.Forms.Cursors.Default ) return "Default";
      if( cursor == System.Windows.Forms.Cursors.Hand ) return "Hand";
      if( cursor == System.Windows.Forms.Cursors.Help ) return "Help";
      if( cursor == System.Windows.Forms.Cursors.HSplit ) return "HSplit";
      if( cursor == System.Windows.Forms.Cursors.IBeam ) return "IBeam";
      if( cursor == System.Windows.Forms.Cursors.No ) return "No";
      if( cursor == System.Windows.Forms.Cursors.NoMove2D ) return "NoMove2D";
      if( cursor == System.Windows.Forms.Cursors.NoMoveHoriz ) return "NoMoveHoriz";
      if( cursor == System.Windows.Forms.Cursors.NoMoveVert ) return "NoMoveVert";
      if( cursor == System.Windows.Forms.Cursors.PanEast ) return "PanEast";
      if( cursor == System.Windows.Forms.Cursors.PanNE ) return "PanNE";
      if( cursor == System.Windows.Forms.Cursors.PanNorth ) return "PanNorth";
      if( cursor == System.Windows.Forms.Cursors.PanNW ) return "PanNW";
      if( cursor == System.Windows.Forms.Cursors.PanSE ) return "PanSE";
      if( cursor == System.Windows.Forms.Cursors.PanSouth ) return "PanSouth";
      if( cursor == System.Windows.Forms.Cursors.PanSW ) return "PanSW";
      if( cursor == System.Windows.Forms.Cursors.PanWest ) return "PanWest";
      if( cursor == System.Windows.Forms.Cursors.SizeAll ) return "SizeAll";
      if( cursor == System.Windows.Forms.Cursors.SizeNESW ) return "SizeNESW";
      if( cursor == System.Windows.Forms.Cursors.SizeNS ) return "SizeNS";
      if( cursor == System.Windows.Forms.Cursors.SizeNWSE ) return "SizeNWSE";
      if( cursor == System.Windows.Forms.Cursors.SizeWE ) return "SizeWE";
      if( cursor == System.Windows.Forms.Cursors.UpArrow ) return "UpArrow";
      if( cursor == System.Windows.Forms.Cursors.VSplit ) return "VSplit";
      if( cursor == System.Windows.Forms.Cursors.WaitCursor ) return "WaitCursor";

      return "<no name>";
    }

    private void CursorsForm_Click(object sender, EventArgs e) {
      try {
        // Change the cursor to indicate that we're waiting
        Cursor.Current = Cursors.WaitCursor;

        // Do something that takes a long time
        System.Threading.Thread.Sleep(2000);
      }
      finally {
        // Restore current cursor
        Cursor.Current = this.Cursor;
      }

      // Cursor restored after this event handler anyway...
    }
  }
}
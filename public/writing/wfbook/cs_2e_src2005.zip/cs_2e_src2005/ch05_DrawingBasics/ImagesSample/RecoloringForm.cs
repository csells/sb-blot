﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class RecoloringForm : Form {
    public RecoloringForm() {
      InitializeComponent();

      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    private void originalColorsPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.originalColorsPanel.ClientRectangle.Width - rect.Width) / 2, (this.originalColorsPanel.ClientRectangle.Height - rect.Height) / 2);
        g.DrawImage(bmp, rect);
      }
    }

    private void mappedColorsPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "INTL_NO.BMP") ) {
        // Set the image attribute's color mappings
        ColorMap[] colorMap = new ColorMap[1];
        colorMap[0] = new ColorMap();
        //colorMap[0].OldColor = Color.Lime;
        colorMap[0].OldColor = bmp.GetPixel(0, bmp.Height - 1);
        colorMap[0].NewColor = Color.White;
        ImageAttributes attr = new ImageAttributes();
        attr.SetRemapTable(colorMap);

        // Draw using the color map
        Rectangle rect = new Rectangle(0, 0, bmp.Width, bmp.Height);
        rect.Offset((this.mappedColorsPanel.ClientRectangle.Width - rect.Width) / 2, (this.mappedColorsPanel.ClientRectangle.Height - rect.Height) / 2);
        g.DrawImage(bmp, rect, 0, 0, rect.Width, rect.Height, g.PageUnit, attr);
      }
    }
  }
}
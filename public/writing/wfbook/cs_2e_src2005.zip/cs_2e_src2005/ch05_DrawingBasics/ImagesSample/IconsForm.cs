﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class IconsForm : Form {
    public IconsForm() {
      InitializeComponent();
    }

    private string GetIconName(Icon icon) {
      if( icon == SystemIcons.Application ) return "Application";
      if( icon == SystemIcons.Asterisk ) return "Asterisk";
      if( icon == SystemIcons.Error ) return "Error";
      if( icon == SystemIcons.Exclamation ) return "Exclamation";
      if( icon == SystemIcons.Hand ) return "Hand";
      if( icon == SystemIcons.Information ) return "Information";
      if( icon == SystemIcons.Question ) return "Question";
      if( icon == SystemIcons.Warning ) return "Warning";
      if( icon == SystemIcons.WinLogo ) return "WinLogo";

      return "<no name>";
    }

    private void IconsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 3;
      int height = this.ClientRectangle.Height / 3;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Far;

      Icon[] icons = new Icon[] { SystemIcons.Application,
                                  SystemIcons.Asterisk,
                                  SystemIcons.Error,
                                  SystemIcons.Exclamation,
                                  SystemIcons.Hand,
                                  SystemIcons.Information,
                                  SystemIcons.Question,
                                  SystemIcons.Warning,
                                  SystemIcons.WinLogo,
      };

      foreach( Icon icon in icons ) {
        Rectangle rect = new Rectangle(x, y, width, height);
        Rectangle iconRect = new Rectangle(x + (width - icon.Width) / 2, y + (height - icon.Height) / 2, icon.Width, icon.Height);
        g.DrawIconUnstretched(icon, iconRect);
        g.DrawString(GetIconName(icon), this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect);
        x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
        y = (x == 0 ? y + height : y);
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class PictureBoxAnimationForm : Form {
    public PictureBoxAnimationForm() {
      InitializeComponent();
    }

    private void AnimatedPictureBoxForm_Load(object sender, EventArgs e) {
      Bitmap gif = new Bitmap(typeof(AnimationForm), "AnimatedGif.GIF");
      this.animatedPictureBox.Image = gif; // gif automatically begins animating
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void scalingClippingButton_Click(object sender, EventArgs e) {
      (new ScalingClippingForm()).ShowDialog();
    }

    private void panningButton_Click(object sender, EventArgs e) {
      (new PanningForm()).ShowDialog();
    }

    private void skewingButton_Click(object sender, EventArgs e) {
      (new SkewingForm()).ShowDialog();
    }

    private void rotatingFlippingButton_Click(object sender, EventArgs e) {
      (new RotatingFlippingForm()).ShowDialog();
    }

    private void recoloringButton_Click(object sender, EventArgs e) {
      (new RecoloringForm()).ShowDialog();
    }

    private void transparencyButton_Click(object sender, EventArgs e) {
      (new TransparencyForm()).ShowDialog();
    }

    private void animationButton_Click(object sender, EventArgs e) {
      (new AnimationForm()).ShowDialog();
    }

    private void drawingToImagesButton_Click(object sender, EventArgs e) {
      (new DrawingToImagesForm()).ShowDialog();
    }

    private void iconsButton_Click(object sender, EventArgs e) {
      (new IconsForm()).ShowDialog();
    }
    
    private void cursorsButton_Click(object sender, EventArgs e) {
      (new CursorsForm()).ShowDialog();
    }

    private void pictureBoxAnimationButton_Click(object sender, EventArgs e)
    {
      (new PictureBoxAnimationForm()).ShowDialog();
    }

    private void animatedCursorsButton_Click(object sender, EventArgs e) {
      (new AnimatedCursorForm()).ShowDialog();
    }

    private void coloredCursorsButton_Click(object sender, EventArgs e) {
      (new ColoredCursorForm()).ShowDialog();
    }
  }
}
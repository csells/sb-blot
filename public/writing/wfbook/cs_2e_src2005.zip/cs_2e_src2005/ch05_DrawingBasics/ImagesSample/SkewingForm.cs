﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class SkewingForm : Form {
    public SkewingForm() {
      InitializeComponent();
    }

    Bitmap bmp = new Bitmap(typeof(SkewingForm), "Soap Bubbles.bmp");
    Size offset = new Size(0, 0); // Adjusted by buttons

    void skewingPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Rectangle rect = this.skewingPanel.ClientRectangle;
      Point[] points = new Point[3];
      points[0] = new Point(rect.Left + offset.Width, rect.Top + offset.Height);
      points[1] = new Point(rect.Right, rect.Top + offset.Height);
      points[2] = new Point(rect.Left, rect.Bottom - offset.Height);
      g.DrawImage(bmp, points);
    }

    private void upButton_Click(object sender, System.EventArgs e) {
      offset.Height += 10;
      skewingPanel.Refresh();
    }

    private void rightButton_Click(object sender, System.EventArgs e) {
      offset.Width -= 10;
      skewingPanel.Refresh();
    }

    private void downButton_Click(object sender, System.EventArgs e) {
      offset.Height -= 10;
      skewingPanel.Refresh();
    }

    private void leftButton_Click(object sender, System.EventArgs e) {
      offset.Width += 10;
      skewingPanel.Refresh();
    }
  }
}
﻿namespace ImagesSample {
  partial class PanningForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.panningPanel = new System.Windows.Forms.Panel();
      this.leftButton = new System.Windows.Forms.Button();
      this.rightButton = new System.Windows.Forms.Button();
      this.downButton = new System.Windows.Forms.Button();
      this.upButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // panningPanel
      // 
      this.panningPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.panningPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
      this.panningPanel.Location = new System.Drawing.Point(41, 37);
      this.panningPanel.Name = "panningPanel";
      this.panningPanel.Size = new System.Drawing.Size(180, 162);
      this.panningPanel.TabIndex = 0;
      this.panningPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.panningPanel_Paint);
      // 
      // leftButton
      // 
      this.leftButton.Anchor = System.Windows.Forms.AnchorStyles.Left;
      this.leftButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.leftButton.Location = new System.Drawing.Point(7, 102);
      this.leftButton.Name = "leftButton";
      this.leftButton.Size = new System.Drawing.Size(27, 23);
      this.leftButton.TabIndex = 0;
      this.leftButton.Text = "<";
      this.leftButton.Click += new System.EventHandler(this.leftButton_Click);
      // 
      // rightButton
      // 
      this.rightButton.Anchor = System.Windows.Forms.AnchorStyles.Right;
      this.rightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.rightButton.Location = new System.Drawing.Point(230, 102);
      this.rightButton.Name = "rightButton";
      this.rightButton.Size = new System.Drawing.Size(27, 23);
      this.rightButton.TabIndex = 1;
      this.rightButton.Text = ">";
      this.rightButton.Click += new System.EventHandler(this.rightButton_Click);
      // 
      // downButton
      // 
      this.downButton.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
      this.downButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.downButton.Location = new System.Drawing.Point(122, 206);
      this.downButton.Name = "downButton";
      this.downButton.Size = new System.Drawing.Size(27, 23);
      this.downButton.TabIndex = 2;
      this.downButton.Text = "v";
      this.downButton.Click += new System.EventHandler(this.downButton_Click);
      // 
      // upButton
      // 
      this.upButton.Anchor = System.Windows.Forms.AnchorStyles.Top;
      this.upButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.upButton.Location = new System.Drawing.Point(122, 7);
      this.upButton.Name = "upButton";
      this.upButton.Size = new System.Drawing.Size(27, 23);
      this.upButton.TabIndex = 3;
      this.upButton.Text = "^";
      this.upButton.Click += new System.EventHandler(this.upButton_Click);
      // 
      // PanningForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(263, 235);
      this.Controls.Add(this.leftButton);
      this.Controls.Add(this.rightButton);
      this.Controls.Add(this.downButton);
      this.Controls.Add(this.upButton);
      this.Controls.Add(this.panningPanel);
      this.Name = "PanningForm";
      this.Text = "Panning";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Panel panningPanel;
    private System.Windows.Forms.Button leftButton;
    private System.Windows.Forms.Button rightButton;
    private System.Windows.Forms.Button downButton;
    private System.Windows.Forms.Button upButton;
  }
}
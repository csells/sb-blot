﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class ScalingClippingForm : Form {
    public ScalingClippingForm() {
      InitializeComponent();
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    private void scalingPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "Soap Bubbles.bmp") ) {
        Rectangle rect = new Rectangle(10, 10, this.scalingPanel.ClientRectangle.Width - 20, this.scalingPanel.ClientRectangle.Height - 20);
        g.DrawImage(bmp, rect);
        g.DrawRectangle(Pens.Black, rect);
      }
    }

    private void clippingPanel_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Bitmap bmp = new Bitmap(this.GetType(), "Soap Bubbles.bmp") ) {
        Rectangle destRect = new Rectangle(10, 10, this.clippingPanel.ClientRectangle.Width - 20, this.clippingPanel.ClientRectangle.Height - 20);
        Rectangle srcRect = new Rectangle(0, 0, destRect.Width, destRect.Height);
        g.DrawImage(bmp, destRect, srcRect, g.PageUnit);
        g.DrawRectangle(Pens.Black, destRect);
      }
    }
  }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace ImagesSample {
  public partial class ColoredCursorForm : Form {
  
    [DllImport("user32.dll")]
    static extern IntPtr LoadCursorFromFile(string lpFileName);

    static Cursor ColoredCursor;
    
    static ColoredCursorForm() {
      // Load colored cursor once for the lifetime of the application
      IntPtr cursor = LoadCursorFromFile(@"c:\windows\cursors\3dgarro.cur");
      ColoredCursor = new Cursor(cursor);
    }
    
    public ColoredCursorForm() {
      InitializeComponent();
    }

    private void ColoredCursorForm_MouseEnter(object sender, EventArgs e) {
      // Load colored cursor
      this.Cursor = ColoredCursor;
    }

    private void ColoredCursorForm_MouseLeave(object sender, EventArgs e) {
      this.Cursor = Cursors.Default;
    }
  }
}
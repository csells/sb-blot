﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ImagesSample {
  partial class DrawingToImagesForm : Form {
    public DrawingToImagesForm() {
      InitializeComponent();
    }

    private int offset;

    private void saveButton_Click(object sender, EventArgs e) {
      Rectangle rect = new Rectangle(0, 0, 100, 100);

      // Get current graphics object for display
      using( Graphics displayGraphics = this.CreateGraphics() )

      // Create bitmap to draw into based on existing Graphics object
      using( Image image = new Bitmap(rect.Width, rect.Height, displayGraphics) )

      // Wrap Graphics object around image to draw into
      using( Graphics imageGraphics = Graphics.FromImage(image) ) {

        imageGraphics.FillRectangle(Brushes.Black, rect);
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.White, rect, format);

        // Save created image to a file
        string file = @"c:\image.png";
        image.Save(file);

        MessageBox.Show("Saved to file: " + file);
      }
    }

    private void DrawingToImagesForm_Load(object sender, EventArgs e) {
      offset = this.ClientRectangle.Height - this.panel1.Height;
    }

    private void DrawingToImagesForm_Layout(object sender, LayoutEventArgs e) {
      this.panel1.Height = this.ClientRectangle.Height - offset;
    }

    private void panel1_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      Rectangle rect = this.panel1.ClientRectangle;

      // Create bitmap to draw into based on existing Graphics object
      using( Image image = new Bitmap(rect.Width, rect.Height, g) )
      // Wrap Graphics object around image to draw into
      using( Graphics imageGraphics = Graphics.FromImage(image) ) {
        imageGraphics.FillRectangle(Brushes.White, rect);
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        imageGraphics.DrawString("Drawing to an image", panel1.Font, Brushes.Black, rect, format);

        // Draw created image to screen
        g.DrawImage(image, rect);
      }
    }
  }
}
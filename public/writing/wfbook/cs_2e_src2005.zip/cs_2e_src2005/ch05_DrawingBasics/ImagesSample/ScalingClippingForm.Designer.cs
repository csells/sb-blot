﻿namespace ImagesSample {
  partial class ScalingClippingForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.splitContainer1 = new System.Windows.Forms.SplitContainer();
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.scalingPanel = new System.Windows.Forms.Panel();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.clippingPanel = new System.Windows.Forms.Panel();
      this.splitContainer1.Panel1.SuspendLayout();
      this.splitContainer1.Panel2.SuspendLayout();
      this.splitContainer1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      this.SuspendLayout();
      // 
      // splitContainer1
      // 
      this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.splitContainer1.Location = new System.Drawing.Point(0, 0);
      this.splitContainer1.Name = "splitContainer1";
      // 
      // splitContainer1.Panel1
      // 
      this.splitContainer1.Panel1.Controls.Add(this.groupBox1);
      // 
      // splitContainer1.Panel2
      // 
      this.splitContainer1.Panel2.Controls.Add(this.groupBox2);
      this.splitContainer1.Size = new System.Drawing.Size(442, 219);
      this.splitContainer1.SplitterDistance = 218;
      this.splitContainer1.TabIndex = 0;
      this.splitContainer1.Text = "splitContainer1";
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.scalingPanel);
      this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox1.Location = new System.Drawing.Point(0, 0);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(218, 219);
      this.groupBox1.TabIndex = 0;
      this.groupBox1.TabStop = false;
      this.groupBox1.Text = "Scaling";
      // 
      // scalingPanel
      // 
      this.scalingPanel.BackColor = System.Drawing.Color.White;
      this.scalingPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.scalingPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.scalingPanel.Location = new System.Drawing.Point(3, 16);
      this.scalingPanel.Name = "scalingPanel";
      this.scalingPanel.Size = new System.Drawing.Size(212, 200);
      this.scalingPanel.TabIndex = 0;
      this.scalingPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.scalingPanel_Paint);
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.clippingPanel);
      this.groupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
      this.groupBox2.Location = new System.Drawing.Point(0, 0);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(220, 219);
      this.groupBox2.TabIndex = 0;
      this.groupBox2.TabStop = false;
      this.groupBox2.Text = "Clipping";
      // 
      // clippingPanel
      // 
      this.clippingPanel.BackColor = System.Drawing.Color.White;
      this.clippingPanel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.clippingPanel.Dock = System.Windows.Forms.DockStyle.Fill;
      this.clippingPanel.Location = new System.Drawing.Point(3, 16);
      this.clippingPanel.Name = "clippingPanel";
      this.clippingPanel.Padding = new System.Windows.Forms.Padding(5);
      this.clippingPanel.Size = new System.Drawing.Size(214, 200);
      this.clippingPanel.TabIndex = 1;
      this.clippingPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.clippingPanel_Paint);
      // 
      // ScalingClippingForm
      // 
      this.ClientSize = new System.Drawing.Size(442, 219);
      this.Controls.Add(this.splitContainer1);
      this.Name = "ScalingClippingForm";
      this.Text = "Scaling vs Clipping";
      this.splitContainer1.Panel1.ResumeLayout(false);
      this.splitContainer1.Panel2.ResumeLayout(false);
      this.splitContainer1.ResumeLayout(false);
      this.groupBox1.ResumeLayout(false);
      this.groupBox2.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer splitContainer1;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Panel scalingPanel;
    private System.Windows.Forms.Panel clippingPanel;
  }
}
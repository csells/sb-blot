﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace BitmapToIconSample {
  partial class BitmapToIconSampleForm : Form {
    public BitmapToIconSampleForm() {
      InitializeComponent();
    }

    private void ConvertBitmapToIcon_Click(object sender, EventArgs e) {
      // Get source bitmap
      Bitmap bitmap = Properties.Resources.Soap_Bubbles;
      
      // Get source bitmap's icon handle
      IntPtr hIcon = bitmap.GetHicon();
      
      // Convert bitmap to icon
      Icon icon = Icon.FromHandle(hIcon);
      
      this.Icon = icon;
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace CopyFromScreenSample {
  partial class CopyFromScreenSampleForm : Form {
    public CopyFromScreenSampleForm() {
      InitializeComponent();
    }

    private void captureButton_Click(object sender, EventArgs e) {

      // Create a screen-sized bitmap to copy to
      Rectangle screenRect = Screen.PrimaryScreen.WorkingArea;
      Bitmap targetBitmap = new Bitmap(screenRect.Width, screenRect.Height);
      
      // Create a graphics object, capture the screen and paint it
      // onto the bitmap
      using( Graphics targetGraphics = Graphics.FromImage(targetBitmap) ) {
        targetGraphics.CopyFromScreen(0, 0, 0, 0, new Size(screenRect.Width, screenRect.Height));
      }
      
      // Render it to target picture box, scaled to fit
      this.screenPictureBox.BackgroundImage = targetBitmap;
      this.screenPictureBox.BackgroundImageLayout = ImageLayout.Stretch;
    }
  }
}
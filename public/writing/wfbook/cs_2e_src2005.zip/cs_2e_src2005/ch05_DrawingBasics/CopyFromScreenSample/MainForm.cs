﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace CopyFromScreenSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void captureButton_Click(object sender, EventArgs e) {
Cursor
      //// Dump screen to bitmap
      //Rectangle screenRect = Screen.PrimaryScreen.WorkingArea;
      //Bitmap dumpBitmap = new Bitmap(screenRect.Width, screenRect.Height);
      //using( Graphics targetGraphics = Graphics.FromImage(dumpBitmap) ) {
      //  targetGraphics.CopyFromScreen(0, 0, 0, 0, new Size(dumpBitmap.Width, dumpBitmap.Height));
      //}

      // Dump form UI to a bitmap
      Rectangle rect = new Rectangle(0, 0, this.Size.Width, this.Size.Height);
      Bitmap dumpBitmap = new Bitmap(this.Size.Width, this.Size.Height);
      this.DrawToBitmap(dumpBitmap, rect);

      // Render dump bitmap to target picture box, stretched to fit
      this.screenPictureBox.BackgroundImage = dumpBitmap;
      this.screenPictureBox.BackgroundImageLayout = ImageLayout.Stretch;
    }
  }
}
﻿namespace Drawing {
  partial class DrawingSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.drawEllipseButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
// 
// drawEllipseButton
// 
      this.drawEllipseButton.Location = new System.Drawing.Point(38, 28);
      this.drawEllipseButton.Name = "drawEllipseButton";
      this.drawEllipseButton.TabIndex = 0;
      this.drawEllipseButton.Text = "Draw Ellipse";
      this.drawEllipseButton.Click += new System.EventHandler(this.drawEllipseButton_Click);
// 
// DrawingSampleForm
// 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(152, 79);
      this.Controls.Add(this.drawEllipseButton);
      this.Name = "DrawingSampleForm";
      this.Text = "Drawing";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.DrawingSampleForm_Paint);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button drawEllipseButton;
  }
}


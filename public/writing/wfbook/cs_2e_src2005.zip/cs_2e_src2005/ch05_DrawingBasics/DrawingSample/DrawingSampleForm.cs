﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace Drawing {
  partial class DrawingSampleForm : Form {
    public DrawingSampleForm() {
      // Required for Windows Form Designer support
      InitializeComponent();
      
      // Trigger a Paint event when the form is resized
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    bool drawEllipse = false;

    private void drawEllipseButton_Click(object sender, EventArgs e) {
      // Toggle whether to draw the ellipse or not
      drawEllipse = !drawEllipse;

//      // Can do one or the other
//      this.Invalidate(); // Ask Windows for a Paint event
//                             // for the form and its children
//      this.Update(); // Force the Paint event to happen now

      // Or can do both at once
      this.Refresh(); // Invalidate(true) + Update

//      Graphics g = this.CreateGraphics();
//      try {
//        if( drawEllipse ) {
//          // Draw the ellipse
//          g.FillEllipse(Brushes.DarkBlue, this.ClientRectangle);
//        }
//        else {
//          // Erase the previously drawn ellipse
//          g.FillEllipse(SystemBrushes.Control, this.ClientRectangle);
//        }
//      }
//      finally {
//        g.Dispose();
//      }

//      using( Graphics g = this.CreateGraphics() ) {
//        if( drawEllipse ) {
//          // Draw the ellipse
//          g.FillEllipse(Brushes.DarkBlue, this.ClientRectangle);
//        }
//        else {
//          // Erase the previously drawn ellipse
//          g.FillEllipse(SystemBrushes.Control, this.ClientRectangle);
//        }
//      }
    }

    private void DrawingSampleForm_Paint(object sender, PaintEventArgs e) {

      Color blue25PercentOpache = Color.FromArgb(255 * 1 / 4, 0, 0, 255);
      Color blue75PercentOpache = Color.FromArgb(-1090518785);
      Color white = Color.FromArgb(255, 255, 255);
      Color black = Color.FromArgb(0, 0, 0);
      Color blue1 = Color.BlueViolet;
      Color blue2 = Color.FromKnownColor(KnownColor.ActiveBorder);
      Color blue3 = Color.FromName("ActiveBorder");
      Color htmlBlue = ColorTranslator.FromHtml("#0000ff");
      //      string htmlBlueToo = ColorTranslator.ToHtml(htmlBlue);
      //      MessageBox.Show(htmlBlueToo);

      if( !drawEllipse ) return;
      Graphics g = e.Graphics;
      g.FillEllipse(Brushes.DarkBlue, this.ClientRectangle);
    }
  }
}
﻿namespace PathsSolution {
  partial class PathsSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
// 
// PathsSampleForm
// 
      this.AutoScaleBaseSize = new System.Drawing.Size(21, 49);
      this.BackColor = System.Drawing.Color.White;
      this.ClientSize = new System.Drawing.Size(385, 247);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 32F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
      this.Name = "PathsSampleForm";
      this.Text = "Path";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.PathsSampleForm_Paint);

    }

    #endregion
  }
}


﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace PathsSolution {
  partial class PathsSampleForm : Form {
    public PathsSampleForm() {
      InitializeComponent();
      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    GraphicsPath GetRoundedRectPath(Rectangle rect, int radius) {
      int diameter = 2 * radius;
      Rectangle arcRect = new Rectangle(rect.Location, new Size(diameter, diameter));
      GraphicsPath path = new GraphicsPath();

      // top left
      path.AddArc(arcRect, 180, 90);

      // top right
      arcRect.X = rect.Right - diameter;
      path.AddArc(arcRect, 270, 90);

      path.StartFigure();

      // bottom right
      arcRect.Y = rect.Bottom - diameter;
      path.AddArc(arcRect, 0, 90);

      // bottom left
      arcRect.X = rect.Left;
      path.AddArc(arcRect, 90, 90);

      path.CloseFigure();

      return path;
    }

    GraphicsPath GetClosedBezierPath(Rectangle rect, Point[] points) {
      GraphicsPath path = new GraphicsPath();
      path.AddBeziers(points);
      path.CloseFigure();
      return path;
    }

    GraphicsPath GetDonutPath(Rectangle rect, int holeRadius) {

      GraphicsPath path = new GraphicsPath();
      //      path.FillMode = FillMode.Winding;
      path.AddEllipse(rect);
      Point centerPoint = new Point(rect.Left + rect.Width / 2, rect.Top + rect.Height / 2);
      Rectangle holeRect = new Rectangle(centerPoint.X - holeRadius, centerPoint.Y - holeRadius, holeRadius * 2, holeRadius * 2);
      //  path.StartFigure();
      path.AddEllipse(holeRect);

      // Combining text as a figure
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      path.AddString("ooohhhh, donuts...", this.Font.FontFamily, (int)this.Font.Style, this.Font.Height, rect, format);

      return path;
    }

    // Need to pass in DPI = 100 for GraphicsUnit == Display
    GraphicsPath GetStringPath(
        string s,
        float dpi,
        RectangleF rect,
        Font font,
        StringFormat format) {
      GraphicsPath path = new GraphicsPath();
      // Convert font size into appropriate coordinates
      float emSize = dpi * font.SizeInPoints / 72;
      path.AddString(s, font.FontFamily, (int)font.Style, emSize, rect, format);
      return path;
    }

    private void PathsSampleForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height;
      Rectangle rect = new Rectangle(10, 10, width - 20, height - 20);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      //using( GraphicsPath path = GetRoundedRectPath(rect, width/10) ) {
      //using( GraphicsPath path = GetClosedBezierPath(rect, new Point[] { new Point(25, height - 25), new Point(width - 25, height - 25), new Point(25, 25), new Point(width - 25, 25), }) ) {
      using( GraphicsPath path = GetDonutPath(rect, width / 5) ) {
        //using( GraphicsPath path = GetStringPath("Ain't paths cool?", rect, this.Font, format) ) {
        g.FillPath(Brushes.Yellow, path);
        g.DrawPath(Pens.Black, path);
      }
    }
  }
}
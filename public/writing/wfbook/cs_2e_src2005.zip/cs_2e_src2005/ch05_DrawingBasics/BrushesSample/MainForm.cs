﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void brushesButton_Click(object sender, EventArgs e) {
      (new BrushesForm()).ShowDialog();
    }

    private void textureBrushesButton_Click(object sender, EventArgs e) {
      (new TextureBrushesForm()).ShowDialog();
    }

    private void hatchBrushesButton_Click(object sender, EventArgs e) {
      (new HatchBrushesForm()).ShowDialog();
    }

    private void linearGradientBrushesButton_Click(object sender, EventArgs e) {
      (new LinearGradientBrushesForm()).ShowDialog();
    }

    private void pathGradientBrushesButton_Click(object sender, EventArgs e) {
      (new PathGradientBrushesForm()).ShowDialog();
    }
  }
}

﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class TextureBrushesForm : Form {
    public TextureBrushesForm() {
      InitializeComponent();
    }

    private void TextureBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height / 6;
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;

      using( Bitmap bitmap = new Bitmap(this.GetType(), "BEANY.BMP") ) {

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.Clamp) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.Tile) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipX) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipY) ) {
          g.FillRectangle(brush, x, y, width, height);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
          y += height;
        }

        using( TextureBrush brush =
                 new TextureBrush(bitmap, WrapMode.TileFlipXY) ) {
          g.FillRectangle(brush, x, y, width, height * 2);
          g.DrawRectangle(blackPen, x, y, width, height * 2);
          g.DrawString(brush.WrapMode.ToString(), this.Font, blackBrush, x, y);
        }
      }
    }
  }
}
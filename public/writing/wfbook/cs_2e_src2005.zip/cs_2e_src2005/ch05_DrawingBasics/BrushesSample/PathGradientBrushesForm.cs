﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class PathGradientBrushesForm : Form {
    public PathGradientBrushesForm() {
      InitializeComponent();
    }

    private void PathGradientBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int width = this.ClientRectangle.Width / 2;
      int height = this.ClientRectangle.Height / 2;

      Point[] triPoints = new Point[] { new Point(width/2, 0),
                                        new Point(0, height),
                                        new Point(width, height), };
      using( PathGradientBrush brush = new PathGradientBrush(triPoints) ) {
        int x = 0;
        int y = 0;
        g.FillRectangle(brush, x, y, width, height);
      }

      Point[] quadPoints = new Point[] { new Point(0, 0), 
                                         new Point(width, 0), 
                                         new Point(width, height), 
                                         new Point(0, height) };
      using( PathGradientBrush brush = new PathGradientBrush(quadPoints) ) {
        // defaults to Clamp, which won't draw anywhere except upper left of client
        brush.WrapMode = WrapMode.Tile;
        int x = width;
        int y = 0;
        g.FillRectangle(brush, x, y, width, height);
      }

      Point[] diamondPoints = new Point[] { new Point(width / 2, 0), new Point(width, height / 2), new Point(width / 2, height), new Point(0, height / 2), };
      using( PathGradientBrush brush =
               new PathGradientBrush(diamondPoints) ) {
        brush.WrapMode = WrapMode.Tile;
        brush.CenterPoint = new Point(0, height / 2);
        int x = 0;
        int y = height;
        g.FillRectangle(brush, x, y, width, height);
      }

      //      Point[] diamondPoints = new Point[] { new Point(width/2, 0), new Point(width, height/2), new Point(width/2, height), new Point(0, height/2), };
      //      using( GraphicsPath diamondPath = new GraphicsPath() ) {
      //        diamondPath.AddPolygon(diamondPoints);
      //        using( PathGradientBrush brush = new PathGradientBrush(diamondPath) ) {
      //          brush.WrapMode = WrapMode.Tile;
      //          int x = 0;
      //          int y = height;
      //          g.FillRectangle(brush, x, y, width, height);
      //        }
      //      }

      using( GraphicsPath circle = new GraphicsPath() ) {
        circle.AddEllipse(0, 0, width, height);
        using( PathGradientBrush brush = new PathGradientBrush(circle) ) {
          brush.WrapMode = WrapMode.Tile;
          brush.SurroundColors = new Color[] { Color.White }; // default
          brush.CenterColor = Color.Black;
          int x = width;
          int y = height;
          g.FillRectangle(brush, x, y, width, height);
        }
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class HatchBrushesForm : Form {
    public HatchBrushesForm() {
      InitializeComponent();
      
    }

    private void HatchBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      string[] hatchNames = Enum.GetNames(typeof(HatchStyle));
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 4;
      int height = this.ClientRectangle.Height / (hatchNames.Length / 4);
      Brush blackBrush = System.Drawing.Brushes.Black;
      Pen blackPen = Pens.Black;

      Array.Sort(hatchNames);

      foreach( string hatchName in hatchNames ) {
        HatchStyle style = (HatchStyle)Enum.Parse(typeof(HatchStyle), hatchName);
        using( HatchBrush brush = new HatchBrush(style, Color.Black, Color.White) ) {
          g.FillRectangle(brush, x, y + height / 2, width, height / 2);
          g.DrawRectangle(blackPen, x, y, width, height);
          g.DrawString(hatchName, this.Font, blackBrush, x, y);
          x += width;
          if( x > this.ClientRectangle.Width - width ) {
            y += height;
            x = 0;
          }
        }
      }
    }
  }
}
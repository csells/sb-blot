﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class LinearGradientBrushesForm : Form {
    public LinearGradientBrushesForm() {
      InitializeComponent();
    }

    private void LinearGradientBrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height / 4;
      Brush blackBrush = System.Drawing.Brushes.Black;

      using(
        LinearGradientBrush brush =
          new LinearGradientBrush(
          this.ClientRectangle,
          Color.White,
          Color.Black,
          LinearGradientMode.Horizontal) ) {

        // Normal: focus set at the end
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Normal", this.Font, blackBrush, x, y);
        y += height;

        // Triangle: focus set in the middle
        brush.SetBlendTriangularShape(0.5f);
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Triangle", this.Font, blackBrush, x, y);
        y += height;

        // Bell: focus set in the middle
        brush.SetSigmaBellShape(0.5f);
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Bell", this.Font, blackBrush, x, y);
        y += height;

        // Custom colors
        ColorBlend blend = new ColorBlend();
        blend.Colors = new Color[] { Color.White, Color.Red, Color.Black, };
        blend.Positions = new float[] { 0.0f, 0.5f, 1.0f };
        brush.InterpolationColors = blend;
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString("Custom Colors", this.Font, blackBrush, x, y);
      }
    }
  }
}
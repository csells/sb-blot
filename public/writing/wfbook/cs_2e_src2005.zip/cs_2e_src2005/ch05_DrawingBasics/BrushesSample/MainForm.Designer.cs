﻿namespace BrushesSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.brushesButton = new System.Windows.Forms.Button();
      this.textureBrushesButton = new System.Windows.Forms.Button();
      this.hatchBrushesButton = new System.Windows.Forms.Button();
      this.linearGradientBrushesButton = new System.Windows.Forms.Button();
      this.pathGradientBrushesButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // brushesButton
      // 
      this.brushesButton.Location = new System.Drawing.Point(13, 13);
      this.brushesButton.Name = "brushesButton";
      this.brushesButton.Size = new System.Drawing.Size(175, 23);
      this.brushesButton.TabIndex = 0;
      this.brushesButton.Text = "Brushes";
      this.brushesButton.Click += new System.EventHandler(this.brushesButton_Click);
      // 
      // textureBrushesButton
      // 
      this.textureBrushesButton.Location = new System.Drawing.Point(13, 43);
      this.textureBrushesButton.Name = "textureBrushesButton";
      this.textureBrushesButton.Size = new System.Drawing.Size(175, 23);
      this.textureBrushesButton.TabIndex = 1;
      this.textureBrushesButton.Text = "Texture Brushes";
      this.textureBrushesButton.Click += new System.EventHandler(this.textureBrushesButton_Click);
      // 
      // hatchBrushesButton
      // 
      this.hatchBrushesButton.Location = new System.Drawing.Point(13, 73);
      this.hatchBrushesButton.Name = "hatchBrushesButton";
      this.hatchBrushesButton.Size = new System.Drawing.Size(175, 23);
      this.hatchBrushesButton.TabIndex = 2;
      this.hatchBrushesButton.Text = "Hatch Brushes";
      this.hatchBrushesButton.Click += new System.EventHandler(this.hatchBrushesButton_Click);
      // 
      // linearGradientBrushesButton
      // 
      this.linearGradientBrushesButton.Location = new System.Drawing.Point(13, 103);
      this.linearGradientBrushesButton.Name = "linearGradientBrushesButton";
      this.linearGradientBrushesButton.Size = new System.Drawing.Size(175, 23);
      this.linearGradientBrushesButton.TabIndex = 3;
      this.linearGradientBrushesButton.Text = "Linear Gradient Brushes";
      this.linearGradientBrushesButton.Click += new System.EventHandler(this.linearGradientBrushesButton_Click);
      // 
      // pathGradientBrushesButton
      // 
      this.pathGradientBrushesButton.Location = new System.Drawing.Point(13, 133);
      this.pathGradientBrushesButton.Name = "pathGradientBrushesButton";
      this.pathGradientBrushesButton.Size = new System.Drawing.Size(175, 23);
      this.pathGradientBrushesButton.TabIndex = 4;
      this.pathGradientBrushesButton.Text = "Path Gradient Brushes";
      this.pathGradientBrushesButton.Click += new System.EventHandler(this.pathGradientBrushesButton_Click);
      // 
      // BrushesSampleForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(200, 170);
      this.Controls.Add(this.pathGradientBrushesButton);
      this.Controls.Add(this.linearGradientBrushesButton);
      this.Controls.Add(this.hatchBrushesButton);
      this.Controls.Add(this.textureBrushesButton);
      this.Controls.Add(this.brushesButton);
      this.Name = "BrushesSampleForm";
      this.Text = "Brushes Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button brushesButton;
    private System.Windows.Forms.Button textureBrushesButton;
    private System.Windows.Forms.Button hatchBrushesButton;
    private System.Windows.Forms.Button linearGradientBrushesButton;
    private System.Windows.Forms.Button pathGradientBrushesButton;
  }
}


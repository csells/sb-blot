﻿namespace BrushesSample {
  partial class LinearGradientBrushesForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.SuspendLayout();
      // 
      // LinearGradientBrushesForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.MinimumSize = new System.Drawing.Size(100, 100);
      this.Name = "LinearGradientBrushesForm";
      this.Text = "Linear Gradient Brushes";
      this.Paint += new System.Windows.Forms.PaintEventHandler(this.LinearGradientBrushesForm_Paint);
      this.ResumeLayout(false);

    }

    #endregion
  }
}
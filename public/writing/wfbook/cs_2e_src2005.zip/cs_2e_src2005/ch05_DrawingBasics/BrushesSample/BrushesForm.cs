﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace BrushesSample {
  partial class BrushesForm : Form {
    public BrushesForm() {
      InitializeComponent();
    }

    private void BrushesForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width;
      int height = this.ClientRectangle.Height / 5;
      Brush whiteBrush = System.Drawing.Brushes.White;
      Brush blackBrush = System.Drawing.Brushes.Black;

      // Draw SolidBrush
      using( Brush brush = new SolidBrush(Color.DarkBlue) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, whiteBrush, x, y);
        y += height;
      }

      // Draw TextureBrush
      string file = @"c:\windows\Santa Fe Stucco.bmp";
      using( Brush brush = new TextureBrush(new Bitmap(file)) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, whiteBrush, x, y);
        y += height;
      }

      // Draw HatchBrush
      using( Brush brush = new HatchBrush(HatchStyle.Divot, Color.DarkBlue, Color.White) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }

      // Draw LinearGradientBrush
      using( Brush brush = new LinearGradientBrush(new Rectangle(x, y, width, height), Color.DarkBlue, Color.White, 45.0f) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }

      // Draw PathGradientBrush
      Point[] points = new Point[] { new Point(x, y),
                                     new Point(x + width, y),
                                     new Point(x + width, y + height),
                                     new Point(x, y + height) };
      using( Brush brush = new PathGradientBrush(points) ) {
        g.FillRectangle(brush, x, y, width, height);
        g.DrawString(brush.ToString(), this.Font, blackBrush, x, y);
        y += height;
      }
    }
  }
}
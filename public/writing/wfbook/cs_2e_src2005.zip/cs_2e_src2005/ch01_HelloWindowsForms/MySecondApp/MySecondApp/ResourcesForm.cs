using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Resources;
using System.Reflection;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class ResourcesForm : Form {
    public ResourcesForm() {
      InitializeComponent();
      
      // Load 
      //this.BackgroundImage = new Bitmap(@"C:\WINDOWS\Web\Wallpaper\Azul.jpg");

      //// Load image resource from project resource file
      //Assembly assem = Assembly.GetExecutingAssembly();
      //ResourceManager resman =
      //  new ResourceManager("MySecondApp.Properties.Resources", assem);
      //this.BackgroundImage = (Image)resman.GetObject("Azul");

      // Load strongly-typed image resource
      this.BackgroundImage = Properties.Resources.Azul;

    }
  }
}
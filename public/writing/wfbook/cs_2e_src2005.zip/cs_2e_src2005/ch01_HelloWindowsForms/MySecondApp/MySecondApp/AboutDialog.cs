using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class AboutDialog : Form {
    public AboutDialog() {
      InitializeComponent();
    }

    void AboutDialog_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      g.SmoothingMode = SmoothingMode.AntiAlias;

      Rectangle rect = this.ClientRectangle;
      int cx = rect.Width;
      int cy = rect.Height;
      float scale = (float)cy / (float)cx;

      LinearGradientBrush brush =
        new LinearGradientBrush(this.ClientRectangle,
                                Color.Empty,
                                Color.Empty,
                                45);
      try {

        ColorBlend blend = new ColorBlend();
        blend.Colors =
          new Color[] { Color.Red, Color.Green, Color.Blue };
        blend.Positions = new float[] { 0, .5f, 1 };
        brush.InterpolationColors = blend;
        Pen pen = new Pen(brush);
        try {
          for( int x = 0; x < cx; x += 7 ) {
            g.DrawLine(pen, 0, x * scale, cx - x, 0);
            g.DrawLine(pen, 0, (cx - x) * scale, cx - x, cx * scale);
            g.DrawLine(pen, cx - x, 0 * scale, cx, (cx - x) * scale);
            g.DrawLine(pen, cx - x, cx * scale, cx, x * scale);
          }
        }
        finally {
          pen.Dispose();
        }

        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        string s = "Ain't graphics cool?";
        g.DrawString(s, this.Font, brush, rect, format);
      }
      finally {
        brush.Dispose();
      }
    }

    
    
  }
}
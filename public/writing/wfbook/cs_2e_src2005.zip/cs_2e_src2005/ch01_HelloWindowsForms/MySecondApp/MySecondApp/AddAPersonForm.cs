using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class AddAPersonForm : Form {
    public AddAPersonForm() {
      InitializeComponent();

      //// Read an application setting
      //string applicationSetting = Properties.Settings.Default.MyApplicationSetting;

      //// Write to an application setting
      //// NOTE: This won't compile
      //// Properties.Settings.Default.MyApplicationSetting = "newApplicationSetting";

      //// Write a user setting
      //Properties.Settings.Default.MyUserSetting = "newUserSetting";

      //// Save all user settings
      //Properties.Settings.Default.Save();

      //// Revert back to last saved user settings
      //Properties.Settings.Value.Reload();

      //// Revert back to default installed user settings
      //Properties.Settings.Value.Reset();
    }
  }
}

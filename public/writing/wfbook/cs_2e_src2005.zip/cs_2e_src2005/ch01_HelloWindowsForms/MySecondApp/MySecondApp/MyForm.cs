using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class MyForm : Form {
    public MyForm() {
      InitializeComponent();
    }
  }
}
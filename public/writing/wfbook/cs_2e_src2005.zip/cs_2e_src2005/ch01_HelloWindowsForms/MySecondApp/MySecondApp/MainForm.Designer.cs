namespace MySecondApp {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.menuStrip1 = new System.Windows.Forms.MenuStrip();
      this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.saveSettingsButton = new System.Windows.Forms.Button();
      this.resetSettingsButton = new System.Windows.Forms.Button();
      this.reloadSettingsButton = new System.Windows.Forms.Button();
      this.menuStrip1.SuspendLayout();
      this.SuspendLayout();
      // 
      // menuStrip1
      // 
      this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolsToolStripMenuItem});
      this.menuStrip1.Location = new System.Drawing.Point(0, 0);
      this.menuStrip1.Name = "menuStrip1";
      this.menuStrip1.Size = new System.Drawing.Size(292, 24);
      this.menuStrip1.TabIndex = 0;
      this.menuStrip1.Text = "menuStrip1";
      // 
      // fileToolStripMenuItem
      // 
      this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
      this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
      this.fileToolStripMenuItem.Text = "&File";
      // 
      // exitToolStripMenuItem
      // 
      this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
      this.exitToolStripMenuItem.Text = "E&xit";
      // 
      // toolsToolStripMenuItem
      // 
      this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem});
      this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
      this.toolsToolStripMenuItem.Text = "&Tools";
      // 
      // optionsToolStripMenuItem
      // 
      this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
      this.optionsToolStripMenuItem.Text = "&Options...";
      this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
      // 
      // saveSettingsButton
      // 
      this.saveSettingsButton.Location = new System.Drawing.Point(97, 94);
      this.saveSettingsButton.Name = "saveSettingsButton";
      this.saveSettingsButton.Size = new System.Drawing.Size(100, 23);
      this.saveSettingsButton.TabIndex = 1;
      this.saveSettingsButton.Text = "Save Settings";
      this.saveSettingsButton.Click += new System.EventHandler(this.saveSettingsButton_Click);
      // 
      // resetSettingsButton
      // 
      this.resetSettingsButton.Location = new System.Drawing.Point(97, 152);
      this.resetSettingsButton.Name = "resetSettingsButton";
      this.resetSettingsButton.Size = new System.Drawing.Size(100, 23);
      this.resetSettingsButton.TabIndex = 2;
      this.resetSettingsButton.Text = "Reset Settings";
      this.resetSettingsButton.Click += new System.EventHandler(this.resetSettingsButton_Click);
      // 
      // reloadSettingsButton
      // 
      this.reloadSettingsButton.Location = new System.Drawing.Point(97, 123);
      this.reloadSettingsButton.Name = "reloadSettingsButton";
      this.reloadSettingsButton.Size = new System.Drawing.Size(100, 23);
      this.reloadSettingsButton.TabIndex = 3;
      this.reloadSettingsButton.Text = "Reload Settings";
      this.reloadSettingsButton.Click += new System.EventHandler(this.reloadSettingsButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Controls.Add(this.reloadSettingsButton);
      this.Controls.Add(this.resetSettingsButton);
      this.Controls.Add(this.saveSettingsButton);
      this.Controls.Add(this.menuStrip1);
      this.MainMenuStrip = this.menuStrip1;
      this.Name = "MainForm";
      this.Text = "MainForm";
      this.menuStrip1.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.MenuStrip menuStrip1;
    private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
    private System.Windows.Forms.Button saveSettingsButton;
    private System.Windows.Forms.Button resetSettingsButton;
    private System.Windows.Forms.Button reloadSettingsButton;
  }
}
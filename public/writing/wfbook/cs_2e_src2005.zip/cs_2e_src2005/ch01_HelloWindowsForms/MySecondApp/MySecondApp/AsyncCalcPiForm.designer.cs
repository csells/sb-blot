﻿namespace MySecondApp {
  partial class AsyncCalcPiForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.decimalPlacesNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.calcButton = new System.Windows.Forms.Button();
      this.resultsTextBox = new System.Windows.Forms.TextBox();
      this.panel1 = new System.Windows.Forms.Panel();
      this.progressStatusStrip = new System.Windows.Forms.StatusStrip();
      this.calcToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.calcToolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
      this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
      ((System.ComponentModel.ISupportInitialize)(this.decimalPlacesNumericUpDown)).BeginInit();
      this.panel1.SuspendLayout();
      this.progressStatusStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 12);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(56, 13);
      this.label1.TabIndex = 0;
      this.label1.Text = "Digits of Pi:";
      // 
      // decimalPlacesNumericUpDown
      // 
      this.decimalPlacesNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.decimalPlacesNumericUpDown.Location = new System.Drawing.Point(80, 9);
      this.decimalPlacesNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
      this.decimalPlacesNumericUpDown.Name = "decimalPlacesNumericUpDown";
      this.decimalPlacesNumericUpDown.Size = new System.Drawing.Size(67, 20);
      this.decimalPlacesNumericUpDown.TabIndex = 1;
      // 
      // calcButton
      // 
      this.calcButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.calcButton.Location = new System.Drawing.Point(153, 7);
      this.calcButton.Name = "calcButton";
      this.calcButton.Size = new System.Drawing.Size(75, 23);
      this.calcButton.TabIndex = 2;
      this.calcButton.Text = "Calculate";
      this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
      // 
      // resultsTextBox
      // 
      this.resultsTextBox.AutoSize = false;
      this.resultsTextBox.BackColor = System.Drawing.Color.White;
      this.resultsTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.resultsTextBox.Location = new System.Drawing.Point(0, 38);
      this.resultsTextBox.Multiline = true;
      this.resultsTextBox.Name = "resultsTextBox";
      this.resultsTextBox.ReadOnly = true;
      this.resultsTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
      this.resultsTextBox.Size = new System.Drawing.Size(241, 85);
      this.resultsTextBox.TabIndex = 1;
      // 
      // panel1
      // 
      this.panel1.Controls.Add(this.decimalPlacesNumericUpDown);
      this.panel1.Controls.Add(this.label1);
      this.panel1.Controls.Add(this.calcButton);
      this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
      this.panel1.Location = new System.Drawing.Point(0, 0);
      this.panel1.Name = "panel1";
      this.panel1.Size = new System.Drawing.Size(241, 38);
      this.panel1.TabIndex = 0;
      // 
      // progressStatusStrip
      // 
      this.progressStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calcToolStripStatusLabel,
            this.calcToolStripProgressBar});
      this.progressStatusStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Table;
      this.progressStatusStrip.Location = new System.Drawing.Point(0, 123);
      this.progressStatusStrip.Name = "progressStatusStrip";
      this.progressStatusStrip.Size = new System.Drawing.Size(241, 23);
      this.progressStatusStrip.TabIndex = 2;
      // 
      // calcToolStripStatusLabel
      // 
      this.calcToolStripStatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
      this.calcToolStripStatusLabel.Name = "calcToolStripStatusLabel";
      this.calcToolStripStatusLabel.Text = "Ready";
      // 
      // calcToolStripProgressBar
      // 
      this.calcToolStripProgressBar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.ImageAndText;
      this.calcToolStripProgressBar.Name = "calcToolStripProgressBar";
      this.calcToolStripProgressBar.Size = new System.Drawing.Size(100, 16);
      this.calcToolStripProgressBar.Step = 1;
      this.calcToolStripProgressBar.Visible = false;
      // 
      // backgroundWorker
      // 
      this.backgroundWorker.WorkerReportsProgress = true;
      this.backgroundWorker.WorkerSupportsCancellation = true;
      this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
      this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
      this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
      // 
      // AsyncCalcPiForm
      // 
      this.ClientSize = new System.Drawing.Size(241, 146);
      this.Controls.Add(this.resultsTextBox);
      this.Controls.Add(this.progressStatusStrip);
      this.Controls.Add(this.panel1);
      this.MinimumSize = new System.Drawing.Size(249, 180);
      this.Name = "AsyncCalcPiForm";
      this.Text = "Digits of Pi";
      ((System.ComponentModel.ISupportInitialize)(this.decimalPlacesNumericUpDown)).EndInit();
      this.panel1.ResumeLayout(false);
      this.panel1.PerformLayout();
      this.progressStatusStrip.ResumeLayout(false);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.NumericUpDown decimalPlacesNumericUpDown;
    private System.Windows.Forms.Button calcButton;
    private System.Windows.Forms.TextBox resultsTextBox;
    private System.Windows.Forms.Panel panel1;
    private System.Windows.Forms.StatusStrip progressStatusStrip;
    private System.Windows.Forms.ToolStripStatusLabel calcToolStripStatusLabel;
    private System.Windows.Forms.ToolStripProgressBar calcToolStripProgressBar;
    private System.ComponentModel.BackgroundWorker backgroundWorker;
  }
}


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
public partial class EmployeesForm : Form {
  public EmployeesForm() {
    InitializeComponent();
  }

  private void bindingNavigatorSaveItem_Click(object sender, EventArgs e) {
    if( this.Validate() ) {
      this.employeesBindingSource.EndEdit();
      this.employeesTableAdapter.Update(this.northwindDataSet.Employees);
    }
    else {
      System.Windows.Forms.MessageBox.Show(this, "Validation errors occurred.", "Save", System.Windows.Forms.MessageBoxButtons.OK, System.Windows.Forms.MessageBoxIcon.Warning);
    }

  }

  private void EmployeesForm_Load(object sender, EventArgs e) {
    // TODO: This line of code loads data into the 'northwindDataSet.Employees' table. You can move, or remove it, as needed.
    this.employeesTableAdapter.Fill(this.northwindDataSet.Employees);

  }
}
}
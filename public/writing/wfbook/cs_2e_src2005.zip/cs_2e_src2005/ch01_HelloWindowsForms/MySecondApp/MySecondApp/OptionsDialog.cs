using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class OptionsDialog : Form {
    public OptionsDialog() {
      InitializeComponent();
    }

    public Color FavoriteColor {
      get { return this.changeColorButton.BackColor; }
      set { this.changeColorButton.BackColor = value; }
    }

    private void changeColorButton_Click(object sender, EventArgs e) {
      this.colorDialog.Color = this.changeColorButton.BackColor;
      if( this.colorDialog.ShowDialog() == DialogResult.OK ) {
        this.changeColorButton.BackColor = this.colorDialog.Color;
      }
    }

    private void changeColorButton_Validating(object sender, CancelEventArgs e) {
      byte greenness = this.changeColorButton.BackColor.G;
      string err = "";
      if( greenness < Color.LightGreen.G ) {
        err = "I'm sorry, we were going for leafy, leafy...";
        e.Cancel = true;
      }
      this.errorProvider.SetError(changeColorButton, err);
    }

    private void okButton_Click(object sender, EventArgs e) {
      // Validate form
      bool isValid = this.Validate();
      // Don't close form if data is invalid
      if( !isValid ) this.DialogResult = DialogResult.None;
    }
  }
}
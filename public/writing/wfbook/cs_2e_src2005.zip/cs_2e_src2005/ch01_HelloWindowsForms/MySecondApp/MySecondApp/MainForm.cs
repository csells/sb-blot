using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MySecondApp {
  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();

      //// Read an application setting
      //decimal pi = Properties.Settings.Default.Pi;

      //// Write to an application setting
      //// NOTE: This won't compile
      //Properties.Settings.Default.Pi = 3.142;

      //// Write a user setting
      //Properties.Settings.Default.WindowLocation = this.Location;
    }
    
    private void optionsToolStripMenuItem_Click(object sender, EventArgs e) {
      OptionsDialog dlg = new OptionsDialog();
      dlg.FavoriteColor = this.BackColor;
      if( dlg.ShowDialog() == DialogResult.OK ) {
        this.BackColor = dlg.FavoriteColor;
      }
    }

    private void saveSettingsButton_Click(object sender, EventArgs e) {
      // Save all user settings
      Properties.Settings.Default.Save();
    }

    private void reloadSettingsButton_Click(object sender, EventArgs e) {
      // Revert back to last saved user settings
      Properties.Settings.Default.Reload();
    }

    private void resetSettingsButton_Click(object sender, EventArgs e) {
      // Revert back to default installed user settings
      Properties.Settings.Default.Reset();
    }
  }
}
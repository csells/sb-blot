namespace MySecondApp {
  partial class AddAPersonForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.saveSettingsButton = new System.Windows.Forms.Button();
      this.label1 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.firstNameTextBox = new System.Windows.Forms.TextBox();
      this.textBox2 = new System.Windows.Forms.TextBox();
      this.resetSettingsButton = new System.Windows.Forms.Button();
      this.addressUserControl1 = new MyFirstControlLibrary.UserControl1();
      this.SuspendLayout();
      // 
      // saveSettingsButton
      // 
      this.saveSettingsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.saveSettingsButton.Location = new System.Drawing.Point(250, 173);
      this.saveSettingsButton.Name = "saveSettingsButton";
      this.saveSettingsButton.Size = new System.Drawing.Size(75, 23);
      this.saveSettingsButton.TabIndex = 0;
      this.saveSettingsButton.Text = "Cancel";
      // 
      // label1
      // 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(12, 15);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(56, 13);
      this.label1.TabIndex = 1;
      this.label1.Text = "First Name:";
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.Location = new System.Drawing.Point(12, 41);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(57, 13);
      this.label2.TabIndex = 2;
      this.label2.Text = "Last Name:";
      // 
      // firstNameTextBox
      // 
      this.firstNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.firstNameTextBox.Location = new System.Drawing.Point(96, 12);
      this.firstNameTextBox.Name = "firstNameTextBox";
      this.firstNameTextBox.Size = new System.Drawing.Size(229, 20);
      this.firstNameTextBox.TabIndex = 3;
      // 
      // textBox2
      // 
      this.textBox2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.textBox2.Location = new System.Drawing.Point(96, 38);
      this.textBox2.Name = "textBox2";
      this.textBox2.Size = new System.Drawing.Size(229, 20);
      this.textBox2.TabIndex = 4;
      // 
      // resetSettingsButton
      // 
      this.resetSettingsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.resetSettingsButton.Location = new System.Drawing.Point(169, 173);
      this.resetSettingsButton.Name = "resetSettingsButton";
      this.resetSettingsButton.Size = new System.Drawing.Size(75, 23);
      this.resetSettingsButton.TabIndex = 5;
      this.resetSettingsButton.Text = "OK";
      // 
      // addressUserControl1
      // 
      this.addressUserControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.addressUserControl1.Location = new System.Drawing.Point(12, 62);
      this.addressUserControl1.Name = "addressUserControl1";
      this.addressUserControl1.Size = new System.Drawing.Size(317, 105);
      this.addressUserControl1.TabIndex = 6;
      // 
      // AddAPersonForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(337, 208);
      this.Controls.Add(this.addressUserControl1);
      this.Controls.Add(this.resetSettingsButton);
      this.Controls.Add(this.textBox2);
      this.Controls.Add(this.firstNameTextBox);
      this.Controls.Add(this.label2);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.saveSettingsButton);
      this.Name = "AddAPersonForm";
      this.Text = "Add a Person";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button saveSettingsButton;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.TextBox firstNameTextBox;
    private System.Windows.Forms.TextBox textBox2;
    private System.Windows.Forms.Button resetSettingsButton;
    private MyFirstControlLibrary.UserControl1 addressUserControl1;
  }
}


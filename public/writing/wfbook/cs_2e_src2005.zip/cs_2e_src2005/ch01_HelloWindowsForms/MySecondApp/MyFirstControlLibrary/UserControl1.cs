using System.Windows.Forms;

namespace MyFirstControlLibrary {
  public partial class UserControl1 : UserControl {
    public UserControl1() {
     InitializeComponent();
    }
  }
}
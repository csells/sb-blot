﻿namespace UsefulPrintingTechniquesSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.printDocument = new System.Drawing.Printing.PrintDocument();
      this.printButton = new System.Windows.Forms.Button();
      this.printDialog = new System.Windows.Forms.PrintDialog();
      this.previewPageNumericUpDown = new System.Windows.Forms.NumericUpDown();
      this.label1 = new System.Windows.Forms.Label();
      this.printPreviewControl = new System.Windows.Forms.PrintPreviewControl();
      this.editPageSettingsButton = new System.Windows.Forms.Button();
      this.pageSetupDialog = new System.Windows.Forms.PageSetupDialog();
      this.getPageCountButton = new System.Windows.Forms.Button();
      this.statusStrip = new System.Windows.Forms.StatusStrip();
      this.pageCountToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
      this.printPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
      ((System.ComponentModel.ISupportInitialize)(this.previewPageNumericUpDown)).BeginInit();
      this.statusStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // printDocument
      // 
      this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
      this.printDocument.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(this.printDocument_QueryPageSettings);
      this.printDocument.EndPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument_EndPrint);
      this.printDocument.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument_BeginPrint);
      // 
      // printButton
      // 
      this.printButton.Location = new System.Drawing.Point(13, 11);
      this.printButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.printButton.Name = "printButton";
      this.printButton.Size = new System.Drawing.Size(104, 23);
      this.printButton.TabIndex = 0;
      this.printButton.Text = "Print";
      this.printButton.Click += new System.EventHandler(this.printButton_Click);
      // 
      // printDialog
      // 
      this.printDialog.UseEXDialog = true;
      // 
      // previewPageNumericUpDown
      // 
      this.previewPageNumericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.previewPageNumericUpDown.Location = new System.Drawing.Point(222, 41);
      this.previewPageNumericUpDown.Margin = new System.Windows.Forms.Padding(1, 3, 3, 1);
      this.previewPageNumericUpDown.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.previewPageNumericUpDown.Name = "previewPageNumericUpDown";
      this.previewPageNumericUpDown.Size = new System.Drawing.Size(120, 20);
      this.previewPageNumericUpDown.TabIndex = 3;
      this.previewPageNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.previewPageNumericUpDown.ValueChanged += new System.EventHandler(this.previewPageNumericUpDown_ValueChanged);
      // 
      // label1
      // 
      this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(159, 44);
      this.label1.Margin = new System.Windows.Forms.Padding(3, 3, 1, 3);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(61, 13);
      this.label1.TabIndex = 4;
      this.label1.Text = "View Page:";
      // 
      // printPreviewControl
      // 
      this.printPreviewControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.printPreviewControl.AutoZoom = false;
      this.printPreviewControl.Document = this.printDocument;
      this.printPreviewControl.Location = new System.Drawing.Point(13, 66);
      this.printPreviewControl.Name = "printPreviewControl";
      this.printPreviewControl.Size = new System.Drawing.Size(329, 287);
      this.printPreviewControl.TabIndex = 5;
      this.printPreviewControl.Zoom = 0.33411764705882352;
      // 
      // editPageSettingsButton
      // 
      this.editPageSettingsButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.editPageSettingsButton.Location = new System.Drawing.Point(223, 11);
      this.editPageSettingsButton.Margin = new System.Windows.Forms.Padding(3, 1, 3, 3);
      this.editPageSettingsButton.Name = "editPageSettingsButton";
      this.editPageSettingsButton.Size = new System.Drawing.Size(120, 23);
      this.editPageSettingsButton.TabIndex = 6;
      this.editPageSettingsButton.Text = "Edit PageSettings";
      this.editPageSettingsButton.Click += new System.EventHandler(this.editPageSettingsButton_Click);
      // 
      // pageSetupDialog
      // 
      this.pageSetupDialog.Document = this.printDocument;
      // 
      // getPageCountButton
      // 
      this.getPageCountButton.Location = new System.Drawing.Point(13, 35);
      this.getPageCountButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.getPageCountButton.Name = "getPageCountButton";
      this.getPageCountButton.Size = new System.Drawing.Size(104, 23);
      this.getPageCountButton.TabIndex = 7;
      this.getPageCountButton.Text = "Get Page Count";
      this.getPageCountButton.Click += new System.EventHandler(this.getPageCountButton_Click);
      // 
      // statusStrip
      // 
      this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pageCountToolStripStatusLabel});
      this.statusStrip.Location = new System.Drawing.Point(0, 354);
      this.statusStrip.Name = "statusStrip";
      this.statusStrip.Padding = new System.Windows.Forms.Padding(0, 0, 12, 0);
      this.statusStrip.Size = new System.Drawing.Size(354, 22);
      this.statusStrip.TabIndex = 0;
      this.statusStrip.Text = "statusStrip";
      // 
      // pageCountToolStripStatusLabel
      // 
      this.pageCountToolStripStatusLabel.BorderStyle = System.Windows.Forms.Border3DStyle.Adjust;
      this.pageCountToolStripStatusLabel.Name = "pageCountToolStripStatusLabel";
      this.pageCountToolStripStatusLabel.Size = new System.Drawing.Size(0, 0);
      // 
      // printPreviewDialog
      // 
      this.printPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog.Document = this.printDocument;
      this.printPreviewDialog.Enabled = true;
      this.printPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog.Icon")));
      this.printPreviewDialog.Name = "printPreviewDialog";
      this.printPreviewDialog.Visible = false;
      // 
      // MainForm
      // 
      this.ClientSize = new System.Drawing.Size(354, 376);
      this.Controls.Add(this.getPageCountButton);
      this.Controls.Add(this.editPageSettingsButton);
      this.Controls.Add(this.printPreviewControl);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.previewPageNumericUpDown);
      this.Controls.Add(this.printButton);
      this.Controls.Add(this.statusStrip);
      this.MinimumSize = new System.Drawing.Size(362, 410);
      this.Name = "MainForm";
      this.Text = "Useful Printing Techniques";
      this.Load += new System.EventHandler(this.MainForm_Load);
      ((System.ComponentModel.ISupportInitialize)(this.previewPageNumericUpDown)).EndInit();
      this.statusStrip.ResumeLayout(false);
      this.statusStrip.PerformLayout();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Drawing.Printing.PrintDocument printDocument;
    private System.Windows.Forms.Button printButton;
    private System.Windows.Forms.PrintDialog printDialog;
    private System.Windows.Forms.NumericUpDown previewPageNumericUpDown;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.PrintPreviewControl printPreviewControl;
    private System.Windows.Forms.Button editPageSettingsButton;
    private System.Windows.Forms.PageSetupDialog pageSetupDialog;
    private System.Windows.Forms.Button getPageCountButton;
    private System.Windows.Forms.StatusStrip statusStrip;
    private System.Windows.Forms.ToolStripStatusLabel pageCountToolStripStatusLabel;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog;
  }
}


using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;

namespace UsefulPrintingTechniquesSample {

  class PageCountPrintController : PreviewPrintController {

    int pageCount = 0;

    public override void OnStartPrint(
      PrintDocument document, PrintEventArgs e) {
      base.OnStartPrint(document, e);
      this.pageCount = 0;
    }

    public override System.Drawing.Graphics OnStartPage(
      PrintDocument document, PrintPageEventArgs e) {
      // Increment page count
      ++this.pageCount;
      return base.OnStartPage(document, e);
    }

    public int PageCount {
      get { return this.pageCount; }
    }

    // Helper method to simplify client code
    public static int GetPageCount(PrintDocument document) {
      // Must have a print document to generate page count
      if( document == null )
        throw new ArgumentNullException("PrintDocument must be set.");

      // Subsitute this PrintController to cause a Print to initiate the 
      // count, which means that OnStartPrint and OnStartPage are called 
      // as the PrintDocument prints
      PrintController existingController = document.PrintController;
      PageCountPrintController controller =
        new PageCountPrintController();
      document.PrintController = controller;
      document.Print();
      document.PrintController = existingController;
      return controller.PageCount;
    }
  }

}


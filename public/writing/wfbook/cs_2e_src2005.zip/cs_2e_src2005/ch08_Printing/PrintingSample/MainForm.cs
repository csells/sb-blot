﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Printing;
using System.Windows.Forms;

#endregion

namespace PrintingSample {
  partial class MainForm : Form {
    
    string fileName = "myFile.txt";

    int totalPages = 13;
    int page;
    int maxPage;
    Font printerfont = null;
    bool preview;

    public MainForm() {
      InitializeComponent();
    }
    
    private void MainForm_Load(object sender, EventArgs e) {
      this.propertyGrid1.SelectedObject = this.printDocument.PrinterSettings;
    }

    private void printButton_Click(object sender, EventArgs e) {
      //      // Print using the default PrintControllerWithStatusDialog    
      //      printDocument.DocumentName = this.fileName;
      //      printDocument.Print();

      //      // Suppress the Printing dialog
      //      PrintController standard = new StandardPrintController();
      //      printDocument.PrintController = standard;
      //      printDocument.DocumentName = this.fileName;
      //      printDocument.Print();

      // Let the user choose the printer
      this.printDocument.PrinterSettings.FromPage = 1;
      this.printDocument.PrinterSettings.ToPage = totalPages;
      this.printDocument.PrinterSettings.MinimumPage = 1;
      this.printDocument.PrinterSettings.MaximumPage = totalPages;
      this.printDialog.AllowSomePages = true;
      this.printDialog.Document = this.printDocument;
      this.printDialog.UseEXDialog = this.useEXDialogCheckBox.Checked;

      if( this.printDialog.ShowDialog() == DialogResult.OK ) {
        if( this.printDialog.PrinterSettings.PrintRange == PrintRange.SomePages ) {
          // Set first page to print to FromPage
          page = this.printDocument.PrinterSettings.FromPage;

          // Set last page to print to ToPage
          maxPage = this.printDocument.PrinterSettings.ToPage;
        }
        else {
          // Print all pages
          page = 1;
          maxPage = totalPages;
        }

        // Print from first page to last page
        this.printDocument.DocumentName = this.fileName;
        this.printDocument.Print();
      }
    }

    private void printPreviewDialogButton_Click(object sender, EventArgs e) {
      // Calculate print preview range
      page = 1;
      maxPage = totalPages;
      // Print
      preview = true;
      this.printPreviewDialog.Document = this.printDocument;
      this.printPreviewDialog.Icon = Properties.Resources.printpreview; // Change icon
      this.printPreviewDialog.ShowDialog();
    }
    private void pageSetupButton_Click(object sender, EventArgs e) {
      // Let the user select page settings
      this.pageSetupDialog.Document = this.printDocument;
      this.pageSetupDialog.ShowDialog();
    }

    private void printDocument_BeginPrint(object sender, PrintEventArgs e) {
      // Create font for printing
      printerfont = new Font("Lucida Console", 30);

      // Print preview?
      preview = (e.PrintAction == PrintAction.PrintToPreview);
    }
    private void printDocument_PrintPage(object sender, PrintPageEventArgs e) {

      Graphics g = e.Graphics;
      g.PageUnit = GraphicsUnit.Inch;

      // print current page...
      //      g.DrawString("Hello,\nPrinter\nPage: " + page, font, Brushes.Black, e.MarginBounds);

      // Check if there are more pages to print
      ++page;
      e.HasMorePages = page <= maxPage;

      // Get the real page bounds
      RectangleF realPageBounds = GetRealPageBounds(e, preview);
      realPageBounds = TranslateBounds(g, Rectangle.Truncate(realPageBounds));

      StringFormat nearFormat = new StringFormat();
      nearFormat.Alignment = StringAlignment.Near;
      nearFormat.LineAlignment = StringAlignment.Near;

      StringFormat farFormat = new StringFormat();
      farFormat.Alignment = StringAlignment.Far;
      farFormat.LineAlignment = StringAlignment.Far;

      // Draw a header in the upper left
      g.DrawString("Header", printerfont, Brushes.Black, realPageBounds, nearFormat);

      // Draw a footer in the lower right
      g.DrawString("footer", printerfont, Brushes.Black, realPageBounds, farFormat);

      RectangleF realMarginBounds = GetRealMarginBounds(e, preview);
      realMarginBounds = TranslateBounds(g, Rectangle.Truncate(realMarginBounds));
      g.DrawString("Content", printerfont, Brushes.Black, realMarginBounds);

      using( Pen thinPen = new Pen(Color.Black, 0) ) {
        g.DrawRectangle(thinPen,
          realPageBounds.X,
          realPageBounds.Y,
          realPageBounds.Width,
          realPageBounds.Height);

        g.DrawRectangle(thinPen, realMarginBounds.X, realMarginBounds.Y, realMarginBounds.Width, realMarginBounds.Height);
      }
    }
    private void printDocument_EndPrint(object sender, PrintEventArgs e) {
      // Reclaim font
      printerfont.Dispose();
      printerfont = null;
    }
    private void printDocument_QueryPageSettings(object sender, QueryPageSettingsEventArgs e) {
      // Set margins to 0.5" all the way around
      // (measured in 100ths of an inch)
      e.PageSettings.Margins = new Margins(50, 50, 50, 50);
    }

    // Get real page bounds based on printable area of the page
    static Rectangle GetRealPageBounds(PrintPageEventArgs e, bool preview) {
      // Return in units of 1/100th of an inch
      if( preview ) return e.PageBounds;

      // Translate to units of 1/100th of an inch
      RectangleF vpb = e.Graphics.VisibleClipBounds;
      PointF[] bottomRight = { new PointF(vpb.Size.Width, vpb.Size.Height) };
      e.Graphics.TransformPoints(CoordinateSpace.Device, CoordinateSpace.Page, bottomRight);
      float dpiX = e.Graphics.DpiX;
      float dpiY = e.Graphics.DpiY;
      return new Rectangle(0, 0, (int)(bottomRight[0].X * 100 / dpiX), (int)(bottomRight[0].Y * 100 / dpiY));
    }

    // Adjust MarginBounds rectangle when printing based
    // on the physical characteristics of the printer
    static Rectangle GetRealMarginBounds(PrintPageEventArgs e, bool preview) {
      if( preview ) return e.MarginBounds;

      // Get printer’s offsets
      float cx = e.PageSettings.HardMarginX;
      float cy = e.PageSettings.HardMarginY;
      
      // Create the real margin bounds by scaling the offset
      // by the printer resolution and then rescaling it
      // back to 1/100th of an inch
      Rectangle marginBounds = e.MarginBounds;
      float dpiX = e.Graphics.DpiX;
      float dpiY = e.Graphics.DpiY;
      marginBounds.Offset((int)(-cx * 100 / dpiX), (int)(-cy * 100 / dpiY));
      return marginBounds;
    }
    
    static RectangleF TranslateBounds(Graphics g, Rectangle bounds) {
      // Translate from units of 1/100th of an inch to page units
      float dpiX = g.DpiX;
      float dpiY = g.DpiY;
      PointF[] pts = new PointF[2];
      pts[0] = new PointF(bounds.X * dpiX / 100, bounds.Y * dpiY / 100);
      pts[1] = new PointF(bounds.Width * dpiX / 100, bounds.Height * dpiX / 100);
      g.TransformPoints(CoordinateSpace.Page, CoordinateSpace.Device, pts);
      return new RectangleF(pts[0].X, pts[0].Y, pts[1].X, pts[1].Y);
    }
  }
}
﻿namespace PrintingSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.printButton = new System.Windows.Forms.Button();
      this.printDocument = new System.Drawing.Printing.PrintDocument();
      this.printPreviewDialog = new System.Windows.Forms.PrintPreviewDialog();
      this.printPreviewDialogButton = new System.Windows.Forms.Button();
      this.propertyGrid1 = new System.Windows.Forms.PropertyGrid();
      this.pageSetupDialog = new System.Windows.Forms.PageSetupDialog();
      this.pageSetupButton = new System.Windows.Forms.Button();
      this.printDialog = new System.Windows.Forms.PrintDialog();
      this.useEXDialogCheckBox = new System.Windows.Forms.CheckBox();
      this.SuspendLayout();
      // 
      // printButton
      // 
      this.printButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.printButton.Location = new System.Drawing.Point(13, 13);
      this.printButton.Name = "printButton";
      this.printButton.Size = new System.Drawing.Size(377, 23);
      this.printButton.TabIndex = 0;
      this.printButton.Text = "Print";
      this.printButton.Click += new System.EventHandler(this.printButton_Click);
      // 
      // printDocument
      // 
      this.printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument_PrintPage);
      this.printDocument.QueryPageSettings += new System.Drawing.Printing.QueryPageSettingsEventHandler(this.printDocument_QueryPageSettings);
      this.printDocument.EndPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument_EndPrint);
      this.printDocument.BeginPrint += new System.Drawing.Printing.PrintEventHandler(this.printDocument_BeginPrint);
      // 
      // printPreviewDialog
      // 
      this.printPreviewDialog.AutoScrollMargin = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.AutoScrollMinSize = new System.Drawing.Size(0, 0);
      this.printPreviewDialog.ClientSize = new System.Drawing.Size(400, 300);
      this.printPreviewDialog.Enabled = true;
      this.printPreviewDialog.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog.Icon")));
      this.printPreviewDialog.Name = "printPreviewDialog1";
      this.printPreviewDialog.Visible = false;
      // 
      // printPreviewDialogButton
      // 
      this.printPreviewDialogButton.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.printPreviewDialogButton.Location = new System.Drawing.Point(12, 42);
      this.printPreviewDialogButton.Name = "printPreviewDialogButton";
      this.printPreviewDialogButton.Size = new System.Drawing.Size(533, 23);
      this.printPreviewDialogButton.TabIndex = 2;
      this.printPreviewDialogButton.Text = "PrintPreviewDialog";
      this.printPreviewDialogButton.Click += new System.EventHandler(this.printPreviewDialogButton_Click);
      // 
      // propertyGrid1
      // 
      this.propertyGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.propertyGrid1.HelpVisible = false;
      this.propertyGrid1.Location = new System.Drawing.Point(13, 101);
      this.propertyGrid1.Name = "propertyGrid1";
      this.propertyGrid1.Size = new System.Drawing.Size(533, 328);
      this.propertyGrid1.TabIndex = 3;
      // 
      // pageSetupButton
      // 
      this.pageSetupButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.pageSetupButton.Location = new System.Drawing.Point(12, 72);
      this.pageSetupButton.Name = "pageSetupButton";
      this.pageSetupButton.Size = new System.Drawing.Size(533, 23);
      this.pageSetupButton.TabIndex = 4;
      this.pageSetupButton.Text = "Page Setup";
      this.pageSetupButton.Click += new System.EventHandler(this.pageSetupButton_Click);
      // 
      // useEXDialogCheckBox
      // 
      this.useEXDialogCheckBox.AutoSize = true;
      this.useEXDialogCheckBox.Location = new System.Drawing.Point(396, 17);
      this.useEXDialogCheckBox.Name = "useEXDialogCheckBox";
      this.useEXDialogCheckBox.Size = new System.Drawing.Size(150, 17);
      this.useEXDialogCheckBox.TabIndex = 5;
      this.useEXDialogCheckBox.Text = "Use Extended Print Dialog";
      this.useEXDialogCheckBox.UseVisualStyleBackColor = true;
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(558, 441);
      this.Controls.Add(this.useEXDialogCheckBox);
      this.Controls.Add(this.pageSetupButton);
      this.Controls.Add(this.propertyGrid1);
      this.Controls.Add(this.printPreviewDialogButton);
      this.Controls.Add(this.printButton);
      this.Name = "MainForm";
      this.Text = "Printing Sample Form";
      this.Load += new System.EventHandler(this.MainForm_Load);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button printButton;
    private System.Drawing.Printing.PrintDocument printDocument;
    private System.Windows.Forms.PrintPreviewDialog printPreviewDialog;
    private System.Windows.Forms.Button printPreviewDialogButton;
    private System.Windows.Forms.PropertyGrid propertyGrid1;
    private System.Windows.Forms.PageSetupDialog pageSetupDialog;
    private System.Windows.Forms.Button pageSetupButton;
    private System.Windows.Forms.PrintDialog printDialog;
    private System.Windows.Forms.CheckBox useEXDialogCheckBox;
  }
}

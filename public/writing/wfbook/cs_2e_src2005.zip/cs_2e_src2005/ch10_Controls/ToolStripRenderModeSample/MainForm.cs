using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ToolStripRenderModeSample {
  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void systemRadioButton_CheckedChanged(object sender, EventArgs e) {
      this.ChangeRenderMode(ToolStripRenderMode.System);
    }

    private void professionalRadioButton_CheckedChanged(object sender, EventArgs e) {
      this.ChangeRenderMode(ToolStripRenderMode.Professional);
    }

    private void managerRenderModeRadioButton_CheckedChanged(object sender, EventArgs e) {
      // Change all tool strips set to ManagerRenderMode to use ToolStripProfessionalRenderer
      this.ChangeRenderMode(ToolStripRenderMode.ManagerRenderMode);
      ToolStripManager.Renderer = new ToolStripProfessionalRenderer();
    }

    private void customRadioButton_CheckedChanged(object sender, EventArgs e) {
      CustomStatusStripRenderer renderer = new CustomStatusStripRenderer();
      this.statusStrip1.Renderer = renderer;

    }

    void ChangeRenderMode(ToolStripRenderMode mode) {
      foreach( Control control in this.Controls ) {
        if( (control is ToolStrip) && !(control is StatusStrip) ) {
          ((ToolStrip)control).RenderMode = mode;
        }
      }
    }
  }
}
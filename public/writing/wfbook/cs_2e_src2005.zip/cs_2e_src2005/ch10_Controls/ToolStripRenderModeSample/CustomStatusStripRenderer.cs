using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ToolStripRenderModeSample {
  public class CustomStatusStripRenderer : ToolStripRenderer {
    protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e) {
      Rectangle backgroundRect = e.AffectedBounds;
      Graphics g = e.Graphics;

      // Fill rectangle
      g.FillRectangle(SystemBrushes.Control, backgroundRect);

      // Draw highlight
      using( Pen highlightPen = new Pen(SystemColors.ControlLightLight) ) {
        g.DrawLine(highlightPen, 0, 0, backgroundRect.Width, 0);
      }
    }
  }
}

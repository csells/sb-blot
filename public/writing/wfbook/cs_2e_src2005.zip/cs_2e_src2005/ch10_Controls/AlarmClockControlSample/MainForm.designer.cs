﻿namespace AlarmClockControlSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.setAlarmButton = new System.Windows.Forms.Button();
      this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
      this.numericUpDown = new System.Windows.Forms.NumericUpDown();
      this.addMinutesButton = new System.Windows.Forms.Button();
      this.showSecondHandCheckBox = new System.Windows.Forms.CheckBox();
      this.alarmClockControl = new AlarmClockControlSample.AlarmClockControl();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).BeginInit();
      this.SuspendLayout();
      // 
      // setAlarmButton
      // 
      this.setAlarmButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.setAlarmButton.Location = new System.Drawing.Point(12, 306);
      this.setAlarmButton.Name = "setAlarmButton";
      this.setAlarmButton.Size = new System.Drawing.Size(75, 23);
      this.setAlarmButton.TabIndex = 1;
      this.setAlarmButton.Text = "Set Alarm";
      this.setAlarmButton.Click += new System.EventHandler(this.setAlarmButton_Click);
      // 
      // dateTimePicker
      // 
      this.dateTimePicker.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Time;
      this.dateTimePicker.Location = new System.Drawing.Point(94, 309);
      this.dateTimePicker.Name = "dateTimePicker";
      this.dateTimePicker.Size = new System.Drawing.Size(298, 20);
      this.dateTimePicker.TabIndex = 2;
      // 
      // numericUpDown
      // 
      this.numericUpDown.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.numericUpDown.Enabled = false;
      this.numericUpDown.Increment = new decimal(new int[] {
            15,
            0,
            0,
            0});
      this.numericUpDown.Location = new System.Drawing.Point(94, 339);
      this.numericUpDown.Maximum = new decimal(new int[] {
            60,
            0,
            0,
            0});
      this.numericUpDown.Name = "numericUpDown";
      this.numericUpDown.Size = new System.Drawing.Size(298, 20);
      this.numericUpDown.TabIndex = 5;
      this.numericUpDown.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
      // 
      // addMinutesButton
      // 
      this.addMinutesButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.addMinutesButton.Enabled = false;
      this.addMinutesButton.Location = new System.Drawing.Point(12, 336);
      this.addMinutesButton.Name = "addMinutesButton";
      this.addMinutesButton.Size = new System.Drawing.Size(75, 23);
      this.addMinutesButton.TabIndex = 4;
      this.addMinutesButton.Text = "Add Minutes";
      this.addMinutesButton.Click += new System.EventHandler(this.addMinutesButton_Click);
      // 
      // showSecondHandCheckBox
      // 
      this.showSecondHandCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.showSecondHandCheckBox.AutoSize = true;
      this.showSecondHandCheckBox.Checked = true;
      this.showSecondHandCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
      this.showSecondHandCheckBox.Location = new System.Drawing.Point(13, 367);
      this.showSecondHandCheckBox.Name = "showSecondHandCheckBox";
      this.showSecondHandCheckBox.Size = new System.Drawing.Size(128, 17);
      this.showSecondHandCheckBox.TabIndex = 7;
      this.showSecondHandCheckBox.Text = "Show Second Hand?";
      this.showSecondHandCheckBox.CheckedChanged += new System.EventHandler(this.showSecondHandCheckBox_CheckedChanged);
      // 
      // alarmClockControl
      // 
      this.alarmClockControl.Alarm = new System.DateTime(9999, 12, 31, 23, 59, 59, 999);
      this.alarmClockControl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.alarmClockControl.AutoScroll = true;
      this.alarmClockControl.AutoScrollMinSize = new System.Drawing.Size(200, 200);
      this.alarmClockControl.Location = new System.Drawing.Point(13, 13);
      this.alarmClockControl.Name = "alarmClockControl";
      this.alarmClockControl.Padding = new System.Windows.Forms.Padding(5);
      this.alarmClockControl.ShowSecondHand = true;
      this.alarmClockControl.Size = new System.Drawing.Size(380, 287);
      this.alarmClockControl.TabIndex = 6;
      this.alarmClockControl.Text = "A nice message!";
      this.alarmClockControl.AlarmSounded += new AlarmClockControlSample.AlarmSoundedEventHandler(this.alarmClockControl_AlarmSounded);
      this.alarmClockControl.Click += new System.EventHandler(this.alarmClockControl_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.AutoScroll = true;
      this.AutoScrollMinSize = new System.Drawing.Size(100, 100);
      this.ClientSize = new System.Drawing.Size(405, 392);
      this.Controls.Add(this.showSecondHandCheckBox);
      this.Controls.Add(this.alarmClockControl);
      this.Controls.Add(this.numericUpDown);
      this.Controls.Add(this.addMinutesButton);
      this.Controls.Add(this.dateTimePicker);
      this.Controls.Add(this.setAlarmButton);
      this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.Name = "MainForm";
      this.Text = "Alarm Clock Control Sample";
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button setAlarmButton;
    private System.Windows.Forms.DateTimePicker dateTimePicker;
    private System.Windows.Forms.NumericUpDown numericUpDown;
    private System.Windows.Forms.Button addMinutesButton;
    private System.Windows.Forms.CheckBox showSecondHandCheckBox;
    private AlarmClockControl alarmClockControl;

  }
}


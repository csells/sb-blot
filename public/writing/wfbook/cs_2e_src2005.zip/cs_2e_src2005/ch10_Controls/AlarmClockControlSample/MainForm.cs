﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void setAlarmButton_Click(object sender, EventArgs e) {
      this.alarmClockControl.Alarm = this.dateTimePicker.Value;
      this.addMinutesButton.Enabled = true;
      this.numericUpDown.Enabled = true;
    }

    private void alarmClockControl_AlarmSounded(object sender, AlarmSoundedEventArgs e) {
      MessageBox.Show("It's " + e.Alarm.ToString() + ". Wake up!");
    }

    private void addMinutesButton_Click(object sender, EventArgs e) {
      double minutes = (double)this.numericUpDown.Value;
      DateTime newAlarm = this.alarmClockControl.DelayAlarm(minutes);
      this.dateTimePicker.Value = newAlarm;
    }

    private void alarmClockControl_Click(object sender, EventArgs e) {
      if( Control.ModifierKeys == Keys.Control ) {
        MessageBox.Show("Ctrl+Click detected");
      }
    }

    private void showSecondHandCheckBox_CheckedChanged(object sender, EventArgs e) {
      this.alarmClockControl.ShowSecondHand = this.showSecondHandCheckBox.Checked;
    }
  }
}
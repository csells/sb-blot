﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace AlarmClockControlSample {
  public partial class AlarmClockControl : ScrollableControl {

    public AlarmClockControl() {
      InitializeComponent();

      base.DoubleBuffered = true;
      this.SetStyle(ControlStyles.ResizeRedraw, true);
    }

    DateTime alarm = DateTime.MaxValue; // No alarm
    public DateTime Alarm {
      get { return this.alarm; }
      set { this.alarm = value; }
    }

    bool showSecondHand = true;
    public bool ShowSecondHand {
      get { return this.showSecondHand; }
      set {
        this.showSecondHand = value;
        this.Invalidate();
      }
    }

    public event AlarmSoundedEventHandler AlarmSounded;
    public DateTime DelayAlarm(double minutes) {
      if( this.alarm < DateTime.MaxValue ) {
        this.alarm = this.alarm.AddMinutes(minutes);
      }
      return this.alarm;
    }

    protected override void OnPaddingChanged(EventArgs e) {
      base.OnPaddingChanged(e);
      this.Invalidate();
    }

    protected override void OnPaint(PaintEventArgs e) {

      Graphics g = e.Graphics;

      // Get specified date/time if control in design-time, 
      // or current date/time if control is in run-time
      DateTime now = DateTime.Now;

      // Calculate required dimensions
      //Size faceSize = this.ClientRectangle.Size;
      Size faceSize = this.DisplayRectangle.Size;
      int xRadius = faceSize.Width / 2;
      int yRadius = faceSize.Height / 2;
      double degrees;
      int x;
      int y;

      // Make things pretty
      g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

      // Paint clock face
      using( Pen facePen = new Pen(Color.Black, 2) )
      using( SolidBrush faceBrush = new SolidBrush(Color.White) ) {
        g.DrawEllipse(facePen, facePen.Width + this.Padding.Left, facePen.Width + this.Padding.Top, faceSize.Width - facePen.Width * 2, faceSize.Height - facePen.Width * 2);
        g.FillEllipse(faceBrush, facePen.Width + this.Padding.Left, facePen.Width + this.Padding.Top, faceSize.Width - facePen.Width * 2, faceSize.Height - facePen.Width * 2);
      }

      // Paint hour hand
      // Hour hand
      using( Pen hourHandPen = new Pen(Color.Black, 2) ) {
        degrees = (90.0 - ((now.Hour / 3.0) + (now.Minute / 180.0)) * 90.0) * (Math.PI / 180.0);
        x = (int)Math.Round((xRadius / 3.0) * Math.Cos(degrees));
        y = (int)-(Math.Round((yRadius / 3.0) * Math.Sin(degrees)));
        g.DrawLine(hourHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
      }

      // Paint minute hand
      using( Pen minuteHandPen = new Pen(Color.Black, 2) ) {
        degrees = (90.0 - (now.Minute / 15.0) * 90.0) * (Math.PI / 180.0);
        x = (int)Math.Round((xRadius / 2.0) * Math.Cos(degrees));
        y = (int)-(Math.Round((yRadius / 2.0) * Math.Sin(degrees)));
        g.DrawLine(minuteHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
      }

      // Paint second hand, if so configured
      if( this.showSecondHand ) {
        using( Pen secondHandPen = new Pen(Color.Red, 2) ) {
          degrees = (90.0 - (now.Second / 15.0) * 90.0) * (Math.PI / 180.0);
          x = (int)Math.Round((2.0 * xRadius / 3.0) * Math.Cos(degrees));
          y = (int)-(Math.Round((2.0 * yRadius / 3.0) * Math.Sin(degrees)));
          g.DrawLine(secondHandPen, xRadius + this.Padding.Left, yRadius + this.Padding.Top, x + xRadius + this.Padding.Left, y + yRadius + this.Padding.Top);
        }
      }

      // Paint clock text
      using( StringFormat format = new StringFormat() ) {
        format.Alignment = StringAlignment.Center;
        string nowFormatted = (this.showSecondHand ? now.ToString("dd/MM/yyyy hh:mm:ss tt") : now.ToString("dd/MM/yyyy hh:mm tt"));
        SizeF size = g.MeasureString(nowFormatted, this.Font);
        using( Brush brush = new SolidBrush(this.ForeColor) ) {
          // Paint digital time
          g.DrawString(nowFormatted, this.Font, brush, xRadius + this.Padding.Left, (yRadius * 1.6F) + this.Padding.Top, format);
        }
      }

      // Let the base class fire the Paint event
      base.OnPaint(e);
    }
    private void timer_Tick(object sender, EventArgs e) {

      // Check to see whether we're within 1 second of the alarm
      double seconds = (DateTime.Now - this.alarm).TotalSeconds;
      if( (seconds >= 0) && (seconds <= 1) ) {
        DateTime alarm = this.alarm;
        this.alarm = DateTime.MaxValue; // Show alarm only once
        if( this.AlarmSounded != null ) {
          // Sound alarm asynch so clock can keep ticking
          this.AlarmSounded.BeginInvoke(this, new AlarmSoundedEventArgs(alarm), null, null);
        }
      }

      if( this.showSecondHand ) {
        // Refresh clock face
        this.Invalidate();
      }
      else {
        if( (DateTime.Now.Second == 59) || (DateTime.Now.Second == 0) ) {
          this.Invalidate();
        }
      }
    }

    // Track whether mouse button is down
    private bool mouseDown = false;

    protected override void OnMouseDown(MouseEventArgs e) {
      this.mouseDown = true;
      this.SetForeColor(e);
      base.OnMouseDown(e);
    }
    protected override void OnMouseMove(MouseEventArgs e) {
      if( this.mouseDown ) this.SetForeColor(e);
      base.OnMouseMove(e);
    }
    protected override void OnMouseUp(MouseEventArgs e) {
      this.SetForeColor(e);
      this.mouseDown = false;
      base.OnMouseUp(e);
    }
    private void SetForeColor(MouseEventArgs e) {
      if( (e.Button & MouseButtons.Left) == MouseButtons.Left ) {
        int red = (e.X * 255 / (this.ClientRectangle.Width - e.X)) % 256;
        if( red < 0 ) red = -red;
        int green = 0;
        int blue = (e.Y * 255 / (this.ClientRectangle.Height - e.Y)) % 256;
        if( blue < 0 ) blue = -blue;
        this.ForeColor = Color.FromArgb(red, green, blue);
      }
    }

    //protected override void OnKeyPress(KeyPressEventArgs e) {
    //
    //  Point location = new Point(this.Left, this.Top);
    //
    //  switch( e.KeyChar ) {
    //    case 'i':
    //      --location.Y;
    //      break;
    //
    //    case 'j':
    //      --location.X;
    //      break;
    //
    //    case 'k':
    //      ++location.Y;
    //      break;
    //
    //    case 'l':
    //      ++location.X;
    //      break;
    //  }
    //
    //  this.Location = location;
    //  
    //  base.OnKeyPress(e);
    //}

    protected override void OnKeyDown(KeyEventArgs e) {

      Point location = new Point(this.Left, this.Top);

      switch( e.KeyCode ) {
        case Keys.I:
        case Keys.Up:
          --location.Y;
          break;

        case Keys.J:
        case Keys.Left:
          --location.X;
          break;

        case Keys.K:
        case Keys.Down:
          ++location.Y;
          break;

        case Keys.L:
        case Keys.Right:
          ++location.X;
          break;
      }

      this.Location = location;

      base.OnKeyDown(e);
    }
    protected override bool IsInputKey(Keys keyData) {
      // Make sure we get arrow keys
      switch( keyData ) {
        case Keys.Up:
        case Keys.Left:
        case Keys.Down:
        case Keys.Right:
          return true;
      }

      // The rest can be determined by the base class
      return base.IsInputKey(keyData);
    }
  }
}

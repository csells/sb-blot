﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

#endregion

namespace ExtendingControlsSample {
  public class FileTextBox : TextBox {
    protected override void OnTextChanged(EventArgs e) {

      // Let the base class process text changed first
      base.OnTextChanged(e);
      
      // If the file does not exist, color the text red
      if( !File.Exists(this.Text) ) {
        this.ForeColor = Color.Red;
      }
      else { // Make it black
        this.ForeColor = Color.Black;
      }
    }
  }
}

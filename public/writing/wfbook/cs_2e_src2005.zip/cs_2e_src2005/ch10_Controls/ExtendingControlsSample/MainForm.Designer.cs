﻿namespace ExtendingControlsSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.label1 = new System.Windows.Forms.Label();
      this.fileTextBox = new ExtendingControlsSample.FileTextBox();
      this.SuspendLayout();
// 
// label1
// 
      this.label1.AutoSize = true;
      this.label1.Location = new System.Drawing.Point(13, 13);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(62, 14);
      this.label1.TabIndex = 1;
      this.label1.Text = "File Exists?";
// 
// fileTextBox
// 
      this.fileTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.fileTextBox.ForeColor = System.Drawing.Color.Black;
      this.fileTextBox.Location = new System.Drawing.Point(82, 10);
      this.fileTextBox.Name = "fileTextBox";
      this.fileTextBox.Size = new System.Drawing.Size(171, 20);
      this.fileTextBox.TabIndex = 0;
      this.fileTextBox.Text = "c:\\autoexec.bat";
// 
// ExtendingControlsSampleForm
// 
      this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
      this.ClientSize = new System.Drawing.Size(265, 40);
      this.Controls.Add(this.label1);
      this.Controls.Add(this.fileTextBox);
      this.Name = "ExtendingControlsSampleForm";
      this.Text = "Extending Controls Sample";
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Label label1;
    private FileTextBox fileTextBox;
  }
}


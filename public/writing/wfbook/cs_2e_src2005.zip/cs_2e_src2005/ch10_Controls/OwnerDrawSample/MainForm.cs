﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace OwnerDrawSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }
    
    private void ownerDrawnFixedListBoxButton_Click(object sender, EventArgs e) {
      (new OwnerDrawnFixedSampleForm()).ShowDialog();
    }

    private void ownerDrawnVariableListBoxButton_Click(object sender, EventArgs e) {
      (new OwnerDrawnVariableSampleForm()).ShowDialog();
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace OwnerDrawSample {
  partial class OwnerDrawnFixedSampleForm : Form {
    public OwnerDrawnFixedSampleForm() {
      InitializeComponent();
    }

    private void listBox_DrawItem(object sender, DrawItemEventArgs e) {
      // Draw the background
      e.DrawBackground();

      // Get the default font
      Font drawFont = e.Font;
      bool ourFont = false;

      // Draw in italics if selected
      if( (e.State & DrawItemState.Selected) == DrawItemState.Selected ) {
        ourFont = true;
        drawFont = new Font(drawFont, FontStyle.Italic);
      }

      using( Brush brush = new SolidBrush(e.ForeColor) ) {
        // Draw the list box item
        e.Graphics.DrawString(listBox.Items[e.Index].ToString(), drawFont, brush, e.Bounds);
        if( ourFont ) drawFont.Dispose();
      }

      // Draw the focus rectangle
      e.DrawFocusRectangle();
    }
  }
}
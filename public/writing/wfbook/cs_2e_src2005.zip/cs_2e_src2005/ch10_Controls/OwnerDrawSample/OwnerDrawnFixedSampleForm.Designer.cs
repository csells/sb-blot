﻿namespace OwnerDrawSample {
  partial class OwnerDrawnFixedSampleForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.listBox = new System.Windows.Forms.ListBox();
      this.SuspendLayout();
      // 
      // listBox
      // 
      this.listBox.Dock = System.Windows.Forms.DockStyle.Fill;
      this.listBox.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
      this.listBox.FormattingEnabled = true;
      this.listBox.IntegralHeight = false;
      this.listBox.Items.AddRange(new object[] {
            "Foo",
            "Bar",
            "Quux"});
      this.listBox.Location = new System.Drawing.Point(0, 0);
      this.listBox.Name = "listBox";
      this.listBox.Size = new System.Drawing.Size(316, 143);
      this.listBox.TabIndex = 4;
      this.listBox.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox_DrawItem);
      // 
      // OwnerDrawnFixedSampleForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(316, 143);
      this.Controls.Add(this.listBox);
      this.Name = "OwnerDrawnFixedSampleForm";
      this.Text = "Owner-Drawn Fixed ListBox Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.ListBox listBox;
  }
}


﻿namespace OwnerDrawSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.ownerDrawnFixedListBoxButton = new System.Windows.Forms.Button();
      this.ownerDrawnVariableListBoxButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // ownerDrawnFixedListBoxButton
      // 
      this.ownerDrawnFixedListBoxButton.Location = new System.Drawing.Point(13, 13);
      this.ownerDrawnFixedListBoxButton.Name = "ownerDrawnFixedListBoxButton";
      this.ownerDrawnFixedListBoxButton.Size = new System.Drawing.Size(202, 23);
      this.ownerDrawnFixedListBoxButton.TabIndex = 0;
      this.ownerDrawnFixedListBoxButton.Text = "Owner-Drawn Fixed ListBox";
      this.ownerDrawnFixedListBoxButton.Click += new System.EventHandler(this.ownerDrawnFixedListBoxButton_Click);
      // 
      // ownerDrawnVariableListBoxButton
      // 
      this.ownerDrawnVariableListBoxButton.Location = new System.Drawing.Point(13, 43);
      this.ownerDrawnVariableListBoxButton.Name = "ownerDrawnVariableListBoxButton";
      this.ownerDrawnVariableListBoxButton.Size = new System.Drawing.Size(202, 23);
      this.ownerDrawnVariableListBoxButton.TabIndex = 1;
      this.ownerDrawnVariableListBoxButton.Text = "Owner-Drawn Variable ListBox";
      this.ownerDrawnVariableListBoxButton.Click += new System.EventHandler(this.ownerDrawnVariableListBoxButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(227, 81);
      this.Controls.Add(this.ownerDrawnVariableListBoxButton);
      this.Controls.Add(this.ownerDrawnFixedListBoxButton);
      this.Name = "MainForm";
      this.Text = "Owner-Draw Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button ownerDrawnFixedListBoxButton;
    private System.Windows.Forms.Button ownerDrawnVariableListBoxButton;
  }
}
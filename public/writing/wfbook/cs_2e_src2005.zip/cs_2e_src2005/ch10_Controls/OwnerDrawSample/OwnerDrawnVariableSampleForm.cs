﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

#endregion

namespace OwnerDrawSample {
  partial class OwnerDrawnVariableSampleForm : Form {
    public OwnerDrawnVariableSampleForm() {
      InitializeComponent();
    }

    private void listBox_DrawItem(object sender, DrawItemEventArgs e) {
      // Draw the background
      e.DrawBackground();

      // Get the default font
      Font drawFont = e.Font;
      bool ourFont = false;

      // Draw in italics if selected
      if( (e.State & DrawItemState.Selected) == DrawItemState.Selected ) {
        ourFont = true;
        drawFont = new Font(drawFont, FontStyle.Italic);
      }

      using( Brush brush = new SolidBrush(e.ForeColor) ) {
        // Draw every even item as disabled
        if( e.Index % 2 == 0 ) {
          ControlPaint.DrawStringDisabled(e.Graphics, listBox.Items[e.Index].ToString(), drawFont, this.ForeColor, e.Bounds, null);
        }
        else {
          e.Graphics.DrawString(listBox.Items[e.Index].ToString(), drawFont, brush, e.Bounds);
        }
      }

      if( ourFont ) drawFont.Dispose();
      
      // Draw the focus rectangle
      e.DrawFocusRectangle();
    }

    private void listBox_MeasureItem(object sender, MeasureItemEventArgs e) {
      // Make every even item twice as high
      if( e.Index % 2 == 0 ) e.ItemHeight *= 2;
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using UserControlLibrarySample;


#endregion

namespace UserControlSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }
  }
}
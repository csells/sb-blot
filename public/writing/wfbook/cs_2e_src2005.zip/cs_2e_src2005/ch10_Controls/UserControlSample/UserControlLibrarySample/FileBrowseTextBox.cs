﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

#endregion

namespace UserControlLibrarySample {
  public partial class FileBrowseTextBox : UserControl {
    public FileBrowseTextBox() {
      InitializeComponent();
    }

    private void openFileButton_Click(object sender, EventArgs e) {
      if( this.openFileDialog.ShowDialog() == DialogResult.OK ) {
        fileTextBox.Text = this.openFileDialog.FileName;
      }
    }
  }
}

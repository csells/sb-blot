﻿namespace UserControlLibrarySample {
  partial class FileBrowseTextBox {
    /// <summary> 
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary> 
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Component Designer generated code

    /// <summary> 
    /// Required method for Designer support - do not modify 
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
      this.openFileButton = new System.Windows.Forms.Button();
      this.fileTextBox = new UserControlLibrarySample.FileTextBox();
      this.SuspendLayout();
      // 
      // openFileButton
      // 
      this.openFileButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
      this.openFileButton.Location = new System.Drawing.Point(191, 3);
      this.openFileButton.Name = "openFileButton";
      this.openFileButton.Size = new System.Drawing.Size(27, 21);
      this.openFileButton.TabIndex = 1;
      this.openFileButton.Text = "...";
      this.openFileButton.Click += new System.EventHandler(this.openFileButton_Click);
      // 
      // fileTextBox
      // 
      this.fileTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.fileTextBox.ForeColor = System.Drawing.Color.Red;
      this.fileTextBox.Location = new System.Drawing.Point(4, 4);
      this.fileTextBox.Name = "fileTextBox";
      this.fileTextBox.Size = new System.Drawing.Size(187, 20);
      this.fileTextBox.TabIndex = 0;
      this.fileTextBox.Text = "fileTextBox";
      // 
      // FileBrowseTextBox
      // 
      this.Controls.Add(this.openFileButton);
      this.Controls.Add(this.fileTextBox);
      this.Name = "FileBrowseTextBox";
      this.Size = new System.Drawing.Size(222, 29);
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private FileTextBox fileTextBox;
    private System.Windows.Forms.OpenFileDialog openFileDialog;
    private System.Windows.Forms.Button openFileButton;
  }
}

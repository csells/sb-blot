using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ThemedControlRenderingSample {
  public partial class ThemedControlRenderingSampleForm : Form {
    public ThemedControlRenderingSampleForm() {
      InitializeComponent();
    }

    private void unthemedPanel_Paint(object sender, PaintEventArgs e) {
      // Render unthemed
      ControlPaint.DrawButton(e.Graphics, this.unthemedPanel.ClientRectangle, ButtonState.Normal);
    }

    private void themedPanel_Paint(object sender, PaintEventArgs e) {
      // Render themed button with the ButtonRenderer
      ButtonRenderer.DrawButton(e.Graphics, this.themedPanel.ClientRectangle, System.Windows.Forms.VisualStyles.PushButtonState.Normal);

      // Render themed button with the VisualStyleRenderer
      //VisualStyleRenderer renderer = new VisualStyleRenderer(VisualStyleElement.Button.PushButton.Normal);
      //renderer.DrawBackground(e.Graphics, this.themedPanel.ClientRectangle);
    }
  }
}
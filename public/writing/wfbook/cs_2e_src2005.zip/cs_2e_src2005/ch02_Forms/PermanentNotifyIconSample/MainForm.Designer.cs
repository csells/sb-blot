namespace PermanentNotifyIconSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.appNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
      this.contextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.waitForNotificationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.contextMenuStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // appNotifyIcon
      // 
      this.appNotifyIcon.ContextMenuStrip = this.contextMenuStrip;
      this.appNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("appNotifyIcon.Icon")));
      this.appNotifyIcon.Text = "Permanent NotifyIcon Sample";
      // 
      // contextMenuStrip
      // 
      this.contextMenuStrip.Enabled = true;
      this.contextMenuStrip.GripMargin = new System.Windows.Forms.Padding(2);
      this.contextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem,
            this.toolStripSeparator1,
            this.waitForNotificationToolStripMenuItem});
      this.contextMenuStrip.Location = new System.Drawing.Point(25, 66);
      this.contextMenuStrip.Name = "contextMenuStrip";
      this.contextMenuStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.contextMenuStrip.Size = new System.Drawing.Size(162, 76);
      // 
      // openToolStripMenuItem
      // 
      this.openToolStripMenuItem.Name = "openToolStripMenuItem";
      this.openToolStripMenuItem.Text = "Open";
      this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
      // 
      // closeToolStripMenuItem
      // 
      this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
      this.closeToolStripMenuItem.Text = "Close";
      this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      // 
      // waitForNotificationToolStripMenuItem
      // 
      this.waitForNotificationToolStripMenuItem.Name = "waitForNotificationToolStripMenuItem";
      this.waitForNotificationToolStripMenuItem.Text = "Wait For Notification";
      this.waitForNotificationToolStripMenuItem.Click += new System.EventHandler(this.waitForNotificationToolStripMenuItem_Click);
      // 
      // timer
      // 
      this.timer.Interval = 5000;
      this.timer.Tick += new System.EventHandler(this.timer_Tick);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(292, 266);
      this.Name = "MainForm";
      this.Text = "Permanent NotifyIcon Sample";
      this.Resize += new System.EventHandler(this.MainForm_Resize);
      this.contextMenuStrip.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.NotifyIcon appNotifyIcon;
    private System.Windows.Forms.ContextMenuStrip contextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem waitForNotificationToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
    private System.Windows.Forms.Timer timer;
  }
}


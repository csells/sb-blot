using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PermanentNotifyIconSample {
  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void MainForm_Resize(object sender, EventArgs e) {
      // Minimize to system tray
      if( FormWindowState.Minimized == WindowState ) {
        Hide();
        this.appNotifyIcon.Visible = true;
      }
    }

    void Open() {
      // Restore from system tray
      this.appNotifyIcon.Visible = false;
      this.Show();
      WindowState = FormWindowState.Normal;
    }

    private void openToolStripMenuItem_Click(object sender, EventArgs e) {
      Open();
    }

    private void closeToolStripMenuItem_Click(object sender, EventArgs e) {
      Open();
    }

    private void waitForNotificationToolStripMenuItem_Click(object sender, EventArgs e) {
      this.timer.Enabled = true;
    }

    private void timer_Tick(object sender, EventArgs e) {
      this.timer.Enabled = false;
      this.NewMailArrived(sender, e);
    }

    private void NewMailArrived() {
      // If notify icon is visible, notify user of new mail
      if( !this.appNotifyIcon.Visible ) return;
      this.appNotifyIcon.BalloonTipText = "New mail has arrived!";
      this.appNotifyIcon.ShowBalloonTip(3);
    }
  }
}


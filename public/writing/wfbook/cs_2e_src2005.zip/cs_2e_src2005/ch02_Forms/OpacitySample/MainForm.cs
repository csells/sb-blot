﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace OpacitySample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void MainForm_Activated(object sender, EventArgs e) {
      this.timer.Enabled = true;
    }

    private void MainForm_Deactivate(object sender, EventArgs e) {
      this.timer.Enabled = false;
      this.Opacity = 0.5;
      this.Text = "Opacity = " + this.Opacity.ToString();
    }

    private void timer_Tick(object sender, EventArgs e) {
      if( this.Opacity < 1.0 ) {
        this.Opacity += 0.1;
        this.Text = "Opacity = " + this.Opacity.ToString();
      }
      else this.timer.Enabled = false;
    }
  }
}
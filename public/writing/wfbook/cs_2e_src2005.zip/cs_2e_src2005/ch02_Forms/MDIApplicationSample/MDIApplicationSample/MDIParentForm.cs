using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace MDIApplicationSample {
  public partial class MDIParentForm : Form {

    static int formCount = 0;

    public MDIParentForm() {
      InitializeComponent();

      this.menuStrip.MdiWindowListItem.DropDownOpening += MdiWindowListItem_DropDownOpening;
    }

    void MdiWindowListItem_DropDownOpening(object sender, EventArgs e) {
      ToolStripItemCollection items = this.menuStrip.MdiWindowListItem.DropDownItems;
      if( items[items.Count - 1] is ToolStripSeparator ) {
        items.RemoveAt(items.Count - 1);
      }
    }
  
    private void newToolStripMenuItem_Click(object sender, EventArgs e) {
      // Create and show MDI Child Form with nice title
      MDIChildForm mdiChildForm = new MDIChildForm();
      mdiChildForm.MdiParent = this;
      mdiChildForm.Text = "MDI Child Form " + (++formCount).ToString();
      mdiChildForm.Show();
    }

    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }
    
    private void arrangeIconsToolStripMenuItem_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.ArrangeIcons);
    }

    private void cascadeToolStripMenuItem_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.Cascade);
    }

    private void tileVerticallyToolStripMenuItem_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.TileVertical);
    }

    private void tileHorizontallyToolStripMenuItem_Click(object sender, EventArgs e) {
      this.LayoutMdi(MdiLayout.TileHorizontal);
    }

    private void closeAllToolStripMenuItem_Click(object sender, EventArgs e) {
      foreach( Form mdiChildForm in MdiChildren ) {
        mdiChildForm.Close();
      }
    }
  }
}
﻿namespace NotifyIconSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && ( components != null ) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.components = new System.ComponentModel.Container();
      System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
      this.newMailNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
      this.newMailNotificationContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.closeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.notifyMeButton = new System.Windows.Forms.Button();
      this.timer = new System.Windows.Forms.Timer(this.components);
      this.appNotifyIcon = new System.Windows.Forms.NotifyIcon(this.components);
      this.appContextMenuStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
      this.openAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.closeAppToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
      this.notifyMeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
      this.newMailNotificationContextMenuStrip.SuspendLayout();
      this.appContextMenuStrip.SuspendLayout();
      this.SuspendLayout();
      // 
      // newMailNotifyIcon
      // 
      this.newMailNotifyIcon.ContextMenuStrip = this.newMailNotificationContextMenuStrip;
      this.newMailNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("newMailNotifyIcon.Icon")));
      this.newMailNotifyIcon.Text = "New mail has arrived!";
      this.newMailNotifyIcon.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.newMailNotifyIcon_MouseDoubleClick);
      // 
      // newMailNotificationContextMenuStrip
      // 
      this.newMailNotificationContextMenuStrip.AllowDrop = true;
      this.newMailNotificationContextMenuStrip.Enabled = true;
      this.newMailNotificationContextMenuStrip.GripMargin = new System.Windows.Forms.Padding(2);
      this.newMailNotificationContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.closeToolStripMenuItem});
      this.newMailNotificationContextMenuStrip.Location = new System.Drawing.Point(25, 66);
      this.newMailNotificationContextMenuStrip.Name = "newMailNotificationContextMenuStrip";
      this.newMailNotificationContextMenuStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.newMailNotificationContextMenuStrip.Size = new System.Drawing.Size(97, 48);
      // 
      // openToolStripMenuItem
      // 
      this.openToolStripMenuItem.Name = "openToolStripMenuItem";
      this.openToolStripMenuItem.Text = "&Open";
      this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
      // 
      // closeToolStripMenuItem
      // 
      this.closeToolStripMenuItem.Name = "closeToolStripMenuItem";
      this.closeToolStripMenuItem.Text = "&Close";
      this.closeToolStripMenuItem.Click += new System.EventHandler(this.closeToolStripMenuItem_Click);
      // 
      // notifyMeButton
      // 
      this.notifyMeButton.Location = new System.Drawing.Point(13, 13);
      this.notifyMeButton.Name = "notifyMeButton";
      this.notifyMeButton.Size = new System.Drawing.Size(196, 23);
      this.notifyMeButton.TabIndex = 0;
      this.notifyMeButton.Text = "Wait For Notification";
      this.notifyMeButton.Click += new System.EventHandler(this.notifyMeButton_Click);
      // 
      // timer
      // 
      this.timer.Interval = 5000;
      this.timer.Tick += new System.EventHandler(this.timer_Tick);
      // 
      // appNotifyIcon
      // 
      this.appNotifyIcon.ContextMenuStrip = this.appContextMenuStrip;
      this.appNotifyIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("appNotifyIcon.Icon")));
      this.appNotifyIcon.Text = "Notify Icon Sample";
      this.appNotifyIcon.DoubleClick += new System.EventHandler(this.appNotifyIcon_DoubleClick);
      // 
      // appContextMenuStrip
      // 
      this.appContextMenuStrip.AllowDrop = true;
      this.appContextMenuStrip.Enabled = true;
      this.appContextMenuStrip.GripMargin = new System.Windows.Forms.Padding(2);
      this.appContextMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openAppToolStripMenuItem,
            this.closeAppToolStripMenuItem,
            this.toolStripSeparator1,
            this.notifyMeToolStripMenuItem});
      this.appContextMenuStrip.Location = new System.Drawing.Point(23, 61);
      this.appContextMenuStrip.Name = "appContextMenuStrip";
      this.appContextMenuStrip.RightToLeft = System.Windows.Forms.RightToLeft.No;
      this.appContextMenuStrip.Size = new System.Drawing.Size(162, 76);
      // 
      // openAppToolStripMenuItem
      // 
      this.openAppToolStripMenuItem.Name = "openAppToolStripMenuItem";
      this.openAppToolStripMenuItem.Text = "Open";
      this.openAppToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
      // 
      // closeAppToolStripMenuItem
      // 
      this.closeAppToolStripMenuItem.Name = "closeAppToolStripMenuItem";
      this.closeAppToolStripMenuItem.Text = "Close";
      this.closeAppToolStripMenuItem.Click += new System.EventHandler(this.closeAppToolStripMenuItem_Click);
      // 
      // toolStripSeparator1
      // 
      this.toolStripSeparator1.Name = "toolStripSeparator1";
      // 
      // notifyMeToolStripMenuItem
      // 
      this.notifyMeToolStripMenuItem.Name = "notifyMeToolStripMenuItem";
      this.notifyMeToolStripMenuItem.Text = "Wait For Notification";
      this.notifyMeToolStripMenuItem.Click += new System.EventHandler(this.notifyMeToolStripMenuItem_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(221, 51);
      this.Controls.Add(this.notifyMeButton);
      this.Name = "MainForm";
      this.Text = "Notify Icon Sample";
      this.Resize += new System.EventHandler(this.MainForm_Resize);
      this.newMailNotificationContextMenuStrip.ResumeLayout(false);
      this.appContextMenuStrip.ResumeLayout(false);
      this.ResumeLayout(false);
    }

    #endregion

    private System.Windows.Forms.NotifyIcon newMailNotifyIcon;
    private System.Windows.Forms.Button notifyMeButton;
    private System.Windows.Forms.Timer timer;
    private System.Windows.Forms.ContextMenuStrip newMailNotificationContextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem closeToolStripMenuItem;
    private System.Windows.Forms.NotifyIcon appNotifyIcon;
    private System.Windows.Forms.ContextMenuStrip appContextMenuStrip;
    private System.Windows.Forms.ToolStripMenuItem openAppToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem closeAppToolStripMenuItem;
    private System.Windows.Forms.ToolStripMenuItem notifyMeToolStripMenuItem;
    private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
  }
}

﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;

#endregion

namespace NotifyIconSample {
  partial class MainForm : Form {

    [DllImport("user32.dll")]
    static extern bool SetForegroundWindow(IntPtr hWnd);

    public MainForm() {
      InitializeComponent();
    }

    private void notifyMeButton_Click(object sender, EventArgs e) {
      // Enable simulated mail receipt
      this.timer.Enabled = true;
    }

    // Simulate receiving a new mail
    private void timer_Tick(object sender, EventArgs e) {
      this.timer.Enabled = false;
      mailWatcher_NewMail(this, EventArgs.Empty);
    }

    void mailWatcher_NewMail(object sender, EventArgs e) {
      // Show the system tray icon to provide latent access to 
      // notification message
      this.newMailNotifyIcon.Visible = true;
    }

    private void newMailNotifyIcon_MouseDoubleClick(object sender, MouseEventArgs e) {
      this.newMailNotifyIcon.Visible = false;
      this.Activate();
      NewMail();
    } 

    private void openToolStripMenuItem_Click(object sender, EventArgs e) {
      this.newMailNotifyIcon.Visible = false;
      this.Activate(); 
      NewMail();
    }

    private void closeToolStripMenuItem_Click(object sender, EventArgs e) {
      this.newMailNotifyIcon.Visible = false;
    }


    private void NewMail() {
      // Show new mail
      MailForm mailForm = new MailForm();
      mailForm.Show();
    }

    private void MainForm_Resize(object sender, EventArgs e) {
      // Minimize to system tray
      if( FormWindowState.Minimized == WindowState ) {
        Hide();
        this.appNotifyIcon.Visible = true;
      }
    }

    private void appNotifyIcon_DoubleClick(object sender, EventArgs e) {
      Open();
    }

    private void openAppToolStripMenuItem_Click(object sender, EventArgs e) {
      Open();
    }

    private void closeAppToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }

    private void notifyMeToolStripMenuItem_Click(object sender, EventArgs e) {
      this.timer.Enabled = true;
    }

    private void Open() {
      // Restore from system tray
      this.appNotifyIcon.Visible = false;
      Show();
      WindowState = FormWindowState.Normal;
    }
  }
}
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StripControlsSample {
  public delegate void BuildProgress(object sender, int progressPercent);

  public partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
      this.mainMenuStrip.Visible = true;
      this.alternateMenuStrip.Visible = false;
      
      this.MainMenuStrip = this.mainMenuStrip;
      
      
    }

    private void newToolStripMenuItem_Click(object sender, EventArgs e) {
      MessageBox.Show("Out with the old, in with the new!", "File | New");
    }

    private void aboutToolStripMenuItem_Click(object sender, EventArgs e) {
      MessageBox.Show("Ain't menus cool?", "About...");
    }
    
    private void exitToolStripMenuItem_Click(object sender, EventArgs e) {
      this.Close();
    }

    private event BuildProgress BuildProgress;
    private event EventHandler BuildComplete;
    
    private void rebuildButton_Click(object sender, EventArgs e) {
      // Kick rebuild off
      this.readyToolStripStatusLabel.Text = "Rebuild All started...";
      this.animationToolStripStatusLabel.Visible = true;
      this.statusToolStripProgressBar.Visible = true;
      this.buildSimulatorTimer.Enabled = true;
      this.BuildProgress += BuildProgressHandler;
      this.BuildComplete += BuildCompleteHandler;
    }

    private void buildSimulatorTimer_Tick(object sender, EventArgs e) {
      // Report progress
      this.readyToolStripStatusLabel.Text = "Build Progress";
      BuildProgress(this, this.statusToolStripProgressBar.Value + 10);
      if( this.statusToolStripProgressBar.Value == 100 ) {
        this.buildSimulatorTimer.Enabled = false;
        this.statusToolStripProgressBar.Value = 0;
        BuildComplete(this, null);
      }
    }
    
    private void BuildProgressHandler(object sender, int progress) {
      // Show progress
      this.statusToolStripProgressBar.Value = progress;
    }

    private void BuildCompleteHandler(object sender, EventArgs e) {
      // Show completion
      this.readyToolStripStatusLabel.Text = "Rebuild All succeeded";
      this.statusToolStripProgressBar.Visible = false;
      this.animationToolStripStatusLabel.Visible = false;
    }

    private void readyToolStripStatusLabel_Click(object sender, EventArgs e) {
      MessageBox.Show("adsf");
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace TransparencySample {
  public partial class MainForm : Form {

    public MainForm() {
      InitializeComponent();
    }

    private void MainForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( Pen pen = new Pen(Color.DarkBlue, 4) ) {
        Rectangle rect = this.ClientRectangle;
        rect.Inflate(-2, -2);
        g.FillEllipse(Brushes.Yellow, rect);
        g.DrawEllipse(pen, rect);
      }
      using( Font font = new Font(this.Font, FontStyle.Bold) ) {
        StringFormat format = new StringFormat();
        format.Alignment = StringAlignment.Center;
        format.LineAlignment = StringAlignment.Center;
        g.DrawString("an ellipse", font, Brushes.DarkBlue, this.ClientRectangle, format);
      }
    }

    private void SetEllipseRegion() {
      // Assume: this.FormBorderStyle = FormBorderStyle.None
      Rectangle rect = this.ClientRectangle;
      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(rect);
        this.Region = new Region(path);
      }
    }

    private void MainForm_Load(object sender, EventArgs e) {
      SetEllipseRegion();
    }

    private void MainForm_SizeChanged(object sender, EventArgs e) {
      SetEllipseRegion();
    }

    Point downPoint = Point.Empty;

    private void MainForm_MouseDown(object sender, MouseEventArgs e) {
      if( e.Button != MouseButtons.Left ) return;
      downPoint = new Point(e.X, e.Y);
    }

    private void MainForm_MouseMove(object sender, MouseEventArgs e) {
      if( downPoint == Point.Empty ) return;
      Point location = 
      new Point(
        this.Left + e.X - downPoint.X,
        this.Top + e.Y - downPoint.Y);
      this.Location = location;
    }

    private void MainForm_MouseUp(object sender, MouseEventArgs e) {
      if( e.Button != MouseButtons.Left ) return;
      downPoint = Point.Empty;
    }

    private void MainForm_KeyDown(object sender, KeyEventArgs e) {
      Point location = new Point(this.Left, this.Top);

      switch( e.KeyCode ) {
        case Keys.I:
        case Keys.Up:
          --location.Y;
          break;

        case Keys.J:
        case Keys.Left:
          --location.X;
          break;

        case Keys.K:
        case Keys.Down:
          ++location.Y;
          break;

        case Keys.L:
        case Keys.Right:
          ++location.X;
          break;
      }

      this.Location = location;
    }

    private void MainForm_KeyPress(object sender, KeyPressEventArgs e) {
      Point location = new Point(this.Left, this.Top);

      switch( e.KeyChar ) {
        case 'i':
          --location.Y;
          break;

        case 'j':
          --location.X;
          break;

        case 'k':
          ++location.Y;
          break;

        case 'l':
          ++location.X;
          break;
      }

      this.Location = location;
    }
  }
}
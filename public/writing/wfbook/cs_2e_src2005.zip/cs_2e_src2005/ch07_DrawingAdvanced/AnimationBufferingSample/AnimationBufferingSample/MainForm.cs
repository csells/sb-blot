﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace AnimationBufferingSample {

  partial class MainForm : Form {

    // Keep buffered graphics context open across method calls 
    // and event handling
    private BufferedGraphicsContext bufferContext;

    // Load gif from project resources
    private Bitmap gif = Properties.Resources.headspin;

    public MainForm() {

      InitializeComponent();

      // Allocate the buffer context for a maximum desired size
      bufferContext = new BufferedGraphicsContext();
      bufferContext.MaximumBuffer = this.ClientRectangle.Size;

      // Animate the gif, if possible
      if( ImageAnimator.CanAnimate(gif) ) {
        ImageAnimator.Animate(gif, gif_FrameChanged);
      }
    }

    private void gif_FrameChanged(object sender, EventArgs e) {
    
      // Create a graphics buffer drawing surface and associate it
      // with the target graphics surface, which is the host form's
      // drawing surface in this example
      Graphics g = this.CreateGraphics();
      using( BufferedGraphics frame = bufferContext.Allocate(g, this.ClientRectangle) ) {

        // Get next gif frame
        ImageAnimator.UpdateFrames(gif);

        // Render to buffered graphics
        frame.Graphics.DrawImage(gif, this.ClientRectangle);

        // Render buffered graphics to target drawing surface
        frame.Render();
      }
    }

    private void MainForm_FormClosing(object sender, FormClosingEventArgs e) {
      // Release outstanding system drawing resources
      bufferContext.Dispose();
    }
  }
}
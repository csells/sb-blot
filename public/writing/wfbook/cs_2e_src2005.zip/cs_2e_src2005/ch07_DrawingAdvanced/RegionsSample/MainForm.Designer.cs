﻿namespace RegionsSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.pathsVsRegionsButton = new System.Windows.Forms.Button();
      this.clippingButton = new System.Windows.Forms.Button();
      this.combinationsButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // pathsVsRegionsButton
      // 
      this.pathsVsRegionsButton.Location = new System.Drawing.Point(13, 13);
      this.pathsVsRegionsButton.Name = "pathsVsRegionsButton";
      this.pathsVsRegionsButton.Size = new System.Drawing.Size(140, 23);
      this.pathsVsRegionsButton.TabIndex = 0;
      this.pathsVsRegionsButton.Text = "Paths vs Regions";
      this.pathsVsRegionsButton.Click += new System.EventHandler(this.pathsVsRegionsButton_Click);
      // 
      // clippingButton
      // 
      this.clippingButton.Location = new System.Drawing.Point(13, 43);
      this.clippingButton.Name = "clippingButton";
      this.clippingButton.Size = new System.Drawing.Size(140, 23);
      this.clippingButton.TabIndex = 1;
      this.clippingButton.Text = "Clipping";
      this.clippingButton.Click += new System.EventHandler(this.clippingButton_Click);
      // 
      // combinationsButton
      // 
      this.combinationsButton.Location = new System.Drawing.Point(13, 73);
      this.combinationsButton.Name = "combinationsButton";
      this.combinationsButton.Size = new System.Drawing.Size(140, 23);
      this.combinationsButton.TabIndex = 2;
      this.combinationsButton.Text = "Combinations";
      this.combinationsButton.Click += new System.EventHandler(this.combinationsButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(165, 109);
      this.Controls.Add(this.combinationsButton);
      this.Controls.Add(this.clippingButton);
      this.Controls.Add(this.pathsVsRegionsButton);
      this.Name = "MainForm";
      this.Text = "Regions";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button pathsVsRegionsButton;
    private System.Windows.Forms.Button clippingButton;
    private System.Windows.Forms.Button combinationsButton;
  }
}


﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace RegionsSample {
  partial class ClippingRegionForm : Form {
    public ClippingRegionForm() {
      InitializeComponent();

      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    private void ClippingRegionForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(this.ClientRectangle);
        using( Region region = new Region(path) ) {
          // Frame clipping region
          g.DrawPath(Pens.Red, path);

          // Don't draw outside the ellipse region
          g.Clip = region;

          // Draw a rectangle
          Rectangle rect = this.ClientRectangle;
          rect.Offset(10, 10);
          rect.Width -= 20;
          rect.Height -= 20;
          g.FillRectangle(Brushes.Black, rect);
          g.DrawString("Rectangle clipped to Ellipse", this.Font, Brushes.White, rect, format);
        }
      }
    }
  }
}
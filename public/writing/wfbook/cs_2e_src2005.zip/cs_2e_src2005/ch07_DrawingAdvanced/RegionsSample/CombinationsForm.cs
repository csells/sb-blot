﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace RegionsSample {
  partial class CombinationsForm : Form {
    public CombinationsForm() {
      InitializeComponent();
    }

    private void CombinationsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      float width = this.ClientSize.Width / 5;
      float height = this.ClientSize.Height;
      RectangleF rect = new RectangleF(0, 0, width, height);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path1 = new GraphicsPath() )
      using( GraphicsPath path2 = new GraphicsPath() ) {
        // Two overlapping ellipses
        RectangleF path1Rect = new RectangleF(0, 0, width * 2f / 3f, height);
        RectangleF path2Rect = path1Rect;
        path2Rect.Offset(width * 1f / 3f, 0);
        path1.AddEllipse(path1Rect);
        path2.AddEllipse(path2Rect);

        // Union
        using( Region region = new Region(path1) ) {
          region.Union(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Union", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Intersect the easy way
        using( Region region = new Region(path1) ) {
          region.Intersect(path2);
          g.FillRegion(Brushes.Red, region);
        }

        // Intersect the hard way
//        using( Region region = new Region() ) {
//          // Defaults to region.IsInfinit(g) == true
//          if( !region.IsEmpty(g) ) region.MakeEmpty();
//          region.Union(path1); // Add a path
//          region.Intersect(path2); // Intersect with another path
//          g.FillRegion(Brushes.Red, region);
//        }

        g.DrawString("Intersect", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Exclude
        using( Region region = new Region(path1) ) {
          region.Exclude(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Exclude", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Complement
        using( Region region = new Region(path1) ) {
          region.Complement(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Comple-\nment", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

        // Xor
        using( Region region = new Region(path1) ) {
          region.Xor(path2);
          g.FillRegion(Brushes.Red, region);
        }
        g.DrawString("Xor", this.Font, Brushes.Black, rect, format);
        g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
        g.TranslateTransform(width, 0);

      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace RegionsSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void pathsVsRegionsButton_Click(object sender, EventArgs e) {
      (new PathAndRegionForm()).ShowDialog();
    }

    private void clippingButton_Click(object sender, EventArgs e) {
      (new ClippingRegionForm()).ShowDialog();
    }

    private void combinationsButton_Click(object sender, EventArgs e) {
      (new CombinationsForm()).ShowDialog();
    }
  }
}
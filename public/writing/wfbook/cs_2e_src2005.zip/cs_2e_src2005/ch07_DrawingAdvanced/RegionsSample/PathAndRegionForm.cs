﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace RegionsSample {
  partial class PathAndRegionForm : Form {
    public PathAndRegionForm() {
      InitializeComponent();

      this.SetStyle(ControlStyles.ResizeRedraw, true);
      this.SetStyle(ControlStyles.OptimizedDoubleBuffer, true);
      this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
    }

    private void PathAndRegionForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      RectangleF rect = new RectangleF(0, 0, this.ClientSize.Width / 2f, this.ClientSize.Height);

      using( GraphicsPath path = new GraphicsPath() ) {
        path.AddEllipse(rect);
        path.Flatten(new Matrix(), 13f);
        path.AddString("Flattened Ellipse", this.Font.FontFamily, (int)this.Font.Style, this.Font.GetHeight(g), rect, format);
        g.FillPath(Brushes.Green, path);
        g.DrawPath(Pens.Black, path);
        g.TranslateTransform(rect.Width, 0);

        using( Region region = new Region(path) ) {
          g.FillRegion(Brushes.Red, region);
        }
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class ShearingForm : Form {
    public ShearingForm() {
      InitializeComponent();
    }

    private void ShearingForm_Paint(object sender, PaintEventArgs e) {
   
      Graphics g = e.Graphics;
      float width = 150; //g.MeasureString("Shear(.0, 0)", this.Font).Width;
      float height = 50; //this.Font.GetHeight(g);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      RectangleF rect = new RectangleF(0, 0, width, height);
      Matrix matrix;

      matrix = new Matrix();
      matrix.Translate(0, 0);
      matrix.Shear(0f, 0f);
      g.Transform = matrix;
      g.DrawString("Shear(0, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);

      matrix = new Matrix();
      matrix.Shear(.5f, 0f); // Shear in x dimension only
      matrix.Translate(width, 0);
      g.Transform = matrix;
      g.DrawString("Shear(.5, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);

      matrix = new Matrix();
      matrix.Translate(2 * width, 0);
      matrix.Shear(1f, 0f);
      g.Transform = matrix;
      g.DrawString("Shear(1, 0)", this.Font, Brushes.Black, rect, format);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
      
      // Foo(g);
    }

//    private void Foo(Graphics g) {
//      Matrix matrix = new Matrix();
//      matrix.Translate(10, 20); // Move orgin to (10, 20)
//      matrix.Scale(2, 3); // Scale x/width and y/width by 2 and 3
//
//      matrix.Reset();
//      matrix.Scale(2, 3); // Scale x/width and y/width by 2 and 3
//      matrix.Translate(10, 20, MatrixOrder.Append); // Move orgin to (20, 60)
//
//      g.Transform = matrix;
//      g.DrawString("(0, 0)", this.Font, Brushes.Black, 0, 0);
//    }
  }
}
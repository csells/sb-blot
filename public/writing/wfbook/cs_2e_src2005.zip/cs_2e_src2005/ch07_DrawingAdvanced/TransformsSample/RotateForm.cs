﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class RotateForm : Form {
    public RotateForm() {
      InitializeComponent();
    }

    private void RotateForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;

      int x = 25;
      int y = 25;
      int width = 275; //this.ClientSize.Width;
      int height = 250; //this.ClientSize.Height;
      float textWidth = g.MeasureString("00", this.Font).Width;
      float length = Math.Min(width - x, height - x) - textWidth;
      RectangleF textRect = new RectangleF(x + length, y - this.Font.GetHeight(g) / 2, length, textWidth);
      //RectangleF textRect = new RectangleF(x + length, 0 - this.Font.GetHeight(g) / 2, length, textWidth);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Near;
      format.LineAlignment = StringAlignment.Center;

      for( int i = 0; i <= 90; i += 10 ) {
        Matrix matrix = new Matrix();
        //matrix.Rotate(i);
        matrix.RotateAt(i, new PointF(x, y));
        g.Transform = matrix;
        g.DrawLine(Pens.Black, x, y, x + length, y);
        g.DrawString(i.ToString(), this.Font, Brushes.Black, textRect, format);
      }
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class PathFlattenForm : Form {
    public PathFlattenForm() {
      InitializeComponent();
    }

    private void PathFlattenForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      float width = this.ClientSize.Width / 4f;
      float height = this.ClientSize.Height;
      RectangleF rect = new RectangleF(0, 0, width, height);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      using( GraphicsPath path = new GraphicsPath() ) {
        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw normal
        g.DrawPath(Pens.Black, path);
        g.DrawString("Ellipse", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);

        // Draw flattened
        path.Flatten(new Matrix(), 10);
        g.DrawPath(Pens.Black, path);
        g.DrawString("Flattened", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);

        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw widened
        using( Pen widenPen = new Pen(Color.Empty /* ignored */, 10) ) {
          path.Widen(widenPen);
          g.DrawPath(Pens.Black, path);
          g.DrawString("Widened", this.Font, Brushes.Black, rect, format);
          g.TranslateTransform(width, 0);
        }

        // Reset
        path.Reset();
        path.AddEllipse(rect);

        // Draw warped
        PointF[] destPoints = new PointF[3];
        destPoints[0] = new PointF(width / 2, 0);
        destPoints[1] = new PointF(width, height);
        destPoints[2] = new PointF(0, height / 2);
        RectangleF srcRect = new RectangleF(0, 0, width, height / 2);
        path.Warp(destPoints, srcRect);
        g.DrawPath(Pens.Black, path);
        g.DrawString("Warped", this.Font, Brushes.Black, rect, format);
        g.TranslateTransform(width, 0);
      }
    }
  }
}
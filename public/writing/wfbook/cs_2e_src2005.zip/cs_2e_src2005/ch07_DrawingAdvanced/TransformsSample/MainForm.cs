﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    private void scalingButton_Click(object sender, EventArgs e) {
      (new MatrixMarginsForm()).ShowDialog();
    }

    private void scalingFontsButton_Click(object sender, EventArgs e) {
      (new ScalingFontsForm()).ShowDialog();
    }

    private void rotationButton_Click(object sender, EventArgs e) {
      (new RotateForm()).ShowDialog();
    }

    private void translationButton_Click(object sender, EventArgs e) {
      (new TranslationForm()).ShowDialog();
    }

    private void shearingButton_Click(object sender, EventArgs e) {
      (new ShearingForm()).ShowDialog();
    }

    private void pathTransformsButton_Click(object sender, EventArgs e) {
      (new PathTranslationForm()).ShowDialog();
    }

    private void pathTranslationButton_Click(object sender, EventArgs e) {
      (new PathFlattenForm()).ShowDialog();
    }
  }
}
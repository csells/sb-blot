﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class TranslationForm : Form {
    public TranslationForm() {
      InitializeComponent();
    }

    private void TranslationForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;

      // Origin at (0, 0)
      DrawLabeledRect(g, "Translate(0, 0)");

      // Move origin to (150, 150)
      Matrix matrix = new Matrix();
      matrix.Translate(150, 150);
      g.Transform = matrix;
      DrawLabeledRect(g, "Translate(150, 150)");
    }

    private void DrawLabeledRect(Graphics g, string label) {
      // Always draw at (0, 0) and let the client
      // set the position using a transform
      RectangleF rect = new RectangleF(0, 0, 125, 125);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      g.FillRectangle(Brushes.White, rect);
      g.DrawRectangle(Pens.Black, rect.X, rect.Y, rect.Width, rect.Height);
      g.DrawString(label, this.Font, Brushes.Black, rect, format);
    }
  }
}
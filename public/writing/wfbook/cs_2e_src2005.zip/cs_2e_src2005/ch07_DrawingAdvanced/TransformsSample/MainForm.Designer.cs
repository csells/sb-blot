﻿namespace TransformsSample {
  partial class MainForm {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    protected override void Dispose(bool disposing) {
      if( disposing && (components != null) ) {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent() {
      this.scalingButton = new System.Windows.Forms.Button();
      this.scalingFontsButton = new System.Windows.Forms.Button();
      this.rotationButton = new System.Windows.Forms.Button();
      this.translationButton = new System.Windows.Forms.Button();
      this.shearingButton = new System.Windows.Forms.Button();
      this.pathTranslationButton = new System.Windows.Forms.Button();
      this.pathTransformsButton = new System.Windows.Forms.Button();
      this.SuspendLayout();
      // 
      // scalingButton
      // 
      this.scalingButton.Location = new System.Drawing.Point(13, 13);
      this.scalingButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.scalingButton.Name = "scalingButton";
      this.scalingButton.Size = new System.Drawing.Size(198, 23);
      this.scalingButton.TabIndex = 0;
      this.scalingButton.Text = "Scaling";
      this.scalingButton.Click += new System.EventHandler(this.scalingButton_Click);
      // 
      // scalingFontsButton
      // 
      this.scalingFontsButton.Location = new System.Drawing.Point(13, 40);
      this.scalingFontsButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.scalingFontsButton.Name = "scalingFontsButton";
      this.scalingFontsButton.Size = new System.Drawing.Size(198, 23);
      this.scalingFontsButton.TabIndex = 1;
      this.scalingFontsButton.Text = "ScalingFonts";
      this.scalingFontsButton.Click += new System.EventHandler(this.scalingFontsButton_Click);
      // 
      // rotationButton
      // 
      this.rotationButton.Location = new System.Drawing.Point(13, 67);
      this.rotationButton.Margin = new System.Windows.Forms.Padding(3, 3, 3, 1);
      this.rotationButton.Name = "rotationButton";
      this.rotationButton.Size = new System.Drawing.Size(198, 23);
      this.rotationButton.TabIndex = 2;
      this.rotationButton.Text = "Rotation";
      this.rotationButton.Click += new System.EventHandler(this.rotationButton_Click);
      // 
      // translationButton
      // 
      this.translationButton.Location = new System.Drawing.Point(13, 94);
      this.translationButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.translationButton.Name = "translationButton";
      this.translationButton.Size = new System.Drawing.Size(198, 23);
      this.translationButton.TabIndex = 3;
      this.translationButton.Text = "Translation";
      this.translationButton.Click += new System.EventHandler(this.translationButton_Click);
      // 
      // shearingButton
      // 
      this.shearingButton.Location = new System.Drawing.Point(13, 121);
      this.shearingButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 3);
      this.shearingButton.Name = "shearingButton";
      this.shearingButton.Size = new System.Drawing.Size(198, 23);
      this.shearingButton.TabIndex = 4;
      this.shearingButton.Text = "Shearing";
      this.shearingButton.Click += new System.EventHandler(this.shearingButton_Click);
      // 
      // pathTranslationButton
      // 
      this.pathTranslationButton.Location = new System.Drawing.Point(13, 175);
      this.pathTranslationButton.Margin = new System.Windows.Forms.Padding(3, 0, 3, 2);
      this.pathTranslationButton.Name = "pathTranslationButton";
      this.pathTranslationButton.Size = new System.Drawing.Size(198, 23);
      this.pathTranslationButton.TabIndex = 5;
      this.pathTranslationButton.Text = "Path Translation";
      this.pathTranslationButton.Click += new System.EventHandler(this.pathTranslationButton_Click);
      // 
      // pathTransformsButton
      // 
      this.pathTransformsButton.Location = new System.Drawing.Point(13, 148);
      this.pathTransformsButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 3);
      this.pathTransformsButton.Name = "pathTransformsButton";
      this.pathTransformsButton.Size = new System.Drawing.Size(198, 23);
      this.pathTransformsButton.TabIndex = 6;
      this.pathTransformsButton.Text = "Path Transforms";
      this.pathTransformsButton.Click += new System.EventHandler(this.pathTransformsButton_Click);
      // 
      // MainForm
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(223, 214);
      this.Controls.Add(this.pathTransformsButton);
      this.Controls.Add(this.pathTranslationButton);
      this.Controls.Add(this.shearingButton);
      this.Controls.Add(this.translationButton);
      this.Controls.Add(this.rotationButton);
      this.Controls.Add(this.scalingFontsButton);
      this.Controls.Add(this.scalingButton);
      this.Name = "MainForm";
      this.Text = "Transforms Sample";
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.Button scalingButton;
    private System.Windows.Forms.Button scalingFontsButton;
    private System.Windows.Forms.Button rotationButton;
    private System.Windows.Forms.Button translationButton;
    private System.Windows.Forms.Button shearingButton;
    private System.Windows.Forms.Button pathTranslationButton;
    private System.Windows.Forms.Button pathTransformsButton;
  }
}


﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class ScalingFontsForm : Form {
    public ScalingFontsForm() {
      InitializeComponent();
    }

    private void ScalingFontsForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      int x = 0;
      int y = 0;
      int width = this.ClientRectangle.Width / 4;
      int height = this.ClientRectangle.Height;
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;

      Matrix matrix = new Matrix();

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(1, 1);
      g.Transform = matrix;
      g.DrawString("Scale(1, 1)", this.Font, Brushes.Black, new Rectangle(x, y, width, height), format);
      x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(1, 3);
      g.Transform = matrix;
      g.DrawString("Scale(1, 3)", this.Font, Brushes.Black, new RectangleF(x, y / 3f, width, height / 3f), format);
      x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      matrix.Scale(3, 1);
      g.Transform = matrix;
      g.DrawString("Scale(3, 1)", this.Font, Brushes.Black, new RectangleF(x / 3f, y, width / 3f, height), format);
      x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
      y = (x == 0 ? y + height : y);

      g.ResetTransform();
      g.DrawRectangle(Pens.Black, x, y, width, height);
      matrix.Reset();
      //matrix.Translate(width, height);
      matrix.Scale(-1, -1);
      g.Transform = matrix;
      g.DrawString("Scale(-1, -1)", this.Font, Brushes.Black,
        new RectangleF(-x - width, -y - height, width, height), format);
      //g.DrawString("Scale(-1, -1)", this.Font, Brushes.Black, new RectangleF(-x, -y, width, height), format);
      x = (x > this.ClientRectangle.Width - 2 * width ? 0 : x + width);
      y = (x == 0 ? y + height : y);
    }
  }
}
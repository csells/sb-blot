﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Text;
using System.Windows.Forms;

#endregion

namespace TransformsSample {
  partial class PathTranslationForm : Form {
    public PathTranslationForm() {
      InitializeComponent();
    }

    private void PathTranslationForm_Paint(object sender, PaintEventArgs e) {
      Graphics g = e.Graphics;
      using( GraphicsPath path = CreateLabeledRectPath("My Path") ) {

        // Draw at (0, 0)
        g.DrawPath(Pens.Black, path);

        // Translate all points in path by (150, 150)
        Matrix matrix = new Matrix();
        matrix.Translate(150, 150);
        path.Transform(matrix);
        g.DrawPath(Pens.Black, path);
      }
    }

    private GraphicsPath CreateLabeledRectPath(string label) {
      GraphicsPath path = new GraphicsPath();
      RectangleF rect = new RectangleF(0, 0, 125, 125);
      StringFormat format = new StringFormat();
      format.Alignment = StringAlignment.Center;
      format.LineAlignment = StringAlignment.Center;
      path.AddRectangle(rect);
      path.AddString(label, this.Font.FontFamily, (int)this.Font.Style, this.Font.Height, rect, format);
      return path;
    }
  }
}
﻿#region Using directives

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;

#endregion

namespace PageUnitsSample {
  partial class MainForm : Form {
    public MainForm() {
      InitializeComponent();
    }

    String s = "For example, it’s not important that the ruler at the top of the document I’m typing this sentence into is currently showing an inch as 1 9/16 inches. What is important is the proportion of the dimensions of each line in proportion to the units shown as “inches” as compared to the width and height of each line as I type. The principle of WYSIWYG (What You See Is What You Get) says that I should be able to print something very similar to what I’m seeing on the screen . When my word processing program shows a line wrapping at a certain word when I get close to the 6 ½ inches area inside of my margins (my page settings are set to standard 8 ½ inch wide paper with a 1 inch margin on each side), I want that same wrap to happen at the same word when I print. To make that happen, we need to be able to write a program that can wrap text at units other than pixels, as shown in Figure 1.";

    private void MainForm_Load(object sender, EventArgs e) {
      ShowClientSize();
    }

    private void MainForm_Paint(object sender, PaintEventArgs e) {
      ManuallyPaintInInches(e.Graphics);
      //PaintInInches(e.Graphics);
    }

    private void MainForm_Resize(object sender, EventArgs e) {
      ShowClientSize();
    }

    private float InchesToPixels(float inches) {
      using( Graphics g = this.CreateGraphics() ) {
        return inches * g.DpiY;
      }
    }

    private RectangleF InchesToPixels(RectangleF rect) {
      return new RectangleF(InchesToPixels(rect.X), InchesToPixels(rect.Y), InchesToPixels(rect.Width), InchesToPixels(rect.Height));
    }

    private float PixelsToInches(float pixels) {
      using( Graphics g = this.CreateGraphics() ) {
        return pixels / g.DpiX;
      }
    }

    private void ManuallyPaintInInches(Graphics g) {
      using( Font rulerFont = new Font("MS Sans Serif", 8.25f) ) {
        int pixelsPerInch = 72;
        // Inches
        float rulerFontHeight = rulerFont.SizeInPoints / pixelsPerInch;

        // Specifiy units in inches
        RectangleF rulerRect =
          new RectangleF(
          0, 0,
          6.5f, rulerFontHeight * 1.5f);
        // Draw in pixels
        g.DrawRectangle(
          Pens.Black,
          InchesToPixels(rulerRect.X), InchesToPixels(rulerRect.Y),
          InchesToPixels(rulerRect.Width), InchesToPixels(rulerRect.Height));

        // Draw 6.5 inches in inches
        for( float i = 1; i <= 6; ++i ) {
          // Specify units in inches
          RectangleF rect = new RectangleF(i - rulerFontHeight, 0, rulerFontHeight * 2, rulerFontHeight);
          StringFormat format = new StringFormat();
          format.Alignment = StringAlignment.Center;
          g.DrawString(i.ToString(), rulerFont, Brushes.Black, InchesToPixels(rect), format);
          //g.DrawLine(Pens.Black, InchesToPixels(i), 0, InchesToPixels(i), InchesToPixels(rulerFontHeight/2));
        }

        // Draw 6.5 inches in half inches
        for( float i = 0.5f; i <= 6.5f; i += 1.0f ) {
          g.DrawLine(Pens.Black, InchesToPixels(i), 0, InchesToPixels(i), InchesToPixels(rulerFontHeight / 2));
        }

        using( Font textFont = new Font("Times New Roman", 11) ) {
          // Draw text wrapped to 6.5 inch margin
          RectangleF textRect = new RectangleF(0, rulerRect.Height, 6.5f, PixelsToInches(this.ClientRectangle.Height) - rulerRect.Height);
          g.FillRectangle(Brushes.White, InchesToPixels(textRect));
          g.DrawRectangle(Pens.Black, InchesToPixels(textRect.X), InchesToPixels(textRect.Y), InchesToPixels(textRect.Width), InchesToPixels(textRect.Height));
          g.DrawString(s, textFont, Brushes.Black, InchesToPixels(textRect));
        }
      }

    }

    private void PaintInInches(Graphics g) {
      // Set page units and scale
      g.PageUnit = GraphicsUnit.Inch;
      g.PageScale = 1; // 1 unit is 1 inch

      using( Font rulerFont = new Font("MS Sans Serif", 8.25f) )
      using( Pen blackPen = new Pen(Color.Black, 0) ) {
        float rulerFontHeight = rulerFont.GetHeight(g); // Inches
        // Specifiy units in inches
        RectangleF rulerRect =
          new RectangleF(
          0, 0,
          6.5f, rulerFontHeight * 1.5f);
        // Draw in inches
        g.DrawRectangle(
          blackPen,
          rulerRect.X, rulerRect.Y,
          rulerRect.Width, rulerRect.Height);

        // Draw 6.5 inches in inches
        for( float i = 1; i <= 6; ++i ) {
          // Specify units in inches
          RectangleF rect = new RectangleF(i - rulerFontHeight, 0, rulerFontHeight * 2, rulerFontHeight);
          StringFormat format = new StringFormat();
          format.Alignment = StringAlignment.Center;
          g.DrawString(i.ToString(), rulerFont, Brushes.Black, rect, format);
          //g.DrawLine(blackPen, i, 0, i, rulerFontHeight/2);
        }

        // Draw 6.5 inches in half inches
        for( float i = 0.5f; i <= 6.5f; i += 1.0f ) {
          g.DrawLine(blackPen, i, 0, i, rulerFontHeight / 2);
        }

        using( Font textFont = new Font("Times New Roman", 11) ) {
          // Draw text wrapped to 6.5 inch margin
          RectangleF textRect = new RectangleF(0, rulerRect.Height, 6.5f, PixelsToInches(this.ClientRectangle.Height) - rulerRect.Height);
          g.FillRectangle(Brushes.White, textRect);
          g.DrawRectangle(blackPen, textRect.X, textRect.Y, textRect.Width, textRect.Height);
          g.DrawString(s, textFont, Brushes.Black, textRect);
        }
      }
    }

    private void ShowClientSize() {
      using( Graphics g = this.CreateGraphics() ) {
        // Set page unit to inches
        g.PageUnit = GraphicsUnit.Inch;
        g.PageScale = 1;
        PointF[] bottomRight =
          new PointF[] { new PointF(this.ClientSize.Width, this.ClientSize.Height) };
        // Convert client size from pixels to inches
        g.TransformPoints(
          CoordinateSpace.Page, CoordinateSpace.Device, bottomRight);
        this.toolStripStatusLabel1.Text = string.Format("ClientSize= {0}x{1} pixels ({2}x{3} inches)", this.ClientSize.Width, this.ClientSize.Height, bottomRight[0].X, bottomRight[0].Y);
      }
    }
  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace CommandHandling
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>


    // Example 4-25. Handling a command

    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            CommandBinding cmdBindingNew = new CommandBinding(ApplicationCommands.New);
            cmdBindingNew.Executed += NewCommandHandler;
            CommandBindings.Add(cmdBindingNew);
        }

        void NewCommandHandler(object sender, ExecutedRoutedEventArgs e)
        {
            if (unsavedChanges)
            {
                MessageBoxResult result = MessageBox.Show(this,
                    "Save changes to existing document?", "New",
                    MessageBoxButton.YesNoCancel);

                if (result == MessageBoxResult.Cancel)
                {
                    return;
                }
                if (result == MessageBoxResult.Yes)
                {
                    SaveChanges();
                }
            }

            // Reset text box contents
            inputBox.Clear();
        }

        // End of Example 4-25.

        bool unsavedChanges = false;

        private void OnTextboxTextChanged(object sender, RoutedEventArgs e)
        {
            unsavedChanges = true;
        }

        private void SaveChanges()
        {
            unsavedChanges = false;
        }

    }
}
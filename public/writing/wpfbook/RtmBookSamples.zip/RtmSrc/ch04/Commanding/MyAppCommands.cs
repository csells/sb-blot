// Example 4-17. Creating a custom command

using System.Windows.Input;

namespace MyNamespace
{
    public class MyAppCommands
    {
        public static RoutedUICommand AddToBasketCommand;

        static MyAppCommands()
        {
            InputGestureCollection addToBasketInputs = new InputGestureCollection();
            addToBasketInputs.Add(new KeyGesture(
                Key.B, ModifierKeys.Control | ModifierKeys.Shift));
            AddToBasketCommand = new RoutedUICommand(
                "Add to Basket", "AddToBasket",
                typeof(MyAppCommands), addToBasketInputs);
        }
    }
}

// End of Example 4-17.
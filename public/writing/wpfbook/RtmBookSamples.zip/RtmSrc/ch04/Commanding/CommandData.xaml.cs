using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Commanding
{
    /// <summary>
    /// Interaction logic for CommandData.xaml
    /// </summary>

    public partial class CommandData : System.Windows.Window
    {

        public CommandData()
        {
            InitializeComponent();
        }


        // Example 4-24. Commands and data

        void AddToBasketHandler(object sender, ExecutedRoutedEventArgs e)
        {
            FrameworkElement source = (FrameworkElement) e.Source;
            ProductInfo product = (ProductInfo) source.DataContext;
        }

        // End of Example 4-24.

    }
}
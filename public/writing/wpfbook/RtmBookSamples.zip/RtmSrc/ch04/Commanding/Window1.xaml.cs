using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MyNamespace;


namespace Commanding
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {
        // Example 4-23. Associating a command parameter with a shortcut

        public Window1()
        {
            InitializeComponent();

            KeyBinding kb = new KeyBinding(MyAppCommands.AddToBasketCommand, Key.B,
                                    ModifierKeys.Shift | ModifierKeys.Control);
            kb.CommandParameter = "productId4299";
            this.InputBindings.Add(kb);
        }

        // End of Example 4-23.


        // Example 4-22. Retrieving a command parameter

        void AddToBasketHandler(object sender, ExecutedRoutedEventArgs e)
        {
            string productId = (string) e.Parameter;
        }

        // End of Example 4-22.

    }
}
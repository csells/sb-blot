using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;


namespace MouseInput
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {
        // Example 4-10. Mouse capture

        public Window1()
        {
            InitializeComponent();

            myEllipse.MouseDown += myEllipse_MouseDown;
            myEllipse.MouseMove += myEllipse_MouseMove;
            myEllipse.MouseUp += myEllipse_MouseUp;
        }

        void myEllipse_MouseDown(object sender, MouseButtonEventArgs e)
        {
            Mouse.Capture(myEllipse);
        }

        void myEllipse_MouseUp(object sender, MouseButtonEventArgs e)
        {
            Mouse.Capture(null);
        }

        void myEllipse_MouseMove(object sender, MouseEventArgs e)
        {
            Debug.WriteLine(Mouse.GetPosition(myEllipse));
        }

        // End of Example 4-10.


        protected override void OnMouseMove(MouseEventArgs e)
        {
            base.OnMouseMove(e);


            // Example 4-9. Retrieving the mouse position

            Point positionRelativeToEllipse = Mouse.GetPosition(myEllipse);

            // End of Example 4-9.


            Debug.WriteLine("Window.MouseMove: " + positionRelativeToEllipse);
        }


        // Example 4-11. Temporary mouse cursor override

        private void StartSlowWork()
        {
            Mouse.OverrideCursor = Cursors.AppStarting;
        }

        private void SlowWorkCompleted()
        {
            Mouse.OverrideCursor = null;
        }

        // End of Example 4-11.

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);
            if (e.Source != myEllipse)
            {
                StartSlowWork();
            }
        }

        protected override void OnMouseUp(MouseButtonEventArgs e)
        {
            base.OnMouseUp(e);
            SlowWorkCompleted();
        }

    }
}
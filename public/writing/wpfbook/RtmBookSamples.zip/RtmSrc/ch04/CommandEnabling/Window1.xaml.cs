using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace CommandEnabling
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {
        // Example 4-26. Handling QueryEnabled

        public Window1()
        {
            InitializeComponent();

            CommandBinding redoCommandBinding =
                new CommandBinding(ApplicationCommands.Redo);
            redoCommandBinding.CanExecute += RedoCommandCanExecute;
            CommandBindings.Add(redoCommandBinding);
        }

        void RedoCommandCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = myCustomUndoManager.CanRedo;
        }

        // End of Example 4-26.


        private class MockUndoManager
        {
            public bool CanRedo
            {
                get
                {
                    return DateTime.Now.Second % 4 > 1;
                }
            }
        }
        MockUndoManager myCustomUndoManager = new MockUndoManager();
    }
}
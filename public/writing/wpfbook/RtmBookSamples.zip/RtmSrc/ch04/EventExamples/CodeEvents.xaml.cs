using System;
using System.Windows;
using System.Diagnostics;

namespace EventExamples
{
    /// <summary>
    /// Interaction logic for CodeEvents.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {

        // Example 4-4. Attaching event handlers in code

        public Window1()
        {
            InitializeComponent();

            myEllipse.MouseDown += MouseDownEllipse;
            myEllipse.PreviewMouseDown += PreviewMouseDownEllipse;
        }

        // End of Example 4-4.

        void PreviewMouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownButton"); }

        void MouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownButton"); }


        void PreviewMouseDownGrid(
          object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownGrid"); }

        void MouseDownGrid(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownGrid"); }


        void PreviewMouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownCanvas"); }

        void MouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownCanvas"); }


        void PreviewMouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownEllipse"); }

        void MouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownEllipse"); }
    }
}
using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace EventExamples
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            HaltingEvents h = new HaltingEvents();
            h.Show();

            // Note: there's more than 1 Window1, in order to
            // get all the examples in this one project...
            // They're in different namespaces. The default
            // Window1 opened for us is in the EventRouting namespace.
            // This next one's in the EventExamples namespace.

            Window1 w1 = new Window1();
            w1.Show();

            EventExamples2.Window1 w1x = new EventExamples2.Window1();
            w1x.Show();
        }
    }
}
using System;
using System.Windows;
using System.Diagnostics;
using System.Windows.Shapes;
using System.Windows.Input;

namespace EventExamples2
{
    /// <summary>
    /// Interaction logic for AddHandler.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {

        // Example 4-5. Attaching event handlers the long-winded way

        public Window1()
        {
            InitializeComponent();

            myEllipse.AddHandler(Ellipse.MouseDownEvent,
                new MouseButtonEventHandler(MouseDownEllipse));
            myEllipse.AddHandler(Ellipse.PreviewMouseDownEvent,
                new MouseButtonEventHandler(PreviewMouseDownEllipse));
        }

        // End of Example 4-5.
        
        
        void PreviewMouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownButton"); }

        void MouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownButton"); }


        void PreviewMouseDownGrid(
          object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownGrid"); }

        void MouseDownGrid(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownGrid"); }


        void PreviewMouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownCanvas"); }

        void MouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownCanvas"); }


        void PreviewMouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownEllipse"); }

        void MouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownEllipse"); }
    }
}
using System;
using System.Windows;
using System.Diagnostics;
using System.Windows.Shapes;
using System.Windows.Input;

namespace EventExamples
{
    /// <summary>
    /// Interaction logic for AttachedEvents.xaml
    /// </summary>

    public partial class AttachedEvents : System.Windows.Window
    {

        public AttachedEvents()
        {
            InitializeComponent();

            if (DateTime.Now.Hour > 12)
            {

                // Example 4-7. Explicit attached event handling

                myEllipse.AddHandler(Mouse.PreviewMouseDownEvent,
                    new MouseButtonEventHandler(PreviewMouseDownEllipse));
                myEllipse.AddHandler(Mouse.MouseDownEvent,
                    new MouseButtonEventHandler(MouseDownEllipse));

                // End of Example 4-7.
            }
            else
            {
                // Example 4-8. Attached event handling with helper function

                Mouse.AddPreviewMouseDownHandler(myEllipse, PreviewMouseDownEllipse);
                Mouse.AddMouseDownHandler(myEllipse, MouseDownEllipse);

                // End of Example 4-8.
            }

        }
        void PreviewMouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownButton"); }

        void MouseDownButton(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownButton"); }


        void PreviewMouseDownGrid(
          object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownGrid"); }

        void MouseDownGrid(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownGrid"); }


        void PreviewMouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownCanvas"); }

        void MouseDownCanvas(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownCanvas"); }


        void PreviewMouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("PreviewMouseDownEllipse"); }

        void MouseDownEllipse(object sender, RoutedEventArgs e)
        { Debug.WriteLine("MouseDownEllipse"); }

    }
}
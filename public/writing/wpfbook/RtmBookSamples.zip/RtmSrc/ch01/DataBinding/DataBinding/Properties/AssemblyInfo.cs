#region Using directives

using System.Reflection;
using System.Runtime.CompilerServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("DataBinding")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft, Corp.")]
[assembly: AssemblyProduct("DataBinding")]
[assembly: AssemblyCopyright("Copyright @ Microsoft, Corp. 2005")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

//In order to begin building localizable applications, set <UICulture>CultureYouAreCodingWith</UICulture> in your
//.csproj file inside a <PropertyGroup>.  For example, if you are using US english in your source files, set the
//<UICulture> to en-US.  Then uncomment the NeutralResourceLanguage attribute below.
//Update the "en-US" in the line below to match the UICulture setting in the project file.
//[assembly: NeutralResourcesLanguage("en-US", UltimateFallbackResourceLocation.Satellite)]


// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.*")]

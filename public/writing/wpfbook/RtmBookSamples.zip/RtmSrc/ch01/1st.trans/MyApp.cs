// MyApp.cs
using System;
using System.Windows;

namespace MyFirstWpfApp {
  class MyApp : Application {
    [STAThread]
    static void Main(string[] args) {
      MyApp app = new MyApp();
      app.StartingUp += app.AppStartingUp;
      app.Run(args);
    }

    void AppStartingUp(object sender, StartingUpCancelEventArgs e) {
      // Let the Window1 initialize itself
      Window window = new Window1();
      window.Show();
    }
  }
}

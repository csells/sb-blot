Avalon Express Application Readme
----------------------------------
Express Applications run in a sandbox with "Internet Permissions".
As such, certain Avalon features, such as launching new windows and the flow document
element, need permissions not granted in the sandbox. 
Please check the SDK for more specifics.

Avalon Item Templates - which work in the sandbox?
--------------------------------------------------------
Work Today - Avalon Page, Avalon Page Function, Avalon Custom Control.
Will work by V1 - Avalon Flow Document (which needs DocumentViewer to display)
Won't work by design - Avalon Window - In the internet zone, you don't have the permission to "popup" new windows.

Debugging Express Applications - (F5)
--------------------------------------------------------
In order to successfully debug an Express Application in Visual Studio, you must enable unmanaged code debugging
via the Debug page in the Properties view.  Developers using Visual C# and Visual Basic Express do not need to
do this.

The first time that this project is debugged, a dialog may appear stating that there 
is no debug information available for PresentationHost.exe.  This dialog can be
safely dismissed.

using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Threading;
using System.Reflection;

namespace SingleInstanceSample {
  public partial class App : System.Windows.Application {
    Mutex mutex;
    protected override void OnStartup(StartupEventArgs e) {
      base.OnStartup(e);

      // Check for existing instance
      string mutexName = "MyCompanyName.MyAppName";
      bool createdNew;
      mutex = new Mutex(true, mutexName, out createdNew);

      // If there is an existing instance, shutdown this one
      if( !createdNew ) { Shutdown(); }

      // For something better (although interesting to integrate w/ WPF),
      // see the "Single Instance Detection" sample in the Windows Platform SDK.
      // http://msdn2.microsoft.com/en-us/library/ms771662.aspx
    }
  }
}
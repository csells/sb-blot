using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace AppEventsSample {
  public partial class Window1 : System.Windows.Window {

    public Window1() {
      InitializeComponent();
      this.DataContext = ((App)Application.Current).EventLog;
    }

    protected override void OnInitialized(EventArgs e) {
      base.OnInitialized(e);

      exceptionButton.Click += new RoutedEventHandler(exceptionButton_Click);
      shutdownButton.Click += new RoutedEventHandler(shutdownButton_Click);
    }

    void exceptionButton_Click(object sender, RoutedEventArgs e) {
      throw new Exception("Opps! Unhandled exception!");
    }

    void shutdownButton_Click(object sender, RoutedEventArgs e) {
      Application.Current.Shutdown(452);
    }

  }
}
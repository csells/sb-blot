using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Diagnostics;
using System.Collections.ObjectModel;
using System.Text;
using System.IO;
using System.Collections.Specialized;
using System.Windows.Threading;

namespace AppEventsSample {
  public partial class App : Application {
    public readonly ObservableCollection<string> EventLog = new ObservableCollection<string>();

    public App() {
      this.Activated += new EventHandler(App_Activated);
      this.Deactivated += new EventHandler(App_Deactivated);
      this.DispatcherUnhandledException += new System.Windows.Threading.DispatcherUnhandledExceptionEventHandler(App_DispatcherUnhandledException);
      this.Exit += new ExitEventHandler(App_Exit);
      this.SessionEnding += new SessionEndingCancelEventHandler(App_SessionEnding);
      this.Startup += new StartupEventHandler(App_Startup);

      File.Delete(@"c:\appeventlog.txt");
      EventLog.CollectionChanged += EventLog_CollectionChanged;
      EventLog.Add("App()");
    }

    void EventLog_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e) {
      using (StreamWriter writer = new StreamWriter(@"c:\appeventlog.txt", true)) {
        foreach (string item in e.NewItems) { writer.WriteLine(item); }
      }
    }

    void App_Startup(object sender, StartupEventArgs e) {
      StringBuilder args = new StringBuilder();
      for (int i = 0; i != e.Args.Length; ++i) {
        args.AppendFormat("arg[{0}]: '{1}' ", i, e.Args[i]);
      }

      EventLog.Add("App_Startup: args= " + args);
    }

    void App_SessionEnding(object sender, SessionEndingCancelEventArgs e) {
      EventLog.Add("App_SessionEnding: reason= " + e.ReasonSessionEnding.ToString());

      if (MessageBox.Show(e.ReasonSessionEnding.ToString(), "Session Ending", MessageBoxButton.OKCancel) == MessageBoxResult.Cancel) {
        e.Cancel = true;
      }
    }

    void App_Exit(object sender, ExitEventArgs e) {
      EventLog.Add("App_Exit: exit code=" + e.ApplicationExitCode.ToString());
    }

    void App_DispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e) {
      EventLog.Add("App_DispatcherUnhandledException: " + e.Exception.Message);

      if (MessageBox.Show("Is exception handled?\r\n" + e.Exception.Message, "Exception", MessageBoxButton.YesNo) == MessageBoxResult.Yes) {
        e.Handled = true;
      }
    }

    void App_Activated(object sender, EventArgs e) {
      EventLog.Add("App_Activated");
    }

    void App_Deactivated(object sender, EventArgs e) {
      EventLog.Add("App_Deactivated");
    }

  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using System.Diagnostics;
using System.ComponentModel;


namespace AppWindowsSample {
  public partial class Window1 : System.Windows.Window {

    public Window1() {
      InitializeComponent();

      DataContext = Application.Current.Windows;
      statusText.Text = Application.Current.ShutdownMode.ToString();

      newWindowButton.Click += new RoutedEventHandler(newWindowButton_Click);
      shutdownButton.Click += new RoutedEventHandler(shutdownButton_Click);
      windowMenu.SubmenuOpened += new RoutedEventHandler(windowMenu_SubmenuOpened);
      Closing += Window1_Closing;
    }

    void windowMenu_SubmenuOpened(object sender, RoutedEventArgs e) {
      windowMenu.Items.Clear();
      foreach( Window window in Application.Current.Windows ) {
        MenuItem item = new MenuItem();
        item.Header = window.Title;
        item.Click += windowMenuItem_Click;
        item.Tag = window;
        item.IsChecked = window.IsActive;
        windowMenu.Items.Add(item);
      }
    }

    void windowMenuItem_Click(object sender, RoutedEventArgs e) {
      Window window = (Window)((MenuItem)sender).Tag;
      window.Activate();
    }

    int windowNo = 1;

    void newWindowButton_Click(object sender, RoutedEventArgs e) {
      ++windowNo;
      Window window = new Window();
      window.Title = "Window " + windowNo.ToString();
      window.Width = 200;
      window.Height = 100;
      window.Show();
      statusText.Text = Application.Current.ShutdownMode.ToString();
    }

    void shutdownButton_Click(object sender, RoutedEventArgs e) {
      Application.Current.Shutdown();
    }

    void Window1_Closing(object sender, CancelEventArgs e) {
      if( MessageBox.Show("Do you really want to shut down?", "Shutting Down", MessageBoxButton.YesNo) == MessageBoxResult.No ) {
        e.Cancel = true;
      }
    }


  }
}
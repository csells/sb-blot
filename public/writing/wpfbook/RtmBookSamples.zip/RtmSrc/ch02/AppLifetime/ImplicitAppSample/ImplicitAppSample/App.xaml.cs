// App.xaml.cs
using System;
using System.Windows;

namespace ImplicitAppSample {
  public partial class App : System.Windows.Application {
    protected override void OnStartup(StartupEventArgs e) {
      // let the base class have a crack
      base.OnStartup(e);

      // WPF itself is providing the Main that creates an
      // Application and calls the Run method; all we have
      // to do is create a window and show it
      Window1 window = new Window1();
      window.Show();
    }
  }
}
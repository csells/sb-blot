using System;
using System.Windows; // the home of the Application class

namespace ExplicitAppSample {
  class Program {
    [STAThread]
    static void Main() {
      Application app = new System.Windows.Application();
      Window1 window = new Window1();
      window.Show();
      Application.Current.Run(); // same as app.Run()
    }
  }
}

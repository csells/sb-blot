#region Using directives

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Resources;
using System.Globalization;
using System.Windows;
using System.Runtime.InteropServices;

#endregion

[assembly: AssemblyTitle("ResourcesExample")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("ResourcesExample")]
[assembly: AssemblyCopyright("Copyright @  2007")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]


// Example 12-10. Declaring custom system-scope resources.

[assembly: ThemeInfo(
  ResourceDictionaryLocation.None,           // Theme-specific resources
  ResourceDictionaryLocation.SourceAssembly  // Generic resources
)]

// End of Example 12-10.


[assembly: AssemblyVersion("1.0.*")]

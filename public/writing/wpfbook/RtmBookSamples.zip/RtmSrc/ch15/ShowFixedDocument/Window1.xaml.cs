using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Xps.Packaging;
using System.IO;


namespace ShowFixedDocument
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {

        public Window1()
        {
            InitializeComponent();

            // Example 15-40. Loading an XPS document into a DocumentViewer

            string docPath = Environment.GetCommandLineArgs()[1];
            XpsDocument doc = new XpsDocument(docPath, FileAccess.Read);
            viewer.Document = doc.GetFixedDocumentSequence();

            // End of Example 15-40.

        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Diagnostics;


namespace ReadXpsDoc
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {

        public Window1()
        {
            InitializeComponent();
        }

        private void ReadDoc()
        {
            // Example 15-4. Extracing FixedDocument objects from an XPS file

            FixedDocumentSequence fds;
            using (XpsDocument xpsDocumentFile = new XpsDocument("MyXpsDoc.xps",
                                                                 FileAccess.Read))
            {
                fds = xpsDocumentFile.GetFixedDocumentSequence();
            }

            foreach (DocumentReference docRef in fds.References)
            {
                FixedDocument document = docRef.GetDocument(false);

                Debug.WriteLine("Pages: " + document.Pages.Count);
            }

            // End of Example 15-4.
        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Printing;
using System.Windows.Documents.Serialization;
using System.Windows.Xps;

namespace CreateXpsDoc
{
    /// <summary>
    /// Interaction logic for Window2.xaml
    /// </summary>

    public partial class Window2 : System.Windows.Window
    {

        public Window2()
        {
            InitializeComponent();
        }

        // Example 15-22. Asynchronous printing

        void PrintPaginatedDocument(IDocumentPaginatorSource dps)
        {
            PrintDocumentImageableArea area = null;
            XpsDocumentWriter xpsdw = PrintQueue.CreateXpsDocumentWriter(ref area);
            xpsdw.WritingCompleted += OnPrinted;
            if (xpsdw != null)
            {
                xpsdw.WriteAsync(dps.DocumentPaginator);
            }
        }

        void OnPrinted(object sender, WritingCompletedEventArgs e)
        {
            MessageBox.Show("Printing completed!");
        }

        // End of Example 15-22.

    }
}
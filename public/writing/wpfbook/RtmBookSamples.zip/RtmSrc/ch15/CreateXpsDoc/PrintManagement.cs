using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Xps;
using System.Printing;
using System.IO;
using System.Xml;
using System.Windows.Controls;

namespace CreateXpsDoc
{
    class PrintManagement
    {
        public static XpsDocumentWriter GetWriterForLocalQueue()
        {
            // Example 15-33. Creating a document write with a specific PrintQueue

            LocalPrintServer local = new LocalPrintServer();
            PrintQueue pq = local.DefaultPrintQueue;

            XpsDocumentWriter xpsdw = PrintQueue.CreateXpsDocumentWriter(pq);

            // End of Example 15-33.

            return xpsdw;
        }

        // Example 15-34. Examining print capabilities

        public static void ShowCapabilities(PrintQueue pq)
        {
            PrintCapabilities caps = pq.GetPrintCapabilities();
            foreach (Duplexing duplexType in caps.DuplexingCapability)
            {
                Console.WriteLine(duplexType);
            }
        }

        // Example 15-34

        public static void ShowXmlCapabilities(PrintQueue pq)
        {
            // Example 15-36. Working with print capabilities in XML form

            Stream capsStream = pq.GetPrintCapabilitiesAsXml();
            XmlDocument capsDoc = new XmlDocument();
            capsDoc.Load(capsStream);

            XmlNamespaceManager nsm = new XmlNamespaceManager(capsDoc.NameTable);
            nsm.AddNamespace("psf",
              "http://schemas.microsoft.com/windows/2003/08/printing/printschemaframework");

            XmlNodeList features = capsDoc.SelectNodes("//psf:Feature", nsm);
            foreach (XmlElement feature in features)
            {
                XmlNode featureName = feature.SelectSingleNode(
                    "psf:Property[@name='psk:DisplayName']/psf:Value/text()", nsm);
                Console.WriteLine("Feature: " + featureName.Value);

                XmlNodeList options = feature.SelectNodes("psf:Option", nsm);
                foreach (XmlElement option in options)
                {
                    XmlNode optionName = option.SelectSingleNode(
                        "psf:Property[@name='psk:DisplayName']/psf:Value/text()", nsm);
                    if (optionName != null)
                    {
                        Console.WriteLine(" option: " + optionName.Value);
                    }
                }
            }

            // End of Example 15-36.
        }


        // Example 15-38. Using PrintDialog

        public static PrintQueue ShowDialogWithPageRange()
        {
            PrintDialog pd = new PrintDialog();
            pd.MinPage = 1;
            pd.MaxPage = 20;
            pd.UserPageRangeEnabled = true;
            pd.PageRangeSelection = PageRangeSelection.UserPages;
            pd.PageRange = new PageRange(4, 8);

            if (pd.ShowDialog() == true)
            {
                PrintQueue pq = pd.PrintQueue;
                PrintTicket pt = pd.PrintTicket;

                return pq;
            }

            return null;
        }

        // End of Example 15-38.
    }
}

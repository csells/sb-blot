using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Documents;
using System.Windows.Controls;
using System.Windows.Markup;

namespace CreateXpsDoc
{
    class HyperlinkedDoc
    {
        // Example 15-28. Using hyperlinks: creating the document

        public static FixedDocument MakeDocWithToc()
        {
            FixedDocument doc = new FixedDocument();

            FixedPage tocPage = new FixedPage();
            TextBlock tableOfContents = new TextBlock();
            tocPage.Children.Add(tableOfContents);

            PageContent pc = new PageContent();
            ((IAddChild) pc).AddChild(tocPage);
            doc.Pages.Add(pc);

            for (int pageNumber = 1; pageNumber <= 10; ++pageNumber)
            {
                pc = MakePage(pageNumber);
                doc.Pages.Add(pc);

                Hyperlink link = MakeLink(pageNumber);
                tableOfContents.Inlines.Add(link);
                tableOfContents.Inlines.Add(new LineBreak());
            }
            return doc;
        }

        // End of Example 15-28.


        // Example 15-29. Using hyperlinks: creating pages with targets

        static PageContent MakePage(int pageNumber)
        {
            PageContent pc;

            string fragmentId = "Page" + pageNumber;

            TextBlock tb = new TextBlock();
            tb.Text = "This is page " + pageNumber;
            tb.Name = fragmentId;

            FixedPage page = new FixedPage();
            page.Children.Add(tb);
            pc = new PageContent();
            ((IAddChild) pc).AddChild(page);

            LinkTarget lt = new LinkTarget();
            lt.Name = tb.Name;
            pc.LinkTargets.Add(lt);
            return pc;
        }

        // End of Example 15-29


        // Example 15-30. Using hyperlinks: creating the Hyperlink

        static Hyperlink MakeLink(int pageNumber)
        {
            string fragmentId = "Page" + pageNumber;

            Run linkText = new Run("Go to page " + pageNumber);
            Uri linkTarget = new Uri("#" + fragmentId, UriKind.Relative);

            Hyperlink link = new Hyperlink(linkText);
            link.NavigateUri = linkTarget;

            return link;
        }

        // End of Example 15-30.

    }
}

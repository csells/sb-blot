using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace Example_3_12
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    public partial class Window1 : System.Windows.Window
    {

        public Window1()
        {
            InitializeComponent();


            // Example 3-12. Setting row heights in code

            Grid g = new Grid();
            RowDefinition r = new RowDefinition();
            r.Height = new GridLength(0, GridUnitType.Auto);
            g.RowDefinitions.Add(r);
            r = new RowDefinition();
            r.Height = new GridLength(2, GridUnitType.Star);
            g.RowDefinitions.Add(r);
            r = new RowDefinition();
            r.Height = new GridLength(1, GridUnitType.Star);
            g.RowDefinitions.Add(r);

            // End of Example 3-12.


            ColumnDefinition c = new ColumnDefinition();
            c.Width = new GridLength(0, GridUnitType.Auto);
            g.ColumnDefinitions.Add(c);
            c = new ColumnDefinition();
            g.ColumnDefinitions.Add(c);

            TextBlock tb = new TextBlock();
            tb.Text = "Protocol:";
            Grid.SetColumn(tb, 0);
            Grid.SetRow(tb, 0);
            g.Children.Add(tb);

            tb = new TextBlock();
            tb.Text = "HyperText Transfer Protocol:";
            Grid.SetColumn(tb, 1);
            Grid.SetRow(tb, 0);
            g.Children.Add(tb);

            tb = new TextBlock();
            tb.Text = "Type:";
            Grid.SetColumn(tb, 0);
            Grid.SetRow(tb, 1);
            g.Children.Add(tb);

            tb = new TextBlock();
            tb.Text = "HTML Document";
            Grid.SetColumn(tb, 1);
            Grid.SetRow(tb, 1);
            g.Children.Add(tb);

            tb = new TextBlock();
            tb.Text = "Connection:";
            Grid.SetColumn(tb, 0);
            Grid.SetRow(tb, 2);
            g.Children.Add(tb);

            tb = new TextBlock();
            tb.Text = "Not encrypted";
            Grid.SetColumn(tb, 1);
            Grid.SetRow(tb, 2);
            g.Children.Add(tb);

            g.ShowGridLines = true;
            this.Content = g;
        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace BindingWithFallback {

  class MyClass {
    public string FastProperty { get { return "No need for fallback value..."; } }
    public string SlowProperty { get { System.Threading.Thread.Sleep(2000); return "A fallback value is useful here..."; } }
    public MyClass NullProperty { get { return null; } }
    public string ExceptionProperty { get { throw new Exception("Oops!"); } }
  }

  public partial class Window1 : System.Windows.Window {

    public Window1() {
      InitializeComponent();
      DataContext = new MyClass();
    }

  }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.ComponentModel;


namespace DisplayAndValueMemberBinding {

  public class Person : INotifyPropertyChanged {
    // INotifyPropertyChanged Members
    public event PropertyChangedEventHandler PropertyChanged;
    protected void Notify(string propName) {
      if( this.PropertyChanged != null ) {
        PropertyChanged(this, new PropertyChangedEventArgs(propName));
      }
    }

    string name;
    public string Name {
      get { return this.name; }
      set {
        if( this.name == value ) { return; }
        this.name = value;
        Notify("Name");
      }
    }

    int age;
    public int Age {
      get { return this.age; }
      set {
        if( this.age == value ) { return; }
        this.age = value;
        Notify("Age");
      }
    }
  }

  class People : ObservableCollection<Person> { }

  public class NamedAge : INotifyPropertyChanged {
    // INotifyPropertyChangeIdd Members
    public event PropertyChangedEventHandler PropertyChanged;
    protected void Notify(string propNameForAge) {
      if( this.PropertyChanged != null ) {
        PropertyChanged(this, new PropertyChangedEventArgs(propNameForAge));
      }
    }

    string nameForAge;
    public string NameForAge {
      get { return this.nameForAge; }
      set {
        if( this.nameForAge == value ) { return; }
        this.nameForAge = value;
        Notify("NameForAge");
      }
    }

    int ageId;
    public int AgeId {
      get { return this.ageId; }
      set {
        if( this.ageId == value ) { return; }
        this.ageId = value;
        Notify("AgeId");
      }
    }
  }

  class NamedAges : ObservableCollection<NamedAge> { }

  public partial class Window1 : System.Windows.Window {

    public Window1() {
      InitializeComponent();
      lb.MouseDoubleClick += lb_MouseDoubleClick;
      this.birthdayButton.Click += birthdayButton_Click;
      this.backButton.Click += backButton_Click;
      this.forwardButton.Click += forwardButton_Click;
    }

    void lb_MouseDoubleClick(object sender, MouseButtonEventArgs e) {
      int index = lb.SelectedIndex;
      if( index < 0 ) { return; }

      Person item = (Person)lb.SelectedItem;
      int value = (int)lb.SelectedValue;

      // do something profitable with this data...
      MessageBox.Show(string.Format("index= {0}, Person= ({1}, {2}), value={3}", index, item.Name, item.Age, value));
    }

    ICollectionView GetFamilyView() {
      People people = (People)this.FindResource("Family");
      return CollectionViewSource.GetDefaultView(people);
    }

    void birthdayButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      Person person = (Person)view.CurrentItem;

      ++person.Age;
      MessageBox.Show(
        string.Format(
          "Happy Birthday, {0}, age {1}!",
          person.Name,
          person.Age),
        "Birthday");
    }

    void backButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      view.MoveCurrentToPrevious();
      if( view.IsCurrentBeforeFirst ) {
        view.MoveCurrentToFirst();
      }
    }

    void forwardButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      view.MoveCurrentToNext();
      if( view.IsCurrentAfterLast ) {
        view.MoveCurrentToLast();
      }
    }

  }
}

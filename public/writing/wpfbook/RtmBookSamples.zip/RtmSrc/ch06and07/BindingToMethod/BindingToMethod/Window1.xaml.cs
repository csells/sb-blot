using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BindingToMethod {
  public partial class Window1 : System.Windows.Window {

    public Window1() {
      InitializeComponent();
      nextButton.Click += new RoutedEventHandler(nextButton_Click);
    }

    void nextButton_Click(object sender, RoutedEventArgs e) {
      ((ObjectDataProvider)Resources["nextRandomNumber"]).Refresh();
    }

  }

  public class StringToInt32Converter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      return ((int)value).ToString();
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      return int.Parse((string)value);
    }
  }

  public class IntegerValidator : ValidationRule {
    public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo) {
      try {
        int.Parse((string)value);
        return ValidationResult.ValidResult;
      }
      catch( Exception ex ) {
        return new ValidationResult(false, ex.Message);
      }
    }
  }

}

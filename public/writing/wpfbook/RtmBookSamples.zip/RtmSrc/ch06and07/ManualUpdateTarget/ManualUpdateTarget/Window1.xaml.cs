using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;


namespace ManualUpdateTarget {

  // No notification support
  public class Person {
    string name;
    public string Name {
      get { return this.name; }
      set {
        if( this.name == value ) { return; }
        this.name = value;
      }
    }

    int age;
    public int Age {
      get { return this.age; }
      set {
        if( this.age == value ) { return; }
        this.age = value;
      }
    }

    public Person() { }
    public Person(string name, int age) {
      this.name = name;
      this.age = age;
    }
  }

  public partial class Window1 : System.Windows.Window {
    public Window1() {
      InitializeComponent();
      this.birthdayButton.Click += birthdayButton_Click;
    }

    void birthdayButton_Click(object sender, RoutedEventArgs e) {
      // Get the Person from the Window's resources
      Person person = (Person)this.FindResource("Tom");

      // Person provides no notification, so force the update of the target manually
      ++person.Age;
      BindingOperations.GetBindingExpression(ageTextBox, TextBox.TextProperty).UpdateTarget();

      MessageBox.Show(
        string.Format(
          "Happy Birthday, {0}, age {1}!",
          person.Name,
          person.Age),
        "Birthday");
    }

  }

}


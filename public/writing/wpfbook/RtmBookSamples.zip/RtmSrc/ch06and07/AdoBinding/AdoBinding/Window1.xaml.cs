// Window1.xaml.cs
using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.Diagnostics;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.ComponentModel;
using System.Configuration; // from System.Configuration.dll

namespace AdoBinding {

  public partial class Window1 : Window {

    public Window1() {
      InitializeComponent();

      // Get the data for binding synchronously
      //DataContext = (new FamilyTableAdapters.PeopleTableAdapter()).GetData();

      this.birthdayButton.Click += birthdayButton_Click;
      this.backButton.Click += backButton_Click;
      this.forwardButton.Click += forwardButton_Click;
      this.addButton.Click += addButton_Click;
      this.sortButton.Click += sortButton_Click;
      this.filterButton.Click += filterButton_Click;
      this.groupButton.Click += groupButton_Click;
    }

    ICollectionView GetFamilyView() {
      DataSourceProvider provider = (DataSourceProvider)this.FindResource("Family");
      return CollectionViewSource.GetDefaultView(provider.Data);
    }

    void birthdayButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();

      // Each item is a DataRowView, which we can use to access the typed PersonRow
      AdoBinding.Family.PeopleRow person =
        (AdoBinding.Family.PeopleRow)((DataRowView)view.CurrentItem).Row;

      ++person.Age;
      MessageBox.Show(
        string.Format(
          "Happy Birthday, {0}, age {1}!",
          person.Name,
          person.Age),
        "Birthday");
    }

    void backButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      view.MoveCurrentToPrevious();
      if( view.IsCurrentBeforeFirst ) {
        view.MoveCurrentToFirst();
      }
    }

    void forwardButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      view.MoveCurrentToNext();
      if( view.IsCurrentAfterLast ) {
        view.MoveCurrentToLast();
      }
    }

    void addButton_Click(object sender, RoutedEventArgs e) {
      // Creating a new PeopleRow
      DataSourceProvider provider = (DataSourceProvider)this.FindResource("Family");
      AdoBinding.Family.PeopleDataTable table =
        (AdoBinding.Family.PeopleDataTable)provider.Data;
      table.AddPeopleRow("Chris", 37);
    }

    void sortButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      if( view.SortDescriptions.Count == 0 ) {
        view.SortDescriptions.Add(new SortDescription("Name", ListSortDirection.Ascending));
        view.SortDescriptions.Add(new SortDescription("Age", ListSortDirection.Descending));
      }
      else {
        view.SortDescriptions.Clear();
      }
    }

    void filterButton_Click(object sender, RoutedEventArgs e) {
      // Can't set the Filter property, but can set the
      // CustomFilter on a BindingListCollectionView
      BindingListCollectionView view =
        (BindingListCollectionView)GetFamilyView();
      if( string.IsNullOrEmpty(view.CustomFilter) ) {
        view.CustomFilter = "Age > 25";
      }
      else {
        view.CustomFilter = null;
      }
    }

    void groupButton_Click(object sender, RoutedEventArgs e) {
      ICollectionView view = GetFamilyView();
      if( view.GroupDescriptions.Count == 0 ) {
        // Group by age
        view.GroupDescriptions.Add(new PropertyGroupDescription("Age"));
      }
      else {
        view.GroupDescriptions.Clear();
      }
    }

  }

  public class AgeToForegroundConverter : IValueConverter {
    // Called when converting the Age to a Foreground brush
    public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      Debug.Assert(targetType == typeof(Brush));

      // DANGER! After 25, it's all down hill...
      int age = int.Parse(value.ToString());
      return (age > 25 ? Brushes.Red : Brushes.Black);
    }

    public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture) {
      // should not be called in our example
      throw new NotImplementedException();
    }
  }

}

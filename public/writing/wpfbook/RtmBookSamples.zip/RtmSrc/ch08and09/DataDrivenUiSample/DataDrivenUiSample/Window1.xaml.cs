using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace DataDrivenUiSample {
  public partial class Window1 : System.Windows.Window {
    TicTacThree game = new TicTacThree(3); // 3x3 grid

    public Window1() {
      InitializeComponent();
      DataContext = game;
    }

    void cell_Click(object sender, RoutedEventArgs e) {
      Button cell = (Button)sender;
      int cellNumber = int.Parse(cell.Tag.ToString());
      game.Move(cellNumber);
      if( game.HasWinner ) {
        MessageBox.Show("Winner!");
        game.NewGame();
      }
    }

  }
}
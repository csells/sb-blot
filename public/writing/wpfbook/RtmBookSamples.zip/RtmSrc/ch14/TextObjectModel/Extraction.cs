using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Documents;

namespace TextObjectModel
{
    class Extraction
    {
        // Example 14-56. Extracting text content

        static string GetText(TextPointer textStart, TextPointer textEnd)
        {
            StringBuilder output = new StringBuilder();

            TextPointer tp = textStart;

            while (tp != null && tp.CompareTo(textEnd) < 0)
            {
                if (tp.GetPointerContext(LogicalDirection.Forward) ==
                           TextPointerContext.Text)
                {
                    output.Append(tp.GetTextInRun(LogicalDirection.Forward));
                }
                tp = tp.GetNextContextPosition(LogicalDirection.Forward);
            }
            return output.ToString();
        }
    }
}

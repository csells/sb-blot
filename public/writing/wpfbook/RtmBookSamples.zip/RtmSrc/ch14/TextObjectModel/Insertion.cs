using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Documents;
using System.Windows.Controls;

namespace TextObjectModel
{
    class Insertion
    {
        // Example 14-57. Inserting text with a TextPointer

        public static void InsertText(RichTextBox richTextBox)
        {
            TextPointer insertionPoint =
              richTextBox.Selection.Start.GetInsertionPosition(LogicalDirection.Forward);
            insertionPoint.InsertTextInRun("Text added from code");
        }

        // End of Example 14-57.
    }
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TextObjectModel
{
    /// <summary>
    /// Interaction logic for NestedSpanElements.xaml
    /// </summary>

    public partial class NestedSpanElements : System.Windows.Window
    {

        public NestedSpanElements()
        {
            InitializeComponent();


            // Example 14-35. Nested Span elements in code

            TextBlock txt = new TextBlock();
            Span rootSpan = new Span();
            rootSpan.FontFamily = new FontFamily("Cambria");
            rootSpan.Inlines.Add(new Run("This uses "));

            Span boldSpan = new Span();
            boldSpan.FontWeight = FontWeights.Bold;
            boldSpan.Inlines.Add(new Run("a "));

            Span italicSpan = new Span();
            italicSpan.Inlines.Add(new Run("mixture"));

            boldSpan.Inlines.Add(italicSpan);
            boldSpan.Inlines.Add(new Run(" of"));

            rootSpan.Inlines.Add(boldSpan);
            rootSpan.Inlines.Add(new Run(" styles"));

            // End of Example 14-35.

            txt.Inlines.Add(rootSpan);
            this.Content = txt;
        }

    }
}
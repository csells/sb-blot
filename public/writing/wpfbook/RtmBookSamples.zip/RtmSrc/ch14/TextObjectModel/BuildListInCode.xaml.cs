using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace TextObjectModel
{
    /// <summary>
    /// Interaction logic for BuildListInCode.xaml
    /// </summary>

    public partial class BuildListInCode : System.Windows.Window
    {

        public BuildListInCode()
        {
            InitializeComponent();

            // Example 14-55. Building a List in code

            FlowDocument doc = new FlowDocument();
            List myList = new List();
            for (int item = 1; item <= 5; ++item)
            {
                string itemText = "Item " + item;
                Run itemRun = new Run(itemText);
                Paragraph itemBlock = new Paragraph(itemRun);
                ListItem listItem = new ListItem(itemBlock);
                myList.ListItems.Add(listItem);
            }
            doc.Blocks.Add(myList);

            // End of Example 14-55.

            this.Content = doc;
        }

    }
}
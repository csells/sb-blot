using System;
using System.Collections.Generic;
using System.Text;

namespace TextDataBinding
{
    public class Person
    {
        private string firstNameValue;

        public string FirstName
        {
            get { return firstNameValue; }
            set { firstNameValue = value; }
        }

        private string lastNameValue;

        public string LastName
        {
            get { return lastNameValue; }
            set { lastNameValue = value; }
        }

    }
}

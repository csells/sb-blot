using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace FlowDocExample
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>

    // Example 14-16. Loading a FlowDocument into a viewer

    partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
            viewer.Document = (FlowDocument) Application.LoadComponent(
                new Uri("MyFlowDocument.xaml", UriKind.Relative));
        }
    }

    // End of Example 14-16.
}
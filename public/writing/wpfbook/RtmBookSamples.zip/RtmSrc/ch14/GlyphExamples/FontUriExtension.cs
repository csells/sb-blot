using System;
using System.Windows.Markup;
using System.Windows.Media;

namespace GlyphsUriLookup
{
    public class FontUriExtension : MarkupExtension
    {
        string fontFamilyName;

        public FontUriExtension(string fontFamilyName)
        {
            this.fontFamilyName = fontFamilyName;
        }

        public override object ProvideValue(IServiceProvider serviceProvider)
        {
            Typeface tf = new Typeface(this.fontFamilyName);
            GlyphTypeface gtf = null;
            if (!tf.TryGetGlyphTypeface(out gtf))
            {
                throw new ArgumentException("Font family not found");
            }
            return gtf.FontUri;
        }
    }
}

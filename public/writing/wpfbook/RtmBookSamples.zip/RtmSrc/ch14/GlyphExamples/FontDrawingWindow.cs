using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;

namespace GlyphExamples
{
    // Example 14-19. GlyphRunDrawing

    public class FontDrawingWindow : Window
    {
        public FontDrawingWindow()
        {

            GlyphRunDrawing drawing = new GlyphRunDrawing(
                    Brushes.Blue, MyGlyphsElement.BuildGlyphRun("Hello, world!"));

            // Host drawing in an Image so we can see it.
            Image imageElement = new Image();
            imageElement.Stretch = Stretch.None;
            imageElement.Source = new DrawingImage(drawing);
            this.Content = imageElement;
        }
    }

    // End of Example 14-19.
}

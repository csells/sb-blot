using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Threading;

namespace GlyphExamples
{
    // Example 14-20. Visual layer text rendering

    public class MyTextElement : FrameworkElement
    {
        protected override void OnRender(DrawingContext drawingContext)
        {
            FormattedText text = new FormattedText(
                "Hello, world!",
                Thread.CurrentThread.CurrentUICulture,
                FlowDirection.LeftToRight,
                new Typeface("Candara"),
                60,    // Font size in pixels
                Brushes.Black);

            drawingContext.DrawText(text, new Point(0, 0));
        }
    }

    // End of Example 14-20.
}

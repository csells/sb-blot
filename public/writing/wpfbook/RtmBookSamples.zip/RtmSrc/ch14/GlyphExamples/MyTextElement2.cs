using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Threading;

namespace GlyphExamples
{
    // Example 14-20. Visual layer text rendering

    public class MyTextElement2 : FrameworkElement
    {
        protected override void OnRender(DrawingContext drawingContext)
        {
            FormattedText text = new FormattedText(
                "I�m not a pheasant plucker, I�m the pheasant plucker�s son, " +
                    "and I�m only plucking pheasants �til the pheasant plucker comes.",
                Thread.CurrentThread.CurrentUICulture,
                FlowDirection.LeftToRight,
                new Typeface("Candara"),
                24,    // Font size in pixels
                Brushes.Black);

            // Example 14-21. Specifying the text width

            text.MaxTextWidth = this.ActualWidth;

            // End of Example 14-21.

            text.MaxTextHeight = this.ActualHeight;


            drawingContext.DrawText(text, new Point(0, 0));
        }
    }

    // End of Example 14-20.
}

using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace GlyphExamples
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);


            FontDrawingWindow fdw = new FontDrawingWindow();
            fdw.Title = "FontDrawingWindow";
            fdw.Width = 300; fdw.Height = 100;
            fdw.Show();

            MyTextElementWindow tew = new MyTextElementWindow();
            tew.Show();
            MyTextElementWindow2 tew2 = new MyTextElementWindow2();
            tew2.Show();
            TypeFaceAndDecorationsWindow tfad = new TypeFaceAndDecorationsWindow();
            tfad.Show();
            GlyphClipping gc = new GlyphClipping();
            gc.Show();
            GlyphsFonts gf = new GlyphsFonts();
            gf.Show();
        }
    }
}
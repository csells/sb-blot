using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Threading;

namespace GlyphExamples
{
    /// <summary>
    /// Interaction logic for GlyphClipping.xaml
    /// </summary>

    public partial class GlyphClipping : System.Windows.Window
    {

        public GlyphClipping()
        {
            InitializeComponent();

            // Example 14-24. Converting text to geometry

            FormattedText text = new FormattedText(
                "CLIP!",
                Thread.CurrentThread.CurrentUICulture,
                FlowDirection.LeftToRight,
                new Typeface("Gill Sans Ultra Bold"),
                20,
                Brushes.Black);

            Geometry textGeometry = text.BuildGeometry(new Point(0, 0));
            button1.Clip = textGeometry;

            // End of Example 14-24.

        }

    }
}
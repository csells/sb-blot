using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Globalization;

namespace VisualRender
{
    // Example 13-61. Custom rendering with layout logic

    class CustomTextRenderer : FrameworkElement
    {
        FormattedText text = new FormattedText("Hello, world",
            CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
            new Typeface("Verdana"), 24, Brushes.Black);

        protected override void OnRender(DrawingContext drawingContext)
        {
            drawingContext.DrawText(text, new Point(0, 0));
        }

        protected override Size MeasureOverride(Size availableSize)
        {
            text.MaxTextWidth = availableSize.Width;
            text.MaxTextHeight = availableSize.Height;
            return new Size(text.Width, text.Height);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            text.MaxTextWidth = finalSize.Width;
            text.MaxTextHeight = finalSize.Height;
            return finalSize;
        }
    }

    // End of Example 13-61.
}

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Diagnostics;
using System.Globalization;

namespace VisualRender
{
    // Example 13-59. A custom OnRender implementation

    class MyFramedTextRenderer : FrameworkElement
    {
        protected override void OnRender(DrawingContext drawingContext)
        {
            Debug.WriteLine("OnRender");

            drawingContext.DrawRectangle(Brushes.Red, null, new Rect(0, 0, 100, 50));

            FormattedText text = new FormattedText("Hello, world",
                CultureInfo.CurrentUICulture, FlowDirection.LeftToRight,
                new Typeface("Verdana"), 24, Brushes.Black);
            drawingContext.DrawText(text, new Point(3, 3));
        }
    }

    // End of Example 13-59.
}

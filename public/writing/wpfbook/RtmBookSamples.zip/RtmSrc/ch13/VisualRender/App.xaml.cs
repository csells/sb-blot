using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;

namespace VisualRender
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : System.Windows.Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            Window2 w2 = new Window2();
            w2.Show();
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BitmapProgramming
{
    /// <summary>
    /// Interaction logic for UseBitmapImage.xaml
    /// </summary>

    public partial class UseBitmapImage : System.Windows.Window
    {

        public UseBitmapImage()
        {
            InitializeComponent();

            // Example 13-31. Using BitmapImage

            Image imageElement = new Image();
            imageElement.Source = new BitmapImage(new Uri(
              "http://www.nasa.gov/images/content/136054main_bm_072004.jpg"));

            // End of Example 13-31.

            this.Content = imageElement;

        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BitmapProgramming
{
    /// <summary>
    /// Interaction logic for AddCaption.xaml
    /// </summary>

    public partial class AddCaption : System.Windows.Window
    {

        public AddCaption()
        {
            InitializeComponent();

            // Example 13-33. Adding a caption to a bitmap

            BitmapImage originalBmp = new BitmapImage();
            originalBmp.BeginInit();
            originalBmp.UriSource = new Uri(
               "http://www.interact-sw.co.uk/images/M3/BackOfM3.jpeg");
            originalBmp.DownloadCompleted += delegate
            {

                Grid rootGrid = new Grid();
                Image img = new Image();
                img.Source = originalBmp;
                rootGrid.Children.Add(img);
                TextBlock caption = new TextBlock();
                caption.Text = "Ian's car";
                caption.FontSize = 35;
                caption.Foreground = Brushes.White;
                caption.Background = new SolidColorBrush(Color.FromArgb(128, 0, 0, 0));
                caption.VerticalAlignment = VerticalAlignment.Bottom;
                caption.HorizontalAlignment = HorizontalAlignment.Center;
                caption.Margin = new Thickness(5);
                caption.Padding = new Thickness(5);
                caption.TextAlignment = TextAlignment.Center;
                caption.TextWrapping = TextWrapping.Wrap;
                rootGrid.Children.Add(caption);

                RenderTargetBitmap bmp = new RenderTargetBitmap(
                    originalBmp.PixelWidth, originalBmp.PixelHeight,
                    originalBmp.DpiX, originalBmp.DpiY, PixelFormats.Pbgra32);
                rootGrid.Measure(new Size(originalBmp.Width, originalBmp.Height));
                rootGrid.Arrange(new Rect(0, 0, originalBmp.Width, originalBmp.Height));
                bmp.Render(rootGrid);

                // bmp now ready for use
                imageElement.Source = bmp;
            };
            originalBmp.EndInit();

            // End of Example 13-33.


        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BitmapProgramming
{
    /// <summary>
    /// Interaction logic for UseRenderTargetBitmap.xaml
    /// </summary>

    public partial class UseRenderTargetBitmap : System.Windows.Window
    {

        public UseRenderTargetBitmap()
        {
            InitializeComponent();


            // Example 13-32. Using RenderTargetBitmap

            RenderTargetBitmap bmp = new RenderTargetBitmap(
                300, 150,     // Dimensions in physical pixels
                300, 300,     // Pixel resolution (dpi)
                PixelFormats.Pbgra32);

            Ellipse e = new Ellipse();
            e.Fill = Brushes.Red;
            e.Measure(new Size(96, 48));
            e.Arrange(new Rect(0, 0, 96, 48));

            bmp.Render(e);

            // End of Example 13-32.


            imageElement.Source = bmp;
        }

    }
}
// Page1.xaml.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.ComponentModel;
using System.Diagnostics;

namespace PageState {
  public partial class Page1 : Page {
    int answer = (new Random()).Next();

    public Page1() {
      Debug.WriteLine("Page1 constructed");
      InitializeComponent();
      answerBox.Text = answer.ToString();
      Loaded += Page1_Loaded;
      Unloaded += Page1_Unloaded;
    }

    void Page1_Loaded(object sender, RoutedEventArgs e) {
      Debug.WriteLine("Page1_Loaded");
      Window parent = Parent as Window;
      if( parent != null ) { parent.Width = 400; parent.Height = 200; }
    }

    void Page1_Unloaded(object sender, RoutedEventArgs e) {
      Debug.WriteLine("Page1_Unloaded");
    }

  }
}

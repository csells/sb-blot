using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.ComponentModel;

namespace PageState {
  public partial class Page1 : Page {

    class GuessData : INotifyPropertyChanged {
      int guess;
      public int Guess {
        get { return guess; }
        set { guess = value; Notify("Guess"); }
      }

      // INotifyPropertyChanged Members
      public event PropertyChangedEventHandler PropertyChanged;
      void Notify(string prop) { if( PropertyChanged != null ) { PropertyChanged(this, new PropertyChangedEventArgs(prop)); } }
    }

    GuessData guess = new GuessData();
    int answer = (new Random()).Next();

    public Page1() {
      InitializeComponent();
      DataContext = guess;
      NavigationService.Navigating += new NavigatingCancelEventHandler(NavigationService_Navigating);
      Loaded += new RoutedEventHandler(Page1_Loaded);
    }

    void NavigationService_Navigating(object sender, NavigatingCancelEventArgs e) {
      Application.Current.nav
    }

    void Page1_Loaded(object sender, RoutedEventArgs e) {
      Window parent = Parent as Window;
      if( parent != null ) { parent.Width = 400; parent.Height = 200; }
    }

  }

  public class PositiveInteger : ValidationRule {
    public override ValidationResult Validate(object value, System.Globalization.CultureInfo cultureInfo) {
      int x;
      if( int.TryParse((string)value, out x) ) return ValidationResult.ValidResult;
      return new ValidationResult(false, "Please enter a number between 0 and 2147483647");
    }
  }

}
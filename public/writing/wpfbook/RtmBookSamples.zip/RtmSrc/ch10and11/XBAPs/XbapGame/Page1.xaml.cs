// Page1.xaml.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation;
using System.ComponentModel;
using System.Diagnostics;

namespace PageState {
  public partial class Page1 : Page {
    int answer = (new Random()).Next();

    public Page1() {
      InitializeComponent();
      answerBox.Text = answer.ToString();
      guessLink.Click += guessLink_Click;
    }

    void guessLink_Click(object sender, RoutedEventArgs e) {
      Page2 page2 = new Page2();
      page2.Answer = answer;
      page2.Guess = int.Parse(guessBox.Text);
      NavigationService.Navigate(page2);
    }

  }
}

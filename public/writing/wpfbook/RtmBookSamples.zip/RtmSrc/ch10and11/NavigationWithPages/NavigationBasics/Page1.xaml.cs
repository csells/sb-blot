// Page1.xaml.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation; // home of the NavigationWindow
using System.Windows.Documents; // home of the Hyperlink
using System.Windows.Controls; // home of the Page
using System.Diagnostics;

namespace NavigationBasics {
  public partial class Page1 : Page {

    public Page1() {
      InitializeComponent();
    }
  }
}

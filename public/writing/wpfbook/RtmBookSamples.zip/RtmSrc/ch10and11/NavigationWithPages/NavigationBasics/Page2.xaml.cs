// Page2.xaml.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation; // home of the NavigationWindow
using System.Windows.Documents; // home of the Hyperlink
using System.Windows.Controls; // home of the Page
using System.Diagnostics;

namespace NavigationBasics
{
    public partial class Page2 : Page
    {

        public Page2()
        {
            InitializeComponent();

            //link2.Click += new RoutedEventHandler(link2_Click);

            // handle the button Click event
            backButton.Click += backButton_Click;
        }

        //void link2_Click(object sender, RoutedEventArgs e) {
        //  // the Page class provides direct access to navigation services
        //  NavigationService.GoBack();
        //}

        void backButton_Click(object sender, RoutedEventArgs e)
        {
            // the Page class provides direct access to navigation services
            this.NavigationService.GoBack();
        }

    }
}

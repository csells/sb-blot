// Window1.xaml.cs
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Navigation; // home of the NavigationWindow
using System.Windows.Documents; // home of the Hyperlink
using System.Diagnostics;


namespace NavigationBasics {
  public partial class Window1 : NavigationWindow {

    // each text is a "page" of content with a single hyperlink
    Hyperlink link1 = new Hyperlink();
    Hyperlink link2 = new Hyperlink();
    TextBlock text1 = new TextBlock();
    TextBlock text2 = new TextBlock();

    public Window1() {
      InitializeComponent();

      //this.Navigate("Hello, World.");
      //return;

      // initialize the first "page"
      text1.Inlines.Add(link1);
      text1.VerticalAlignment = VerticalAlignment.Bottom;
      text1.Loaded += text1_Loaded;

      link1.Inlines.Add("Click to see page 2");
      link1.Click += link1_Click;

      // initialize the second "page"
      text2.Inlines.Add(link2);
      text2.VerticalAlignment = VerticalAlignment.Bottom;
      text2.Loaded += text2_Loaded;

      link2.Inlines.Add("Click to go back to page 1");
      link2.Click += link2_Click;

      // Show first "page"
      this.Navigate(text1);

      #region TODO: drop this
#if false
  // each button is a "page" of content
  Button button1 = new Button();
  Button button2 = new Button();

  // initialize the first "page"
  button1.Content = "Click to see Button 2";

  button1.Loaded += delegate(object sender, RoutedEventArgs e2) {
    // set the navigation window's title
    ((NavigationWindow)button1.Parent).Title = "Welcome to button1";
  };

  button1.Click += delegate(object sender, RoutedEventArgs e2) {
    // navigate to the second "page"
    this.Navigate(button2);
  };

  // initialize the second "page"
  button2.Content = "Click to go back to Button 1";

  button2.Loaded += delegate(object sender, RoutedEventArgs e2) {
    ((NavigationWindow)button2.Parent).Title = "Welcome to button2";
  };

  button2.Click += delegate(object sender, RoutedEventArgs e2) {
    // use the navigation window's history to go back
    ((NavigationWindow)button2.Parent).GoBack();
  };

  //button2.Content = "Button 2: Click to see sellsbrothers.com";

  //button2.Loaded += delegate(object sender, RoutedEventArgs e) {
  //  ((NavigationWindow)(button2.Parent)).Title = "Welcome to button2";
  //};

  //button2.Click += delegate(object sender, RoutedEventArgs e) {
  //  //this.Navigate(button1);
  //  //this.GoBack();
  //  //this.Navigate(new Uri("http://sellsbrothers.com"));
  //  NavigationService.GetNavigationService(button2).Navigate(new Uri("http://sellsbrothers.com"));
  //};

  // Show first "page"
  this.Navigate(button1);
#endif
      #endregion
    }

    void text1_Loaded(object sender, RoutedEventArgs e) {
      Title = "Welcome to Page 1";
    }

    void text2_Loaded(object sender, RoutedEventArgs e) {
      Title = "Welcome to Page 2";
    }

    void link1_Click(object sender, RoutedEventArgs e) {
      // navigate to the second "page"
      Navigate(text2);
    }

    void link2_Click(object sender, RoutedEventArgs e) {
      // the NavigationWindow navigation methos are wrappers around this guy
      NavigationService navService =
        NavigationService.GetNavigationService((DependencyObject)sender);

      // use the navigation history to go back
      navService.GoBack();
    }

  }
}

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Xml;
using System.Collections;


namespace LayoutExamples
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            AddHandler(Hyperlink.ClickEvent, new RoutedEventHandler(NavigateHandler));

        }

        private void NavigateHandler(object sender, RoutedEventArgs e)
        {
            Hyperlink h = e.OriginalSource as Hyperlink;
            if (h == null) return;
            IList nodes = h.Tag as IList;
            if (nodes == null || nodes.Count == 0) return;

            XmlNode node = (XmlNode)nodes[0];
            string target = node.InnerText;

            Type myType = typeof(Window1);
            string typeName = myType.Namespace + "." + target;
            Type targetType = myType.Assembly.GetType(typeName);

            if (targetType == null)
            {
                MessageBox.Show("Couldn't find example " + typeName, "Error");
            }
            else
            {
                Window w = (Window)Activator.CreateInstance(targetType);
                w.Show();
            }
        }

    }
}
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;


namespace Layout {
  public partial class StackPanelDemo : Window {
    public StackPanelDemo() {
      InitializeComponent();

      this.canvasButton.Click += new RoutedEventHandler(canvasButton_Click);
      this.stackPanelButton.Click += new RoutedEventHandler(stackPanelButton_Click);
      this.dockPanelButton.Click += new RoutedEventHandler(dockPanelButton_Click);
      this.gridButton.Click += new RoutedEventHandler(gridButton_Click);
    }

    void gridButton_Click(object sender, RoutedEventArgs e) {
      (new GridDemo()).ShowDialog();
    }

    void dockPanelButton_Click(object sender, RoutedEventArgs e) {
      (new DockPanelDemo()).ShowDialog();
    }

    void stackPanelButton_Click(object sender, RoutedEventArgs e) {
      MessageBox.Show("You're looking @ it!");
    }

    void canvasButton_Click(object sender, RoutedEventArgs e) {
      (new CanvasDemo()).ShowDialog();
    }
  }
}
// MyApp.cs
using System;
using System.Windows; // the root Avalon namespace

namespace MyFirstAvalonApp {
  class MyApp {
    [STAThread]
    static void Main() {
      // the Avalon message box
      MessageBox.Show("Hello, Avalon");
    }
  }
}

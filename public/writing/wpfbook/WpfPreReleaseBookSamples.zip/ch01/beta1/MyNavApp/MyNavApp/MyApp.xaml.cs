// MyApp.xaml.cs
using System;
using System.Windows;
using System.Windows.Navigation;
using System.Data;
using System.Xml;
using System.Configuration;

namespace MyNavApp {
  /// <summary>
  /// Interaction logic for MyApp.xaml
  /// </summary>

  public partial class MyApp : NavigationApplication {

  }
}
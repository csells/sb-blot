// Page2.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyNavApp {
  public partial class Page2 : Page {
    void page1Button_Click(object sender, RoutedEventArgs e) {
      NavigationService.GetNavigationService(this).Navigate(new Uri("page1.xaml", UriKind.Relative));
    }

    void backButton_Click(object sender, RoutedEventArgs e) {
      NavigationService.GetNavigationService(this).GoBack();
    }
    
    void forwardButton_Click(object sender, RoutedEventArgs e) {
      NavigationService.GetNavigationService(this).GoForward();
    }
  }
}
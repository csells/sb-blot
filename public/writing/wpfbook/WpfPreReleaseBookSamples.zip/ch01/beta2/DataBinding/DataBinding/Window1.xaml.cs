// Window1.xaml.cs
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Collections.Generic;
using System.ComponentModel;
using System.Collections.ObjectModel;

namespace DataBindingDemo {
  public class Nickname : INotifyPropertyChanged {
    // INotifyPropertyChanged Member
    public event PropertyChangedEventHandler PropertyChanged;
    protected void OnPropertyChanged(string propName) {
      if( PropertyChanged != null ) {
        PropertyChanged(this, new PropertyChangedEventArgs(propName));
      }
    }

    string name;
    public string Name {
      get { return name; }
      set {
        name = value;
        OnPropertyChanged("Name"); // notify consumers
      }
    }

    private string nick;
    public string Nick {
      get { return nick; }
      set {
        nick = value;
        OnPropertyChanged("Nick"); // notify consumers
      }
    }

    public Nickname() : this("name", "nick") { }
    public Nickname(string name, string nick) {
      this.name = name;
      this.nick = nick;
    }
  }

  // Notify consumers
  public class Nicknames : ObservableCollection<Nickname> {
    public Nicknames() {
        // For testing
        //this.Add(new Nickname("Don", "Naked"));
        //this.Add(new Nickname("Martin", "Gudge"));
        //this.Add(new Nickname("Tim", "Stinky"));
    }
  }

  public partial class Window1 : Window {
    Nicknames names;

    public Window1() {
      InitializeComponent();
      this.addButton.Click += addButton_Click;

      // create Nicknames collection
      //this.names = new Nicknames();

      // get names collection from resources
      this.names = (Nicknames)this.FindResource("names");

      // make data available for binding
      //dockPanel.DataContext = this.names;
    }

    void addButton_Click(object sender, RoutedEventArgs e) {
      this.names.Add(new Nickname());
    }
  }
}

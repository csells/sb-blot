using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example6.xaml
    /// </summary>

    public partial class Example6 : Window
    {
        public Example6()
        {
            InitializeComponent();

            // Create one thread window on main thread
            tw = new ThreadWindow();
            tw.Text = "Created on main thread";
            tw.Show();

            // Fire one up on another thread
            ThreadStart threadMethod = delegate
            {

                w2 = new ThreadWindow();
                w2.Text = "Created on second thread";
                w2.Show();

                // Won�t return until dispatcher shuts down
                System.Windows.Threading.Dispatcher.Run();
            };
            thread = new Thread(threadMethod);
            thread.SetApartmentState(ApartmentState.STA);
            thread.Start();
        }
        Thread thread;
        ThreadWindow tw;
        ThreadWindow w2;

        protected override void OnClosed(EventArgs args)
        {
            tw.Close();
            EventHandler shutdown = delegate
            {
                Dispatcher d = w2.Dispatcher;
                w2.Close();
                d.BeginInvokeShutdown(DispatcherPriority.Normal);
            };
            w2.Dispatcher.BeginInvoke(DispatcherPriority.Normal, shutdown, null, EventArgs.Empty);
        }

    }
}
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example1.xaml
    /// </summary>

    public partial class Example1 : Window
    {
        public Example1()
        {
            InitializeComponent();

            btnRightThread.Click += new RoutedEventHandler(btnRightThread_Click);
            btnWrongThread.Click += new RoutedEventHandler(btnWrongThread_Click);
        }

        void btnRightThread_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Frobnicate(FrobLevel.One);
                MessageBox.Show("Success!");
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Error");
            }
        }

        void btnWrongThread_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                EventHandler callOnOtherThread = delegate
                {
                    Frobnicate(FrobLevel.One);
                };
                IAsyncResult callObject = callOnOtherThread.BeginInvoke(this, EventArgs.Empty, null, null);
                Thread.Sleep(100);
                callOnOtherThread.EndInvoke(callObject);
                MessageBox.Show("Success!");
            }
            catch (Exception x)
            {
                MessageBox.Show(x.ToString(), "Error");
            }
        }

        // Example C-1
        public void Frobnicate(FrobLevel fl)
        {
            // Ensure we�re on the UI thread
            VerifyAccess();
        }
        public enum FrobLevel { One, Two };

    }
}
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example2.xaml
    /// </summary>

    public partial class Example2 : Window
    {
        public delegate void MyDelegateType();
        private void RunsOnWorkerThread()
        {

            Color bgColor = CalculateBgColor();
            MyDelegateType methodForUiThread = delegate
            {
                this.Background = new SolidColorBrush(bgColor);
            };
            this.Dispatcher.BeginInvoke(DispatcherPriority.Normal, methodForUiThread);
        }

        static Color CalculateBgColor()
        {
            byte[] rgb = new byte[3];
            r.NextBytes(rgb);
            return Color.FromRgb(rgb[0], rgb[1], rgb[2]);
        }
        static Random r = new Random();

        public Example2()
        {
            InitializeComponent();

            // The System.Threading.Timer class will call us back on
            // a non-UI thread.
            t = new System.Threading.Timer(
                delegate { RunsOnWorkerThread(); },
                null,
                TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));
        }
        System.Threading.Timer t;

        protected override void OnClosed(EventArgs args)
        {
            t.Dispose();
        }
    }
}
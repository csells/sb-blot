using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;


namespace AsyncExamples
{
    public partial class Example3 : Window
    {
        delegate void UsesColor(Color c);
        private void SetBackgroundColor(Color c)
        {
            this.Background = new SolidColorBrush(c);
        }

        private void RunsOnWorkerThread()
        {
            UsesColor methodForUiThread = SetBackgroundColor;
            this.Dispatcher.BeginInvoke(DispatcherPriority.Normal, methodForUiThread,
                                        Colors.Blue);
        }

        public Example3()
        {
            InitializeComponent();

            ThreadStart ts = delegate
            {
                Thread.Sleep(1000);
                RunsOnWorkerThread();
            };
            Thread t = new Thread(ts);
            t.Start();
        }


    }
}
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example4.xaml
    /// </summary>

    public partial class Example4 : Window
    {
        public delegate void MyDelegateType();

        private void RunsOnWorkerThread()
        {
            MyDelegateType work = delegate
            {

                DoWorkOnUIThread();

                DoWhateverWeNeedToDoNowTheMainWorkHasBeenDone();
            };
            this.Dispatcher.BeginInvoke(DispatcherPriority.Normal, work);
        }

        private void DoWorkOnUIThread()
        {
            VerifyAccess();
            Background = new LinearGradientBrush(Colors.Blue, Colors.Black, 0);
        }

        private void DoWhateverWeNeedToDoNowTheMainWorkHasBeenDone()
        {
            // Whatever...
        }

        public Example4()
        {
            InitializeComponent();

            ThreadStart ts = delegate
            {
                Thread.Sleep(1000);
                RunsOnWorkerThread();
            };
            Thread t = new Thread(ts);
            t.Start();
        }

        // To use Loaded event put Loaded="WindowLoaded" attribute in root element of .xaml file.
        // private void WindowLoaded(object sender, RoutedEventArgs e) {}

        // Sample event handler:  
        // private void ButtonClick(object sender, RoutedEventArgs e) {}

    }
}
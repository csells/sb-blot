using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example5.xaml
    /// </summary>

    public partial class Example5 : Window
    {
        public Example5()
        {
            InitializeComponent();
            DispatcherTimer dt = new DispatcherTimer();
            dt.Tick += dt_Tick;
            dt.Interval = TimeSpan.FromSeconds(2);
            dt.Start();
        }

        void dt_Tick(object sender, EventArgs e)
        {
            Random r = new Random();
            byte[] vals = new byte[3];
            r.NextBytes(vals);
            Color c = Color.FromRgb(vals[0], vals[1], vals[2]);
            this.Background = new SolidColorBrush(c);
        }

    }
}
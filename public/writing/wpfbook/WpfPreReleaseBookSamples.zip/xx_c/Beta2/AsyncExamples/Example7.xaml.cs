using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Threading;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for Example7.xaml
    /// </summary>

    public partial class Example7 : Window
    {
        private BackgroundWorker bw;
        public Example7()
        {
            InitializeComponent();

            bw = new BackgroundWorker();
            bw.DoWork += new DoWorkEventHandler(bw_DoWork);
            bw.ProgressChanged += new ProgressChangedEventHandler(bw_ProgressChanged);
            bw.RunWorkerCompleted += new RunWorkerCompletedEventHandler(
                                                     bw_RunWorkerCompleted);
            bw.WorkerReportsProgress = true;
            bw.RunWorkerAsync();
        }

        void bw_DoWork(object sender, DoWorkEventArgs e)
        {

            // Running on a worker thread
            for (int i = 0; i < 10; ++i)
            {
                int percent = i * 10;
                bw.ReportProgress(percent);
                Thread.Sleep(1000);
            }
        }
        void bw_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.Title = "Working: " + e.ProgressPercentage + "%";
        }

        void bw_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            this.Title = "Finished";
        }
    }
}
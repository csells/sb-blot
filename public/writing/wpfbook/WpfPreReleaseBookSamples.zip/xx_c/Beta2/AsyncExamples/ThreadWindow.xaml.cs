using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;


namespace AsyncExamples
{
    /// <summary>
    /// Interaction logic for ThreadWindow.xaml
    /// </summary>

    public partial class ThreadWindow : Window
    {
        public ThreadWindow()
        {
            InitializeComponent();

            tid.Text = Dispatcher.Thread.ManagedThreadId.ToString();
        }
    }
}
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Xml;
using System.Collections;
using System.Windows.Navigation;


namespace AsyncExamples
{
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();

            AddHandler(Hyperlink.ClickEvent, new RoutedEventHandler(NavigateHandler));

        }
        private void NavigateHandler(object sender, RoutedEventArgs e)
        {
            Hyperlink h = e.OriginalSource as Hyperlink;
            if (h == null) return;

            XmlNode node = h.Tag as XmlNode;
            if (node == null) return;
            string target = node.InnerText;

            Type myType = typeof(Window1);
            string typeName = myType.Namespace + "." + target;
            Type targetType = myType.Assembly.GetType(typeName);

            if (targetType == null)
            {
                MessageBox.Show("Couldn't find example " + typeName, "Error");
            }
            else
            {
                Window w = (Window)Activator.CreateInstance(targetType);
                w.Show();
            }
        }

    }
}
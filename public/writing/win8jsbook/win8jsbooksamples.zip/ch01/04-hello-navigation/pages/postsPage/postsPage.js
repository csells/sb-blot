﻿// postsPage.js
(function () {
  "use strict";

  WinJS.UI.Pages.define("/pages/postsPage/postsPage.html", {
    ready: function (element, options) {
      // TODO: do something with the feed object the user invoked
      var feed = options.feed;
    },
  });
})();

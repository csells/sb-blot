You can download the files for this folder from:

http://sellsbrothers.com/Content/poststuff/writing/win8jsbook/win8jsbooksamples-media.zip

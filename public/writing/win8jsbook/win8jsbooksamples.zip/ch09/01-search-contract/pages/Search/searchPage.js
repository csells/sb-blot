﻿// searchPage.js
(function () {
  "use strict";

  WinJS.Binding.optimizeBindingReferences = true;

  var appModel = Windows.ApplicationModel;
  var appViewState = Windows.UI.ViewManagement.ApplicationViewState;
  var nav = WinJS.Navigation;
  var ui = WinJS.UI;
  var utils = WinJS.Utilities;
  var searchPageURI = "/pages/Search/searchPage.html";

  ui.Pages.define(searchPageURI, {
    _filters: [],
    _lastSearch: "",

    // This function is called whenever a user navigates to this page. It
    // populates the page elements with the app's data.
    ready: function (element, options) {
      var listView = element.querySelector(".resultslist").winControl;
      listView.itemTemplate = element.querySelector(".itemtemplate");
      listView.oniteminvoked = this._itemInvoked;
      this._handleQuery(element, options);
      listView.element.focus();
    },

    // This function updates the page layout in response to viewState changes.
    updateLayout: function (element, viewState, lastViewState) {
      /// <param name="element" domElement="true" />

      var listView = element.querySelector(".resultslist").winControl;
      if (lastViewState !== viewState) {
        if (lastViewState === appViewState.snapped || viewState === appViewState.snapped) {
          var handler = function (e) {
            listView.removeEventListener("contentanimating", handler, false);
            e.preventDefault();
          }
          listView.addEventListener("contentanimating", handler, false);
          var firstVisible = listView.indexOfFirstVisible;
          this._initializeLayout(listView, viewState);
          if (firstVisible >= 0 && listView.itemDataSource.list.length > 0) {
            listView.indexOfFirstVisible = firstVisible;
          }
        }
      }
    },

    // This function filters the search data using the specified filter.
    _applyFilter: function (filter, originalResults) {
      if (filter.results === null) {
        filter.results = originalResults.createFiltered(filter.predicate);
      }
      return filter.results;
    },

    // This function responds to a user selecting a new filter. It updates the
    // selection list and the displayed results.
    _filterChanged: function (element, filterIndex) {
      var filterBar = element.querySelector(".filterbar");
      var listView = element.querySelector(".resultslist").winControl;

      utils.removeClass(filterBar.querySelector(".highlight"), "highlight");
      utils.addClass(filterBar.childNodes[filterIndex], "highlight");

      element.querySelector(".filterselect").selectedIndex = filterIndex;

      listView.itemDataSource = this._filters[filterIndex].results.dataSource;
    },

    _generateFilters: function () {
      this._filters = [];
      this._filters.push({ results: null, text: "All", predicate: function (item) { return true; } });

      // Add Groups for each Feed
      Data.groups.forEach(function (feed) {
        // Filter Search by feed
        this._filters.push({
          results: null,
          text: feed.title,
          predicate: function (item) {
            // If the feed matches the group on the item, then it's in that filter
            return item.group === feed;
          }
        });
      }, this);

    },

    // This function executes each step required to perform a search.
    _handleQuery: function (element, args) {
      var originalResults;
      this._lastSearch = args.queryText;
      WinJS.Namespace.define("searchPage", { markText: WinJS.Binding.converter(this._markText.bind(this)) });
      this._initializeLayout(element.querySelector(".resultslist").winControl, Windows.UI.ViewManagement.ApplicationView.value);
      this._generateFilters();
      originalResults = this._searchData(args.queryText);
      if (originalResults.length === 0) {
        document.querySelector('.filterarea').style.display = "none";
      } else {
        document.querySelector('.resultsmessage').style.display = "none";
      }
      this._populateFilterBar(element, originalResults);
      this._applyFilter(this._filters[0], originalResults);
    },

    // This function updates the ListView with new layouts
    _initializeLayout: function (listView, viewState) {
      /// <param name="listView" value="WinJS.UI.ListView.prototype" />

      if (viewState === appViewState.snapped) {
        listView.layout = new ui.ListLayout();
        document.querySelector(".titlearea .pagetitle").textContent = '“' + this._lastSearch + '”';
        document.querySelector(".titlearea .pagesubtitle").textContent = "";
      } else {
        listView.layout = new ui.GridLayout();

        // TODO: Change "App Name" to the name of your app.
        document.querySelector(".titlearea .pagetitle").textContent = "RssReader";
        document.querySelector(".titlearea .pagesubtitle").textContent = "Results for “" + this._lastSearch + '”';
      }
    },

    _itemInvoked: function (args) {
      args.detail.itemPromise.done(function itemInvoked(item) {
        // TODO: Navigate to the item that was invoked.
        navigateToItem(item.data);
      });
    },

    // This function colors the search term. Referenced in /pages/Search/searchPage.html
    // as part of the ListView item templates.
    _markText: function (text) {
      return text.replace(this._lastSearch, "<mark>" + this._lastSearch + "</mark>");
    },

    // This function generates the filter selection list.
    _populateFilterBar: function (element, originalResults) {
      var filterBar = element.querySelector(".filterbar");
      var listView = element.querySelector(".resultslist").winControl;
      var li, option, filterIndex;

      filterBar.innerHTML = "";
      for (filterIndex = 0; filterIndex < this._filters.length; filterIndex++) {
        this._applyFilter(this._filters[filterIndex], originalResults);

        li = document.createElement("li");
        li.filterIndex = filterIndex;
        li.tabIndex = 0;
        li.textContent = this._filters[filterIndex].text + " (" + this._filters[filterIndex].results.length + ")";
        li.onclick = function (args) { this._filterChanged(element, args.target.filterIndex); }.bind(this);
        li.onkeyup = function (args) {
          if (args.key === "Enter" || args.key === "Spacebar")
            this._filterChanged(element, args.target.filterIndex);
        }.bind(this);
        utils.addClass(li, "win-type-interactive");
        utils.addClass(li, "win-type-x-large");
        filterBar.appendChild(li);

        if (filterIndex === 0) {
          utils.addClass(li, "highlight");
          listView.itemDataSource = this._filters[filterIndex].results.dataSource;
        }

        option = document.createElement("option");
        option.value = filterIndex;
        option.textContent = this._filters[filterIndex].text + " (" + this._filters[filterIndex].results.length + ")";
        element.querySelector(".filterselect").appendChild(option);
      }

      element.querySelector(".filterselect").onchange = function (args) { this._filterChanged(element, args.currentTarget.value); }.bind(this);
    },

    // This function populates a WinJS.Binding.List with search results for the
    // provided query.
    _searchData: function (queryText) {
      var originalResults;
      // Only search if there are items to search
      if (window.Data && window.Data.items && window.Data.items.length > 0) {
        var searchExpression = new RegExp(queryText, "i"); // Use query to do a regex search
        originalResults = Data.items.createFiltered(function (item) {
          return searchExpression.test(item.title);
        });
      } else {
        originalResults = new WinJS.Binding.List();
      }
      return originalResults;
    }
  });

  WinJS.Application.addEventListener("activated", function (args) {
    if (args.detail.kind === appModel.Activation.ActivationKind.search) {
      args.setPromise(ui.processAll().then(function () {
        if (!nav.location) {
          nav.history.current = { location: Application.navigator.home, initialState: {} };
        }

        return nav.navigate(searchPageURI, { queryText: args.detail.queryText });
      }));
    }
  });

  // query submitted
  appModel.Search.SearchPane.getForCurrentView().onquerysubmitted = function (args) { nav.navigate(searchPageURI, args); };

  // DONE: handle navigation
  function navigateToItem(item) {
    // determine item number in group 
    var items = Data.getItemsFromGroup(item.group);
    var itemIndex = items.indexOf(item);

    // if we found the item, navigate to the feed and item
    if (item) {
      WinJS.Navigation.navigate("/pages/split/split.html", { groupKey: item.group.key, selectedIndex: itemIndex });
    }
  }

  // DONE: suggestions
  appModel.Search.SearchPane.getForCurrentView().onsuggestionsrequested = function (args) {
    var req = args.request;

    // calculate the query and alternatives
    var alternatives = args.linguisticDetails.queryTextAlternatives;
    var query = args.queryText;
    var queries = [query];
    alternatives.forEach(function (alt) { queries.push(alt) });

    // get suggestions and append them to the OS
    var suggestions = Data.getSuggestedResults(queries, 5);
    req.searchSuggestionCollection.appendSearchSeparator("RSS Items");
    suggestions.forEach(function (item) {
      //req.searchSuggestionCollection.appendQuerySuggestion(item.title);
      req.searchSuggestionCollection.appendResultSuggestion(item.title,
        item.description,
        item.id, // navigate to the blog containing this post upon suggested picked
        Data.appIconStreamReference,
        item.title); // all required but last parameter
    });
  };

  appModel.Search.SearchPane.getForCurrentView().onresultsuggestionchosen = function (args) {
    // if the user picks a suggestion, just go to that blog group with the post
    // tag is the id of the post
    navigateToItem(Data.resolveItemReference(args.tag));
  };

})();
